extends "res://ui_teclas.gd"
# p23 · tecla I: inventario (equipo + bolsa 8 × 5), baúl (bolsa ↔ baúl 10 × 10) y venta a Tobías el herrero.
# Modelo: inventario.gd (cada pieza ocupa su tam de data/equipo.json). Arrastrar mueve, equipa o vende; con el dedo también vale
# tocar un objeto (se marca) y luego tocar dónde va. Doble clic: equipar/quitar (inventario) o pasar al otro lado (baúl).
const SLOTS := {"casco": Rect2(128, 162, 76, 72), "arma": Rect2(128, 250, 76, 132), "guantes": Rect2(128, 398, 76, 72), "pantalones": Rect2(128, 486, 76, 72),
	"collar": Rect2(486, 162, 76, 72), "pechera": Rect2(486, 250, 76, 132), "anillo": Rect2(486, 398, 76, 72), "botas": Rect2(486, 486, 76, 72)}
const MOSTRADOR := Rect2(920, 180, 280, 190)
const BORDE_OBJ := Color(0.925, 0.925, 0.957)
const VERDE_OK := Color(0.43, 0.9, 0.43)
const ROJO_NO := Color(0.93, 0.33, 0.28)
var rejillas: Array = []      # [{"inv": Inventario, "g": Vector2 (esquina), "cel": int, "tabla": String}]
var agarre: Variant = null             # lo que se está pulsando/arrastrando: {"de": "rejilla"|"ranura", "g", "i", "r", "id", "off", "p0", "mueve"}
var sel: Variant = null                # objeto marcado (toque o clic): mismo formato
var encima: Variant = null             # bajo el ratón (para la ficha)
var puntero := Vector2(-100, -100)
var demo := false             # fotogramas del GIF: se dibuja el puntero
var banner := Rect2()         # «El herrero te da…» (clic: vender lo marcado)
var cuerpo: Texture2D
var herrero_tx: Texture2D

func _montar() -> void:
	match modo:
		"inventario": rejillas = [{"inv": tec.inv, "g": Vector2(662, 190), "cel": 60, "tabla": "tabla_8x5_60"}]
		"baul": rejillas = [{"inv": tec.inv, "g": Vector2(92, 214), "cel": 50, "tabla": "tabla_8x5_50"}, {"inv": tec.baul, "g": Vector2(744, 190), "cel": 44, "tabla": "tabla_10x10_44"}]
		_: rejillas = [{"inv": tec.inv, "g": Vector2(84, 200), "cel": 56, "tabla": "tabla_8x5_56"}]
	if modo == "inventario": cuerpo = _recortada("res://assets/pjs8/%s/%s_reposo_sur.png" % [Equipo.pj_arte(m().pj), Equipo.pj_arte(m().pj)])
	if modo == "herrero": herrero_tx = _recortada("res://assets/raizal2/v_herrero_0.png")
	for r in rejillas: r["inv"].cambiado.connect(L.queue_redraw)

static func _recortada(ruta: String) -> Texture2D:   # sin el margen transparente (para colocar la figura por los pies)
	var tx: Texture2D = load(ruta)
	if tx == null: return null
	var u: Rect2i = tx.get_image().get_used_rect()
	var a := AtlasTexture.new(); a.atlas = tx; a.region = Rect2(u); return a

# ---- geometría ----
func _rect_obj(gi: int, o: Dictionary) -> Rect2:
	var r: Dictionary = rejillas[gi]; var c: int = r["cel"]; var p := Equipo.pieza(o["id"])
	return Rect2(r["g"] + Vector2(int(o["x"]), int(o["y"])) * c + Vector2(2, 2), Vector2(p.tam) * c - Vector2(4, 4))
func _rect_rejilla(gi: int) -> Rect2:
	var r: Dictionary = rejillas[gi]; var inv: Inventario = r["inv"]
	return Rect2(r["g"], Vector2(inv.ancho, inv.alto) * int(r["cel"]))
func _objeto_en(p: Vector2) -> Variant:   # {"de": "rejilla", g, i} o {"de": "ranura", r} o null
	for gi in rejillas.size():
		var inv: Inventario = rejillas[gi]["inv"]
		for i in inv.objetos.size():
			if _rect_obj(gi, inv.objetos[i]).grow(2).has_point(p): return {"de": "rejilla", "g": gi, "i": i, "id": inv.objetos[i]["id"]}
	if modo == "inventario":
		for r in SLOTS:
			if SLOTS[r].has_point(p) and tec.inv.equipado.has(r): return {"de": "ranura", "r": r, "id": tec.inv.equipado[r]}
	return null
func _id(a) -> String: return String(a["id"]) if a != null else ""
func _igual(a, b) -> bool:
	if a == null or b == null: return false
	return a["de"] == b["de"] and a.get("g", -1) == b.get("g", -1) and a.get("i", -1) == b.get("i", -1) and a.get("r", "") == b.get("r", "")
# a dónde iría una pieza cuya esquina está en «esq»: [gi, celda] (gi = -1 si fuera de las cuadrículas)
func _destino(id: String, esq: Vector2, p: Vector2) -> Array:
	for gi in rejillas.size():
		var c: int = rejillas[gi]["cel"]
		if _rect_rejilla(gi).grow(c * 0.5).has_point(p):
			var q: Vector2 = ((esq - rejillas[gi]["g"]) / c).round()
			return [gi, Vector2i(int(q.x), int(q.y))]
	return [-1, Vector2i.ZERO]
func _ranura_en(p: Vector2) -> String:
	if modo != "inventario": return ""
	for r in SLOTS:
		if SLOTS[r].grow(6).has_point(p): return r
	return ""
func _cabe_en(a: Dictionary, gi: int, q: Vector2i) -> bool:
	var inv: Inventario = rejillas[gi]["inv"]
	return inv.cabe(a["id"], q.x, q.y, a["i"] if a["de"] == "rejilla" and a["g"] == gi else -1)

# ---- acciones ----
func _soltar(a: Dictionary, p: Vector2, esq: Vector2) -> bool:
	var id: String = a["id"]
	if modo == "herrero" and MOSTRADOR.has_point(p) and a["de"] == "rejilla":
		tec.vender(a["i"]); return true
	var r := _ranura_en(p)
	if r != "":
		if a["de"] == "rejilla" and Equipo.pieza(id).ranura == r: return tec.inv.equipar(a["i"])
		return false
	var d := _destino(id, esq, p)
	if d[0] < 0 or not _cabe_en(a, d[0], d[1]): return false
	var dst: Inventario = rejillas[d[0]]["inv"]
	if a["de"] == "ranura": return dst == tec.inv and tec.inv.desequipar_en(a["r"], d[1].x, d[1].y)
	if a["g"] == d[0]: return dst.mover(a["i"], d[1].x, d[1].y)
	var src: Inventario = rejillas[a["g"]]["inv"]
	src.sacar(a["i"]); return dst.poner(id, d[1].x, d[1].y)
func _doble(a: Dictionary) -> void:
	if modo == "inventario":
		if a["de"] == "rejilla": tec.inv.equipar(a["i"])
		else: tec.inv.desequipar(a["r"])
	elif modo == "baul" and a["de"] == "rejilla":
		var otro: Inventario = rejillas[1 - int(a["g"])]["inv"]
		if otro.hueco(a["id"]).x >= 0: rejillas[a["g"]]["inv"].sacar(a["i"]); otro.meter(a["id"])
	sel = null

func _entrada(e: InputEvent) -> void:
	if e is InputEventMouseMotion:
		puntero = e.position
		if agarre != null and not agarre["mueve"] and puntero.distance_to(agarre["p0"]) > 6: agarre["mueve"] = true; sel = null
		encima = _objeto_en(puntero) if agarre == null else null
		L.queue_redraw(); return
	if not (e is InputEventMouseButton and e.button_index == MOUSE_BUTTON_LEFT): return
	puntero = e.position
	if e.pressed:
		if en_cerrar(puntero): tec.cerrar(); return
		if modo == "herrero" and sel != null and banner.has_point(puntero): tec.vender(sel["i"]); sel = null; L.queue_redraw(); return
		var a: Variant = _objeto_en(puntero)
		if a != null and e.double_click: _doble(a); agarre = null; L.queue_redraw(); return
		if a != null:
			var esq: Vector2 = SLOTS[a["r"]].position if a["de"] == "ranura" else _rect_obj(a["g"], rejillas[a["g"]]["inv"].objetos[a["i"]]).position - Vector2(2, 2)
			a["off"] = puntero - esq; a["p0"] = puntero; a["mueve"] = false; agarre = a
		elif sel != null:   # tocar el sitio de destino con un objeto marcado
			var c: int = rejillas[sel.get("g", 0)]["cel"] if sel["de"] == "rejilla" else 60
			var d := _destino(sel["id"], puntero - Vector2(c, c) * 0.5, puntero)
			var esq2: Vector2 = puntero - Vector2(c, c) * 0.5
			if d[0] >= 0: esq2 = rejillas[d[0]]["g"] + Vector2(_celda(d[0], puntero)) * int(rejillas[d[0]]["cel"])
			_soltar(sel, puntero, esq2); sel = null
	else:
		if agarre != null:
			if agarre["mueve"]: _soltar(agarre, puntero, puntero - agarre["off"])
			else: sel = null if _igual(sel, agarre) and modo != "herrero" else agarre
			agarre = null
	encima = _objeto_en(puntero)
	L.queue_redraw()
func marcar(i: int) -> void:
	if i >= 0 and i < tec.inv.objetos.size(): sel = {"de": "rejilla", "g": 0, "i": i, "id": tec.inv.objetos[i]["id"]}; L.queue_redraw()
func _celda(gi: int, p: Vector2) -> Vector2i:
	var q: Vector2 = ((p - rejillas[gi]["g"]) / int(rejillas[gi]["cel"])).floor(); return Vector2i(int(q.x), int(q.y))

# ---- dibujo ----
func _dibujar() -> void:
	var c := L
	match modo:
		"inventario": cabecera(c, tr("INV_TITULO"), tr("INV_SUB") % [nombre_pj(), lugar()], retrato_pj())
		"baul": cabecera(c, tr("BAUL_TITULO"), tr("BAUL_SUB") % [nombre_pj(), tr("JUEGO_RAIZAL")], "retrato_cofre")
		_: cabecera(c, tr("HERRERO_TITULO"), tr("HERRERO_SUB"))
	if tec.botin_prueba: _sello(c, Vector2(ancho_txt(_titulo(), 32, Estilo.serif()) + (114 if modo != "herrero" else 44) + 18, 28))
	if modo == "inventario": _equipo(c)
	if modo == "herrero": _panel_herrero(c)
	for gi in rejillas.size(): _rejilla(c, gi)
	_textos_rejillas(c)
	_arrastre(c)
	var f = encima if encima != null and agarre == null else (sel if agarre == null else null)
	banner = Rect2()
	if f != null: _ficha(c, f)
	if demo: _puntero(c, puntero)
func _titulo() -> String: return tr({"inventario": "INV_TITULO", "baul": "BAUL_TITULO"}.get(modo, "HERRERO_TITULO"))
func _sello(c: CanvasItem, p: Vector2) -> void:
	var s := tr("INV_EJEMPLO"); var w := ancho_txt(s, 13, Estilo.negrita()) + 22
	caja(c, Rect2(p, Vector2(w, 24)), Color(0.36, 0.22, 0.08, 0.92), Color(0.93, 0.63, 0.33), 12, 1)
	txt(c, s, p + Vector2(w / 2.0, 12), 13, Color(1, 0.84, 0.63), HORIZONTAL_ALIGNMENT_CENTER, Estilo.negrita(), 0, Color.BLACK, w)

func _equipo(c: CanvasItem) -> void:
	pon(c, "arco_equipo", Vector2(205, 125), Vector2(280, 480))
	if cuerpo:
		var h := 286.0; var w: float = cuerpo.get_width() * h / cuerpo.get_height()
		c.draw_set_transform(Vector2(345, 558), 0, Vector2(1, 0.22)); c.draw_circle(Vector2.ZERO, 70, Color(0, 0, 0, 0.35)); c.draw_set_transform_matrix(Transform2D())
		c.draw_texture_rect(cuerpo, Rect2(345 - w / 2.0, 558 - h, w, h), false)
	var lleva = agarre["id"] if agarre != null and agarre["mueve"] else ""
	for r in SLOTS:
		var q: Rect2 = SLOTS[r]; var id: String = tec.inv.equipado.get(r, "")
		var arrastrado: bool = agarre != null and agarre["mueve"] and agarre["de"] == "ranura" and agarre["r"] == r
		if id == "" or arrastrado: pon(c, "hueco_" + r, q.position - Vector2(4, 4), Vector2(84, q.size.y + 10))
		else:
			pon(c, "hueco_base_" + str(int(q.size.y)), q.position - Vector2(4, 4), Vector2(84, q.size.y + 10))
			_icono(c, id, q.grow(-8))
		if lleva != "" and Equipo.pieza(lleva).ranura == r and not arrastrado:   # dónde se puede equipar lo que llevas
			var sobre: bool = _ranura_en(puntero) == r
			caja(c, q.grow(2), Color(VERDE_OK, 0.22 if sobre else 0.08), Color(VERDE_OK, 0.95 if sobre else 0.6), 7, 2)
		if (encima != null and encima["de"] == "ranura" and encima["r"] == r) or (sel != null and sel["de"] == "ranura" and sel["r"] == r):
			caja(c, q.grow(3), Color(0, 0, 0, 0), Color(1, 0.87, 0.51), 8, 2)
	txt(c, tr("INV_EQUIPO"), Vector2(345, 612), 20, Estilo.ORO, HORIZONTAL_ALIGNMENT_CENTER, Estilo.serif(), 5, Color(0.02, 0.07, 0.07, 0.85), 400)

func _rejilla(c: CanvasItem, gi: int) -> void:
	var r: Dictionary = rejillas[gi]; var inv: Inventario = r["inv"]; var cel: int = r["cel"]; var g: Vector2 = r["g"]
	pon(c, r["tabla"], g - Vector2(16, 16), Vector2(inv.ancho * cel + 32, inv.alto * cel + 34))
	# todas las casillas a la vista (como en Diablo II): fondo más oscuro y un filo suave, debajo de los objetos
	var fondo := Color(0.02, 0.06, 0.06, 0.55); var filo := Color(0.62, 0.52, 0.36, 0.30)
	for yy in inv.alto:
		for xx in inv.ancho:
			var q := Rect2(g + Vector2(xx * cel, yy * cel), Vector2(cel, cel)).grow(-1.5)
			c.draw_rect(q, fondo); c.draw_rect(q, filo, false, 1.0)
	for i in inv.objetos.size():
		var o: Dictionary = inv.objetos[i]; var q := _rect_obj(gi, o)
		var este := {"de": "rejilla", "g": gi, "i": i}
		var arrastrado: bool = agarre != null and agarre["mueve"] and _igual(agarre, este)
		_pieza(c, o["id"], q, 0.35 if arrastrado else 1.0)
		if _igual(sel, este) or (agarre == null and _igual(encima, este)):
			caja(c, q.grow(2), Color(1, 0.84, 0.47, 0.12) if _igual(sel, este) else Color(0, 0, 0, 0), Color(1, 0.87, 0.51), 7, 2)
func _pieza(c: CanvasItem, id: String, q: Rect2, alfa := 1.0) -> void:
	caja(c, q, Color(BORDE_OBJ * 0.22, 0.92 * alfa), Color(0, 0, 0, 0), 5, 0)
	_icono(c, id, q.grow(-3), alfa)
	caja(c, q, Color(0, 0, 0, 0), Color(BORDE_OBJ, 0.86 * alfa), 5, 2)
func _icono(c: CanvasItem, id: String, q: Rect2, alfa := 1.0) -> void:
	var tt := t("ico_" + id)
	if tt == null: return
	var s: Vector2 = tt.get_size(); var k2: float = min(q.size.x * 0.9 / s.x, q.size.y * 0.9 / s.y)
	c.draw_texture_rect(tt, Rect2(q.get_center() - s * k2 / 2.0, s * k2), false, Color(1, 1, 1, alfa))

func _textos_rejillas(c: CanvasItem) -> void:
	var b: Inventario = tec.inv; var tot: int = b.ancho * b.alto
	var g0: Vector2 = rejillas[0]["g"]; var cel0: int = rejillas[0]["cel"]; var cx: float = g0.x + b.ancho * cel0 / 2.0
	match modo:
		"inventario":
			_tit(c, tr("INV_BOLSA") % [b.ancho, b.alto], Vector2(cx, 146), 24)
			_nota(c, "%d / %d" % [b.ocupadas(), tot], Vector2(cx, 586))
			pastilla_oro(c, Vector2(cx, 622), tec.oro())
		"baul":
			var k2: Inventario = tec.baul; var cx2: float = 744 + k2.ancho * 22
			_tit(c, tr("INV_BOLSA") % [b.ancho, b.alto], Vector2(cx, 170), 22)
			_nota(c, "%d / %d" % [b.ocupadas(), tot], Vector2(cx, 497))
			pastilla_oro(c, Vector2(cx, 541), tec.oro())
			_tit(c, tr("BAUL_TABLA") % [k2.ancho, k2.alto], Vector2(cx2, 146), 22)
			_nota(c, "%d / %d" % [k2.ocupadas(), k2.ancho * k2.alto], Vector2(cx2, 664))
		_:
			_tit(c, tr("HERRERO_BOLSA") % [b.ancho, b.alto], Vector2(cx, 157), 22)

func _tit(c: CanvasItem, s: String, p: Vector2, tam: int) -> void: txt(c, s, p, tam, Estilo.ORO, HORIZONTAL_ALIGNMENT_CENTER, Estilo.serif(), 5, Color(0.02, 0.07, 0.07, 0.85), 500)
func _nota(c: CanvasItem, s: String, p: Vector2, tam := 14, col := Estilo.SUAVE) -> void: txt(c, s, p, tam, col, HORIZONTAL_ALIGNMENT_CENTER, null, 0, Color.BLACK, 560)

func _panel_herrero(c: CanvasItem) -> void:
	caja(c, Rect2(640, 150, 586, 530), Color(0.04, 0.1, 0.1, 0.84), Color(0.86, 0.73, 0.46, 0.3), 12, 1)
	for k2 in 6: c.draw_circle(Vector2(775, 400), 130 - k2 * 18, Color(1, 0.67, 0.31, 0.035))
	if herrero_tx:
		var h := 250.0; var w: float = herrero_tx.get_width() * h / herrero_tx.get_height()
		c.draw_set_transform(Vector2(775, 510), 0, Vector2(1, 0.22)); c.draw_circle(Vector2.ZERO, 64, Color(0, 0, 0, 0.35)); c.draw_set_transform_matrix(Transform2D())
		c.draw_texture_rect(herrero_tx, Rect2(775 - w / 2.0, 510 - h, w, h), false)
	txt(c, tr("HERRERO_NOMBRE"), Vector2(775, 542), 20, Estilo.ORO, HORIZONTAL_ALIGNMENT_CENTER, Estilo.serif(), 5, Color(0.02, 0.07, 0.07, 0.85), 260)
	txt(c, tr("HERRERO_PAGA"), Vector2(775, 568), 13, Estilo.SUAVE, HORIZONTAL_ALIGNMENT_CENTER, null, 0, Color.BLACK, 260)
	# mostrador: soltar aquí vende
	var mx := MOSTRADOR; var cx: float = mx.get_center().x
	var sobre: bool = agarre != null and agarre["mueve"] and agarre["de"] == "rejilla" and mx.has_point(puntero)
	pon(c, "mostrador", mx.position - Vector2(4, 4), mx.size + Vector2(8, 10))
	caja(c, Rect2(mx.position + Vector2(14, 40), mx.size - Vector2(28, 54)), Color(0.08, 0.055, 0.03, 0.6) if not sobre else Color(0.25, 0.45, 0.2, 0.55),
		Color(0.86, 0.73, 0.46, 0.47) if not sobre else Color(VERDE_OK, 0.95), 8, 2 if sobre else 1)
	txt(c, tr("HERRERO_MOSTRADOR"), Vector2(cx, mx.position.y + 22), 17, Estilo.CREMA, HORIZONTAL_ALIGNMENT_CENTER, Estilo.serif(), 4, Color(0.1, 0.05, 0.02, 0.9), 260)
	txt(c, tr("HERRERO_SUELTA"), Vector2(cx, mx.position.y + 70), 15, Estilo.SUAVE, HORIZONTAL_ALIGNMENT_CENTER, null, 0, Color.BLACK, 250)
	var n: int = tec.vendidos.size()
	for i in n: _pieza(c, tec.vendidos[i], Rect2(cx - n * 30 + 4 + i * 60, mx.position.y + 92, 52, 52))
	txt(c, tr("HERRERO_VENDIDO") % [tec.vendido_n, tec.vendido_oro], Vector2(cx, mx.position.y + 164), 13, Estilo.SUAVE, HORIZONTAL_ALIGNMENT_CENTER, null, 0, Color.BLACK, 260)
	# tu oro
	var tr2 := Rect2(920, 392, 280, 150)
	caja(c, tr2, Color(0.12, 0.094, 0.04, 0.82), Color(0.96, 0.78, 0.43, 0.59), 10, 1)
	txt(c, tr("HERRERO_TU_ORO"), Vector2(1060, 416), 17, Estilo.ORO, HORIZONTAL_ALIGNMENT_CENTER, Estilo.serif(), 4, Color(0.02, 0.07, 0.07, 0.85), 260)
	pastilla_oro(c, Vector2(1060, 457), tec.oro())
	var vista = agarre if agarre != null and agarre["mueve"] else (sel if sel != null else encima)
	if vista != null and vista["de"] == "rejilla":
		var pv := Equipo.precio_venta(vista["id"])
		txt(c, tr("HERRERO_SI_VENDES") % [tec.oro(), pv, tec.oro() + pv], Vector2(1060, 500), 15, Estilo.VERDE, HORIZONTAL_ALIGNMENT_CENTER, Estilo.negrita(), 0, Color.BLACK, 270)
	txt(c, tr("HERRERO_PRECIO"), Vector2(1060, 524), 12, Estilo.SUAVE, HORIZONTAL_ALIGNMENT_CENTER, null, 0, Color.BLACK, 270)

func _arrastre(c: CanvasItem) -> void:
	if agarre == null or not agarre["mueve"]: return
	var id: String = agarre["id"]; var p := Equipo.pieza(id); var esq: Vector2 = puntero - agarre["off"]
	if _ranura_en(puntero) == "" and not (modo == "herrero" and MOSTRADOR.has_point(puntero)):
		var d := _destino(id, esq, puntero)
		if d[0] >= 0:   # huella: verde si cabe, rojo si no
			var cel: int = rejillas[d[0]]["cel"]; var ok := _cabe_en(agarre, d[0], d[1])
			var inv: Inventario = rejillas[d[0]]["inv"]
			var q := Rect2(rejillas[d[0]]["g"] + Vector2(d[1]) * cel, Vector2(p.tam) * cel)
			q = q.intersection(_rect_rejilla(d[0])).grow(-2)
			if q.size.x > 0 and q.size.y > 0:
				var col := VERDE_OK if ok else ROJO_NO
				caja(c, q, Color(col, 0.27), Color(col, 0.9), 5, 2)
	# la pieza en la mano, al tamaño de la cuadrícula de origen
	var cel0: int = rejillas[agarre["g"]]["cel"] if agarre["de"] == "rejilla" else 60
	var q0 := Rect2(esq + Vector2(2, 2), Vector2(p.tam) * cel0 - Vector2(4, 4))
	caja(c, Rect2(q0.position + Vector2(6, 8), q0.size), Color(0, 0, 0, 0.45), Color(0, 0, 0, 0), 6, 0)
	_pieza(c, id, q0, 0.95)
	caja(c, q0.grow(2), Color(0, 0, 0, 0), Color(1, 0.87, 0.51), 7, 2)

func _mod_txt(k2: String, v: float) -> Array:
	var pct := func(x: float) -> String: return "%+d %%" % int(round(x * 100.0))
	match k2:
		"vida_max": return [tr("INV_MOD_VIDA"), "%+d" % int(v), Estilo.VERDE]
		"reduccion": return [tr("INV_MOD_REDUCCION"), pct.call(-v), Estilo.VERDE]
		"cadencia": return [tr("INV_MOD_CADENCIA"), pct.call(v), Estilo.ORO]
		"vel_mov": return [tr("INV_MOD_VELOCIDAD"), pct.call(v), Estilo.ORO]
		"dano": return [tr("INV_MOD_DANO"), pct.call(v), Estilo.ORO]
		"crit": return [tr("INV_MOD_CRITICO"), pct.call(v), Estilo.ORO]
		"regen": return [tr("INV_MOD_REGEN"), tr("INV_POR_SEGUNDO") % String.num(v, 1).replace(".", ","), Estilo.VERDE]
	return [k2, str(v), Estilo.CREMA]
func _ficha(c: CanvasItem, a: Dictionary) -> void:
	var id: String = a["id"]; var p := Equipo.pieza(id)
	if p == null: return
	var ancla: Rect2 = SLOTS[a["r"]] if a["de"] == "ranura" else _rect_obj(a["g"], rejillas[a["g"]]["inv"].objetos[a["i"]])
	var nom_r: String = tr(Equipo.datos()["nombres_ranura"].get(p.ranura, ""))
	var filas: Array = []
	for k2 in p.mods: filas.append(_mod_txt(k2, float(p.mods[k2])))
	filas.append([tr("INV_HUECO"), nom_r, Estilo.CREMA])
	var vende: bool = modo == "herrero" and a["de"] == "rejilla"
	var pie := "" if vende else tr("INV_HERRERO_DA") % Equipo.precio_venta(id)
	var w := 300.0; var lh := 25.0
	var h: float = 18 + 30 + 20 + 26 + 8 + filas.size() * lh + 14 + (24 if pie != "" else 0)
	var x: float = ancla.end.x + 12; var y: float = ancla.position.y - 30
	if x + w > 1256: x = ancla.position.x - w - 12
	y = clamp(y, 96, 700 - h - (40 if vende else 0))
	caja(c, Rect2(x + 3, y + 6, w, h), Color(0, 0, 0, 0.45), Color(0, 0, 0, 0), 12, 0)
	caja(c, Rect2(x, y, w, h), Color(0.36, 0.235, 0.125), Color(0.2, 0.125, 0.055), 12, 2)
	caja(c, Rect2(x + 6, y + 6, w - 12, h - 12), Color(0.04, 0.094, 0.086, 0.97), Color(0.1, 0.055, 0.016), 8, 1)
	var cx := x + w / 2.0; var cy := y + 18
	txt(c, tr(p.nombre), Vector2(cx, cy + 12), 22, Estilo.ORO, HORIZONTAL_ALIGNMENT_CENTER, Estilo.serif(), 5, Color(0.02, 0.07, 0.07, 0.9), w); cy += 30
	txt(c, tr("INV_TAM") % [nom_r, p.tam.x, p.tam.y], Vector2(cx, cy + 8), 13, Estilo.SUAVE, HORIZONTAL_ALIGNMENT_CENTER, null, 0, Color.BLACK, w); cy += 20
	txt(c, tr("INV_VALE") % p.valor_oro, Vector2(cx, cy + 10), 15, Estilo.CREMA, HORIZONTAL_ALIGNMENT_CENTER, null, 0, Color.BLACK, w); cy += 26
	c.draw_line(Vector2(x + 22, cy), Vector2(x + w - 22, cy), Color(0.86, 0.73, 0.46, 0.35), 1); cy += 8
	for f in filas:
		txt(c, f[0], Vector2(x + 24, cy + lh / 2.0), 15, Estilo.SUAVE)
		txt(c, f[1], Vector2(x + w - 24, cy + lh / 2.0), 17, f[2], HORIZONTAL_ALIGNMENT_RIGHT, Estilo.negrita(), 4, Color(0.02, 0.07, 0.07, 0.85), w - 48); cy += lh
	if pie != "": txt(c, pie, Vector2(cx, cy + 13), 12, Color(0.745, 0.69, 0.55), HORIZONTAL_ALIGNMENT_CENTER, null, 0, Color.BLACK, w)
	if vende:   # pastilla dorada: clic para vender lo marcado
		banner = Rect2(x + 14, y + h - 4, w - 28, 34)
		var activo: bool = _igual(sel, a)
		caja(c, banner, Color(0.235, 0.17, 0.047, 0.95), Color(0.96, 0.78, 0.43, 0.8 if activo else 0.5), 8, 2 if activo else 1)
		txt(c, tr("HERRERO_TE_DA") % Equipo.precio_venta(id), banner.get_center(), 16, Estilo.ORO, HORIZONTAL_ALIGNMENT_CENTER, Estilo.negrita(), 4, Color(0.02, 0.07, 0.07, 0.85), banner.size.x)
		if not activo: banner = Rect2()

func _puntero(c: CanvasItem, p: Vector2) -> void:
	var f := PackedVector2Array([Vector2(0, 0), Vector2(0, 22), Vector2(6, 17), Vector2(10, 26), Vector2(14, 24), Vector2(10, 15), Vector2(17, 15)])
	var sh := PackedVector2Array(); var pt := PackedVector2Array()
	for v in f: sh.append(p + v + Vector2(2, 2)); pt.append(p + v)
	c.draw_colored_polygon(sh, Color(0, 0, 0, 0.45)); c.draw_colored_polygon(pt, Color(0.965, 0.933, 0.847))
	pt.append(p); c.draw_polyline(pt, Color(0.12, 0.06, 0.02), 1.6, true)

# ---- GIF de ejemplo (--teclas_gif=carpeta): arrastra una pieza y guarda los fotogramas ----
func _paso(dir: String, n: int) -> int:
	await RenderingServer.frame_post_draw
	get_viewport().get_texture().get_image().save_png("%s/f_%03d.png" % [dir, n]); return n + 1
func _mover_a(dest: Vector2, pasos: int, dir: String, n: int) -> int:
	var desde := puntero
	for s in pasos:
		var u := float(s + 1) / pasos; u = u * u * (3 - 2 * u)
		var ev := InputEventMouseMotion.new(); ev.position = desde.lerp(dest, u); _entrada(ev)
		n = await _paso(dir, n)
	return n
func _clic(pulsado: bool) -> void:
	var ev := InputEventMouseButton.new(); ev.button_index = MOUSE_BUTTON_LEFT; ev.pressed = pulsado; ev.position = puntero; _entrada(ev)
func demo_arrastre(dir: String) -> void:
	demo = true; DirAccess.make_dir_recursive_absolute(dir)
	await get_tree().create_timer(1.0, true, false, true).timeout
	var inv: Inventario = tec.inv; var n := 0
	# una pieza de la bolsa que se pueda llevar a su ranura (inventario), al baúl o al mostrador
	var i := -1
	for k2 in inv.objetos.size():
		if modo != "inventario" or not inv.equipado.has(Equipo.pieza(inv.objetos[k2]["id"]).ranura): i = k2; break
	if i < 0: i = 0
	var q := _rect_obj(0, inv.objetos[i]); var id: String = inv.objetos[i]["id"]
	puntero = Vector2(1000, 660)
	var dest: Vector2
	match modo:
		"inventario": dest = SLOTS[Equipo.pieza(id).ranura].get_center()
		"baul":
			var h: Vector2i = tec.baul.hueco(id); dest = rejillas[1]["g"] + Vector2(h) * 44 + (q.get_center() - q.position)
		_: dest = MOSTRADOR.get_center()
	n = await _mover_a(q.get_center(), 10, dir, n)
	for s in 4: n = await _paso(dir, n)
	_clic(true)
	n = await _mover_a(q.get_center() + Vector2(-10, -14), 4, dir, n)   # un poco por un sitio donde no cabe…
	n = await _mover_a(dest, 22, dir, n)
	for s in 6: n = await _paso(dir, n)
	_clic(false); L.queue_redraw()
	for s in 14: n = await _paso(dir, n)
	print("TECLAS gif ", n, " fotogramas en ", dir); get_tree().quit()
