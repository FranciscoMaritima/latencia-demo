extends Node2D
# Aventura de Rootheart: Raizal, bosque y zonas secretas.
var arena := Raizal.ARENA
var player: Node2D
var enemies: Array = []
var alive_time := 0.0
var kills := 0
var state := "jugando"
var cam: Camera2D
var shake_amt := 0.0
var hp_bar: ProgressBar
var aviso_banner: Label
var banner_t := 0.0
var t := 0.0
var god := false
var pacifico := "--pacifico" in OS.get_cmdline_user_args()
# p18: ciclo de día y noche (ciclo.gd). --ciclo_x=N lo acelera; --hora=fase|segundos pone la hora al entrar
var ciclo_x := 1.0
var hora_forzada := ""
var ciclo_guarda_t := 0.0
var ciclo_k := 0.0   # 0 de día, 1 de noche (lo leen las criaturas oscuras)   # p17: capturas: el jugador no ataca
var shot_path := ""
var shot_at := 6.0
var trails: Array = []   # [pos, vida, dps]
var sfx := {}
var check_big := false
var obst: Array = []   # [centro, radio]
var stats: Dictionary = {}
var pj := "echo"
var arma := "varita"
var arma_nv := 1
var xp_bar: ProgressBar
var hits := 0
var menu: Control
var test_mode := false
var pausa: Control
var ui_capa: CanvasLayer
var quieto := false
var andar_dir := Vector2.ZERO   # prueba: --andar_dir=norte|noreste|...: camina siempre en esa dirección
var registro_pasos := "--registro_pasos" in OS.get_cmdline_user_args()
var andar := 0   # prueba: --andar=izq/der, el jugador camina siempre hacia ese lado   # prueba: el jugador no se mueve
var modo := "raizal"
# Compañeros (Brasa, Escarcha, Musguito, Chispa): código y datos guardados se conservan, pero DORMIDOS (19/10, 20:26).
# Con false no aparece ninguno ni hay efectos en ningún modo. La búsqueda del Corral («Busca tu Compañero») se quitó del todo.
const COMPANEROS_ACTIVOS := true    # (19/10, 23:36) vuelven en el ARPG: se consiguen explorando zonas secretas (secretos.gd)
var comp_src := false   # el daño en curso lo hace el compañero
var comp_dano := 0.0
var comp_cura := 0.0
var companero = null
# --- ARPG sprint 1: Raizal ---
# Cámara: unidades de mundo visibles en el lado CORTO de la pantalla, iguales en PC y móvil (no depende de los píxeles)
const S_EXPLORA := 1000.0   # Raizal (y el bosque): cámara alejada, estilo Diablo 2
var raizal_esc: Node2D = null
var ui_accion: Button
var ui_burbuja: PanelContainer
var ui_burbuja_l: Label
var salida_cerca := ""
var usar_test := "--usar" in OS.get_cmdline_user_args()   # prueba: usa la salida cercana al segundo
var shot_pos := Vector2.INF
var shot_mira := ""

func _ready() -> void:
	_setup_inputs()
	var fps_n := CanvasLayer.new(); fps_n.set_script(load("res://fps.gd")); fps_n.name = "Fps"; get_tree().root.add_child.call_deferred(fps_n)   # F3: contador de FPS y tirones
	y_sort_enabled = true
	randomize()
	Guardado.cargar(); Arbol.cargar(); _crear_buses(); _aplicar_volumen()
	TranslationServer.set_locale(str(Guardado.d.get("idioma", "es")))   # textos: i18n/textos.csv (de momento solo español)
	# ambiente mágico de bosque (sintetizado, ver audio_licencias.md); bus Master => respeta el volumen de Opciones
	var amb := AudioStreamPlayer.new(); var ws: AudioStreamWAV = load("res://assets/ambiente.wav")
	ws.loop_mode = AudioStreamWAV.LOOP_FORWARD; ws.loop_begin = 0; ws.loop_end = int(ws.get_length() * ws.mix_rate)
	amb.stream = ws; amb.volume_db = -9.0; amb.bus = "Ambiente"; amb.process_mode = Node.PROCESS_MODE_ALWAYS; add_child(amb); amb.play()
	cam = Camera2D.new(); add_child(cam)
	var lim := arena   # la cámara no enseña nada fuera del mapa
	cam.limit_left = int(lim.position.x); cam.limit_top = int(lim.position.y); cam.limit_right = int(lim.end.x); cam.limit_bottom = int(lim.end.y)
	_ajustar_escala(); get_tree().root.size_changed.connect(_ajustar_escala)
	get_tree().root.theme = Estilo.tema()   # estilo único de toda la UI (estilo.gd)
	# el tema no atraviesa CanvasLayer: se asigna a cada Control "raíz" (cuyo padre no es Control) al entrar en el árbol
	get_tree().node_added.connect(func(nd): if nd is Control and not (nd.get_parent() is Control) and nd.theme == null: nd.theme = Estilo.tema())
	var ui := CanvasLayer.new(); ui.layer = 10; add_child(ui); ui_capa = ui
	_hud_crear(ui)
	aviso_banner = Label.new(); aviso_banner.set_anchors_preset(Control.PRESET_CENTER_TOP); aviso_banner.position.y = 90
	aviso_banner.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER; aviso_banner.grow_horizontal = Control.GROW_DIRECTION_BOTH
	aviso_banner.add_theme_font_size_override("font_size", 44); aviso_banner.add_theme_color_override("font_color", Estilo.ORO); aviso_banner.add_theme_font_override("font", Estilo.serif())
	aviso_banner.add_theme_color_override("font_outline_color", Color(0.03, 0.1, 0.1, 0.9)); aviso_banner.add_theme_constant_override("outline_size", 10); aviso_banner.position.y = 150
	ui.add_child(aviso_banner)
	var joy := Control.new(); joy.set_script(load("res://joystick.gd")); ui.add_child(joy)
	joy.moved.connect(func(v): if player: player.touch_vec = v)
	pausa = Control.new(); pausa.set_script(load("res://pausa.gd")); ui.add_child(pausa)
	var teclas := Control.new(); teclas.name = "teclas"; teclas.set_script(load("res://teclas.gd")); ui.add_child(teclas)   # p23: teclas M (mapa) e I (inventario)
	for n in ["aviso", "boom", "mejora", "martillo"]: sfx[n] = load("res://assets/%s.wav" % n)
	var t_r := Node2D.new(); t_r.set_script(load("res://trail.gd")); t_r.z_index = -5; add_child(t_r)
	menu = Control.new(); menu.set_script(load("res://menu.gd")); ui.add_child(menu)
	menu.jugar.connect(func(): menu.visible = false; start_raizal())
	# Opciones de desarrollo: --raizal --bosque --god --shot=ruta.png --shot_at=S
	var args := Array(OS.get_cmdline_user_args())
	args = args.filter(func(a): return not (a in ["--clasico", "--continuar", "--pick", "--auto", "--guardar_cont"] or a.begins_with("--wave=") or a.begins_with("--up=") or a.begins_with("--shot_resumen=") or a.begins_with("--fin=") or a.begins_with("--secuencia=") or a.begins_with("--cap=")))
	# en web: ?god=1 o ?check=1 (solo para pruebas)
	if OS.has_feature("web"):
		var q = JavaScriptBridge.eval("window.location.search", true)
		if q is String and q.length() > 1:
			for kv in q.substr(1).split("&"):
				var p2 = kv.split("=")
				if p2[0] in ["god", "check"]: args.append("--" + p2[0])
	for a in args:
		if a.begins_with("--"): test_mode = true
	if test_mode and not ("--pm" in str(args)): menu.visible = false; start_raizal()
	else: state = "menu"; menu.mostrar()
	for a in args:
		if a == "--touch": _touch_test()
		if a == "--pausa": get_tree().create_timer(3.0).timeout.connect(func(): pausa.alternar())
		if a.begins_with("--pm="): Guardado.d["savia"] = int(a.substr(5)); Guardado.d["semillas"] = 2
		if a.begins_with("--ciclo_x="): ciclo_x = float(a.substr(10))
		if a.begins_with("--hora="): hora_forzada = a.substr(7)
		if a.begins_with("--pj="): pj = a.substr(5); Guardado.d["personaje"] = pj; start_raizal()
		if a.begins_with("--arma="): arma = a.substr(7).split(":")[0]; arma_nv = int(a.substr(7).split(":")[1]) if a.contains(":") else 1
		if a == "--test_menus": _test_menus.call_deferred()
		if a.begins_with("--escena_bestia="): var eb := Node.new(); eb.set_script(load("res://escena_bestia.gd")); eb.set_meta("main", self); eb.set_meta("cfg", a.substr(16)); get_tree().root.add_child.call_deferred(eb)
		if a == "--test_bestiario": var tbe := Node.new(); tbe.set_script(load("res://test_bestiario.gd")); tbe.set_meta("main", self); get_tree().root.add_child.call_deferred(tbe)
		if a.begins_with("--test_dps"): var tdp := Node.new(); tdp.set_script(load("res://test_dps.gd")); tdp.set_meta("main", self); tdp.set_meta("cfg", a.substr(11) if a.length() > 11 else ""); get_tree().root.add_child.call_deferred(tdp)
		if a.begins_with("--sala_jefe"): var sj := Node.new(); sj.set_script(load("res://sala_jefe.gd")); sj.set_meta("main", self); sj.set_meta("cfg", a.substr(12) if a.length() > 12 else ""); sala_nodo = sj; get_tree().root.add_child.call_deferred(sj)
		if a == "--test_ciclo": var tci := Node.new(); tci.set_script(load("res://test_ciclo.gd")); tci.set_meta("main", self); get_tree().root.add_child.call_deferred(tci)
		if a == "--test_textos" or a.begins_with("--capturas_textos="): var tt := Node.new(); tt.set_script(load("res://test_textos.gd")); tt.set_meta("main", self); get_tree().root.add_child.call_deferred(tt)
		if a == "--arbol_prueba": Guardado.d["savia"] = 40; Guardado.d["arbol2"] = {Arbol.pj(): {"vida": 3, "ataque": 1}}
		if a.begins_with("--pestana="): menu.pestana = a.substr(10)   # capturas de Ajustes por pestaña
		if a.begins_with("--menu="): state = "menu"; menu.visible = true; menu.mostrar(a.substr(7))
		if a == "--god": god = true
		if a.begins_with("--bot_fotos="): bot_fotos = a.split("=")[1]
		if a == "--quieto": quieto = true; Engine.time_scale = 4.0
		if a == "--check": check_big = true
		if a.begins_with("--shot="): shot_path = a.substr(7)
		if a.begins_with("--shot_at="): shot_at = float(a.substr(10))
	for a in args:
		if a == "--mortal": god = false
		if a == "--arbol_full": Guardado.d["arbol2"] = {Arbol.pj(): {"vida": 10, "ataque": 10, "habilidades": 10, "defensa": 10, "fortuna": 10}}; start_raizal()
		if a.begins_with("--arbol="):
			var dd := {}
			for kv in a.substr(8).split(","): dd[kv.split(":")[0]] = int(kv.split(":")[1])
			Guardado.d["arbol2"] = {Arbol.pj(): dd}; start_raizal()
		if a == "--arbol_demo":
			Guardado.d["arbol2"] = {Arbol.pj(): {"vida": 4, "ataque": 2, "habilidades": 6, "defensa": 3, "fortuna": 1}}
		if a.begins_with("--esc_en="):   # prueba: pulsa Esc (ui_cancel) a los N segundos
			get_tree().create_timer(float(a.substr(9))).timeout.connect(func():
				var ev := InputEventAction.new(); ev.action = "ui_cancel"; ev.pressed = true; Input.parse_input_event(ev); print("ESC enviado, estado=", state))
		if a == "--perf":   # perfil: media de 3 s tras 2 s de calentamiento
			get_tree().create_timer(2.0).timeout.connect(func():
				var n := [0, 0.0, 0.0, 0.0, 0.0, 0.0]; var t0 := Time.get_ticks_usec()
				get_tree().process_frame.connect(func():
					n[0] += 1; n[1] += Performance.get_monitor(Performance.TIME_PROCESS) * 1000.0
					n[2] += Performance.get_monitor(Performance.RENDER_TOTAL_DRAW_CALLS_IN_FRAME); n[3] += Performance.get_monitor(Performance.RENDER_TOTAL_OBJECTS_IN_FRAME)
					n[4] += Performance.get_monitor(Performance.RENDER_TOTAL_PRIMITIVES_IN_FRAME)
					if Time.get_ticks_usec() - t0 > 3000000 and n[5] == 0.0:
						n[5] = 1.0; var dt: float = (Time.get_ticks_usec() - t0) / 1000.0 / n[0]
						print("PERF frames=%d ms_frame=%.2f fps=%.1f ms_process=%.2f draw_calls=%.0f objetos=%.0f prim=%.0f nodos=%d" % [n[0], dt, 1000.0 / dt, n[1] / n[0], n[2] / n[0], n[3] / n[0], n[4] / n[0], get_tree().get_node_count()])
						get_tree().quit()))
		if a == "--fps": get_tree().create_timer(1.0).timeout.connect(func(): var tm := Timer.new(); tm.wait_time = 2.0; tm.autostart = true; add_child(tm); tm.timeout.connect(func(): print("FPS ", Engine.get_frames_per_second(), " vivos ", enemies.size(), " nodos ", get_tree().get_node_count())))
		if a.begins_with("--andar="): andar = -1 if a.ends_with("izq") else 1
		if a.begins_with("--andar_dir="): andar_dir = _vec_mira(a.substr(12))
		if a.begins_with("--lado="): player.forzar_lado = -1 if a.ends_with("izq") else 1
	for a in args:
		if a.begins_with("--pos="): var xy: PackedStringArray = a.substr(6).split(","); shot_pos = Vector2(float(xy[0]), float(xy[1]))
		if a.begins_with("--mira="): shot_mira = a.substr(7)
	for a in args: if a.begins_with("--con_pj="): pj = a.substr(9); Guardado.d["personaje"] = pj   # capturas: Raizal con otro personaje
	if "--raizal" in args: start_raizal()
	for a in args: if a.begins_with("--tira8="): _tira8(a.substr(8))
	if "--test_dlg" in args: _test_dlg()
	if "--test_alcance" in args and raizal_esc: _test_alcance()
	if "--test_escala" in args and raizal_esc:   # p13: tabla de escala de los edificios y solapes de sus huellas (planta baja)
		var malos := 0
		for h in raizal_esc.huellas:
			print("ESCALA %-18s alto %4d u · ancho %4d u · puerta %3d u (%.2f de Eco)" % [h[0], h[4], h[2] + h[3], h[5], h[5] / 100.0])
		for i in raizal_esc.huellas.size():
			for j in range(i + 1, raizal_esc.huellas.size()):
				var a: Array = raizal_esc.huellas[i]; var b: Array = raizal_esc.huellas[j]
				var ra := Rect2(a[1].x - a[2] * 0.92, a[1].y - a[4] * 0.32, (a[2] + a[3]) * 0.92, a[4] * 0.32)
				var rb := Rect2(b[1].x - b[2] * 0.92, b[1].y - b[4] * 0.32, (b[2] + b[3]) * 0.92, b[4] * 0.32)
				if ra.intersects(rb): print("SOLAPE %s %s con %s %s (%d u)" % [a[0], Vector2i(a[1]), b[0], Vector2i(b[1]), ra.intersection(rb).size.x]); malos += 1
		# p13b: el puesto de pócimas, como mucho la mitad de ancho y de alto VISIBLES que la taberna, y más alto que Eco
		var vp := _visible_u(raizal_esc.get_node("madriguera_gusana")); var vt := _visible_u(raizal_esc.get_node("casa_posada")); var ve := _visible_u(player.spr)
		print("VISIBLE pócimas %d x %d u · taberna %d x %d u · Eco %d x %d u" % [vp.x, vp.y, vt.x, vt.y, ve.x, ve.y])
		if vp.x > vt.x * 0.5 or vp.y > vt.y * 0.5 or vp.y <= ve.y * 1.2: print("ESCALA pócimas demasiado grande o demasiado pequeño"); malos += 1
		var vf := _visible_u(raizal_esc.get_node("forja_brasas"))   # p13c: la forja de Brasas, con la misma regla
		print("VISIBLE forja %d x %d u" % [vf.x, vf.y])
		if vf.x > vt.x * 0.5 or vf.y > vt.y * 0.5 or vf.y <= ve.y * 1.2: print("ESCALA forja demasiado grande o demasiado pequeña"); malos += 1
		print("ESCALA OK (sin solapes)" if malos == 0 else "ESCALA FALLA %d solapes" % malos)
		if not "--test_alcance" in args: get_tree().quit()
	if "--test_guirnaldas" in args and raizal_esc:
		var cr: Array = raizal_esc.guirnaldas_cruces()
		if "--rects" in args:
			for c in raizal_esc.get_children():
				if c is Sprite2D and c.texture != null and c.z_index >= 0 and c != raizal_esc.copa:
					var rc: Rect2 = c.get_rect(); var gt: Transform2D = c.get_global_transform(); var r := Rect2(gt * rc.position, Vector2.ZERO).expand(gt * rc.end)
					if r.size.y >= 60.0 and r.intersects(Rect2(-700, -300, 1500, 1100)): print("RECT %s %d %d %d %d" % [c.name, r.position.x, r.position.y, r.end.x, r.end.y])
			for o in raizal_esc.obst:
				if Rect2(-700, -300, 1500, 1100).has_point(o[0]): print("OBST %d %d %d" % [o[0].x, o[0].y, o[1]])
		for c in cr: print("GUIRNALDA %d cruza por delante de %s en %s" % [c[1], c[0], c[2]])
		print("GUIRNALDAS OK (%d cuerdas)" % raizal_esc.guirnaldas.size() if cr.is_empty() else "GUIRNALDAS FALLA %d" % cr.size())
		if not "--test_alcance" in args: get_tree().quit()
	for a in args:
		if a.begins_with("--casa=") and raizal_esc:
			var cid: String = str(a).substr(7)
			get_tree().create_timer(0.3).timeout.connect(func():
				for pu in raizal_esc.puertas: if pu[0] == cid: _entrar(pu)
				for a2 in OS.get_cmdline_user_args():   # capturas: --pos_casa=x,y (px de la lámina) coloca al niño dentro
					if a2.begins_with("--pos_casa="):
						var xy: PackedStringArray = a2.substr(11).split(",")
						get_tree().create_timer(0.6).timeout.connect(func(): if interior: player.position = interior.resolver(Vector2(float(xy[0]), float(xy[1])) * Interior.DS, 16.0); player.mira = Vector2.DOWN))
		if a == "--vista_total": _vista_total()
	if "--test_puertas" in args: _test_puertas()
	if "--test_colarse" in args and raizal_esc: _test_colarse()
	if "--ver_colision" in args and raizal_esc:   # depuración: círculos de colisión a la vista
		var vc := Node2D.new(); vc.set_script(load("res://ver_colision.gd")); vc.obst = raizal_esc.obst; raizal_esc.add_child(vc)
	if "--test_interiores" in args: _test_interiores()
	if "--test_cruce" in args: _test_cruce()
	if "--barrido" in args: _barrido()
	if "--bosque" in args: start_raizal(); arpg["hojas"] = max(arpg["hojas"], 2); start_bosque()
	for a in args:   # capturas: --zona=tuneles|refugio|claro_musgo|cueva_helada|hondonada (con --etapa, --comps…)
		if a.begins_with("--zona="): start_raizal(); arpg["hojas"] = max(arpg["hojas"], 3); start_zona(a.substr(7))
		if a.begins_with("--bosque_pos="): var xy2: PackedStringArray = a.substr(13).split(","); player.position = Vector2(float(xy2[0]), float(xy2[1])); cam.position = player.position; cam.reset_smoothing()
	if "--test_zonas" in args: _test_zonas.call_deferred()
	for a in args:
		if a.begins_with("--tira_lat="): _tira_lat(a.substr(11))
		if a.begins_with("--ataque_perfil="): _ataque_perfil(a.substr(16))
		if a.begins_with("--andan_lado="): _andan_lado(a.substr(13))
		if a.begins_with("--casa_cerrada="): _casa_cerrada(a.substr(15))
		if a.begins_with("--casa_tocon="): _casa_tocon(a.substr(13))
		if a.begins_with("--casa_deco="): _casa_tocon(a.substr(12).get_slice(",", 1), int(a.substr(12).get_slice(",", 0)))
		if a.begins_with("--medir_patina="): _medir_patina(a.substr(15))
		if a.begins_with("--andar_a_puerta="): _andar_a_puerta(a.substr(17))
		if a.begins_with("--medir_visible="): _medir_visible(a.substr(16))
		if a.begins_with("--vista_en="): _vista_en(a.substr(11))
		if a.begins_with("--andar_hacia="): _andar_hacia(a.substr(14))
		if a.begins_with("--camino_corral="): _camino_corral(a.substr(16))
		if a.begins_with("--plumas_rama="): _plumas_rama_cap(a.substr(14))
		if a.begins_with("--gif_lat="): _gif_lat(a.substr(10))
		if a.begins_with("--gif_p13="): _gif_p13(a.substr(10))
		if a.begins_with("--reposo_lat="): _reposo_lat(a.substr(13))
		if a.begins_with("--reposo_vs_andar="): _reposo_vs_andar(a.substr(18))
		if a.begins_with("--gif_parar="): _gif_parar(a.substr(12))
		if a.begins_with("--gif_hierba="): _gif_hierba(a.substr(13))
		if a.begins_with("--gif_flora="): _gif_flora(a.substr(12))
		if a.begins_with("--gif_equipo="): _gif_equipo(a.substr(13))
		if a.begins_with("--vista_mapa="): _vista_mapa(a.substr(13))
		if a.begins_with("--mosaico="): _mosaico(a.substr(10))
		if a.begins_with("--cap_comps="): _cap_comps(a.substr(12))
	if "--bruja_ui" in args: get_tree().create_timer(1.0).timeout.connect(func(): _bruja_ui())
	if "--pergamino" in args: get_tree().create_timer(1.0).timeout.connect(func(): _pergamino_ui())
	if "--test_claro" in args or "--test_claro_luz" in args:   # capturas del calco de escarcha: claro vacío (y farolillo encendido)
		if bosque_esc == null: start_raizal(); arpg["hojas"] = max(arpg["hojas"], 2); start_bosque()
		player.position = bosque_esc.CLARO_C + Vector2(-60, 170); tuto_vivo = false
		for e in enemies: e.queue_free()
		enemies.clear(); guard_vivos = 0
		if "--test_claro_luz" in args: get_tree().create_timer(0.8).timeout.connect(_encender_farolillo)
	recalc_stats()
	_crear_ui_raizal(ui)
	guia = Control.new(); guia.set_script(load("res://guia.gd")); ui.add_child(guia); ui.move_child(guia, 0)
	dialogo = Control.new(); dialogo.set_script(load("res://dialogo.gd")); ui.add_child(dialogo)
	if bot_on: dialogo.auto_t = 0.0

func _setup_inputs() -> void:
	# Volver: Esc, botón B del mando y "atrás" del móvil
	var vb_b := InputEventJoypadButton.new(); vb_b.button_index = JOY_BUTTON_B
	if not InputMap.action_has_event("ui_cancel", vb_b): InputMap.action_add_event("ui_cancel", vb_b)
	var vb_k := InputEventKey.new(); vb_k.keycode = KEY_BACK
	if not InputMap.action_has_event("ui_cancel", vb_k): InputMap.action_add_event("ui_cancel", vb_k)
	var map := {"izq": [KEY_A, KEY_LEFT], "der": [KEY_D, KEY_RIGHT], "arriba": [KEY_W, KEY_UP], "abajo": [KEY_S, KEY_DOWN]}
	var axes := {"izq": [JOY_AXIS_LEFT_X, -1.0], "der": [JOY_AXIS_LEFT_X, 1.0], "arriba": [JOY_AXIS_LEFT_Y, -1.0], "abajo": [JOY_AXIS_LEFT_Y, 1.0]}
	var dpad := {"izq": JOY_BUTTON_DPAD_LEFT, "der": JOY_BUTTON_DPAD_RIGHT, "arriba": JOY_BUTTON_DPAD_UP, "abajo": JOY_BUTTON_DPAD_DOWN}
	for a in map:
		InputMap.add_action(a, 0.2)
		for k in map[a]:
			var ev := InputEventKey.new(); ev.physical_keycode = k; InputMap.action_add_event(a, ev)
		var j := InputEventJoypadMotion.new(); j.axis = axes[a][0]; j.axis_value = axes[a][1]; InputMap.action_add_event(a, j)
		var b := InputEventJoypadButton.new(); b.button_index = dpad[a]; InputMap.action_add_event(a, b)
	# (sin impulso/dash: Francisco lo quitó en v202610191700; Espacio, clic derecho y B ya no hacen nada en juego)
	InputMap.add_action("reiniciar")
	for k in [KEY_ENTER, KEY_R, KEY_SPACE]:
		var ev := InputEventKey.new(); ev.physical_keycode = k; InputMap.action_add_event("reiniciar", ev)
	var jb := InputEventJoypadButton.new(); jb.button_index = JOY_BUTTON_A; InputMap.action_add_event("reiniciar", jb)
	InputMap.add_action("interactuar")   # Raizal: entrar por puertas y salidas
	for k in [KEY_E, KEY_ENTER, KEY_F]:
		var ev := InputEventKey.new(); ev.physical_keycode = k; InputMap.action_add_event("interactuar", ev)
	for bt in [JOY_BUTTON_A, JOY_BUTTON_X]:
		var ji := InputEventJoypadButton.new(); ji.button_index = bt; InputMap.action_add_event("interactuar", ji)
	var mb := InputEventMouseButton.new(); mb.button_index = MOUSE_BUTTON_LEFT; InputMap.action_add_event("reiniciar", mb)

func _volver_menu(p := "principal") -> void:
	_ocultar_ui_raizal(); limpiar_partida(); state = "menu"; menu.visible = true; menu.mostrar(p)
func _process(delta: float) -> void:
	t += delta
	if state == "menu":
		if shot_path != "" and t >= shot_at: get_viewport().get_texture().get_image().save_png(shot_path); shot_path = ""; get_tree().quit()
		return
	alive_time += delta
	# pulido 2 (23/10): fuera las ardillas de ambiente que salían de la nada cada 40-90 s fuera de Raizal (bosque, zonas,
	# Academia). Regla de Francisco: ningún animal aparece de golpe; solo quedan los colocados de adorno.
	if check_big:
		for e in get_children():
			for sp in e.find_children("*", "Sprite2D", true, false):
				if sp.is_visible_in_tree() and sp.get_global_transform().get_scale().x * sp.texture.get_width() > 300.0 and not String(sp.texture.resource_path).contains("popup"):
					print("BIG ", sp.texture.resource_path, " ", sp.get_global_transform().get_scale())
	if god: player.hp = player.max_hp
	if quieto and int(alive_time) != int(alive_time - delta): print("QUIETO t=%d hp=%.0f/%.0f vivos=%d golpes=%d" % [alive_time, player.hp, player.max_hp, enemies.size(), player.golpes_n])
	if shot_path != "" and alive_time >= shot_at:
		if player: print("SHOT pos=", player.position)
		get_viewport().get_texture().get_image().save_png(shot_path); shot_path = ""; get_tree().quit()
	enemies = enemies.filter(func(e): return is_instance_valid(e))
	_rehacer_egrid()
	if bot_on: _bot(delta)
	_ciclo(delta)
	if modo == "raizal": _raizal(delta)
	elif modo == "bosque": _bosque(delta)
	elif modo == "zona": _zona(delta)
	banner_t -= delta; aviso_banner.modulate.a = clamp(banner_t, 0.0, 1.0)
	_hud_actualizar()
	if player.hp < player.max_hp and st("regen") > 0: pass
	cam.position = cam.position.lerp(_cam_meta(), 1.0 - exp(-delta * 9.75))   # igual que 0,15 a 60 fps, pero sin tirones si varían los fps
	_zoom_mundo()
	shake_amt = lerp(shake_amt, 0.0, 0.15)
	cam.offset = Vector2(randf_range(-1, 1), randf_range(-1, 1)) * shake_amt

var toque_ini := Vector2.ZERO; var toque_ms := 0
func _input(e: InputEvent) -> void:
	# tocar (o hacer clic) sobre alguien cercano = hablar con él. Un toque corto y quieto: arrastrar sigue siendo andar
	if modo in ["raizal", "bosque", "zona"] and state == "jugando":
		var pos = null
		if e is InputEventScreenTouch and e.index == 0:
			if e.pressed: toque_ini = e.position; toque_ms = Time.get_ticks_msec()
			elif e.position.distance_to(toque_ini) < 18.0 and Time.get_ticks_msec() - toque_ms < 350: pos = e.position
		elif e is InputEventMouseButton and e.pressed and e.button_index == MOUSE_BUTTON_LEFT and e.device != InputEvent.DEVICE_ID_EMULATION: pos = e.position
		if pos != null and _tocar(pos): get_viewport().set_input_as_handled()

func _tocar(sp: Vector2) -> bool:
	if not modo in ["raizal", "zona"] or player == null: return false
	var w: Vector2 = get_viewport().get_canvas_transform().affine_inverse() * sp
	if dentro != "" and interior and interior.tocar(w): return true
	for h in _gente():
		var n: Node2D = h[0]
		if not Rect2(n.position + Vector2(-34, -n.alto - 10), Vector2(68, n.alto + 22)).has_point(w): continue
		if player.position.distance_to(n.position) > 260.0: return false
		npc_cerca = h; _usar_salida("hablar"); return true
	return false


func nearest_enemy(p: Vector2, maxd := 700.0, exclude := [], need_los := true):
	return nearest_enemy_ex(p, maxd * (1.0 + st("alcance")), exclude, need_los)

func nearest_enemy_ex(p: Vector2, maxd: float, exclude: Array, need_los := true):
	# el mas cercano CON LINEA DE VISION (los obstaculos bloquean los laseres)
	var best = null; var bd := maxd
	for e in (enemigos_cerca(p, maxd) if maxd < 1500.0 else enemies):
		if not is_instance_valid(e) or e.ally > 0.0: continue
		var d := p.distance_to(e.position + e.center)
		if d < bd and not exclude.has(e) and (not need_los or los(p, e.position + e.center)): bd = d; best = e   # distancia primero: la línea de visión es cara
	return best

# Rejilla espacial de enemigos (se rehace cada frame): consultas de cercanía O(vecinos) en vez de O(todos)
const ECELDA := 160.0
var _egrid := {}
func _rehacer_egrid() -> void:
	_egrid.clear()
	for e in enemies:
		var k := Vector2i(floor(e.position.x / ECELDA), floor(e.position.y / ECELDA))
		if _egrid.has(k): _egrid[k].append(e)
		else: _egrid[k] = [e]
func enemigos_cerca(p: Vector2, r: float) -> Array:
	var out: Array = []
	var x0 := int(floor((p.x - r) / ECELDA)); var x1 := int(floor((p.x + r) / ECELDA))
	var y0 := int(floor((p.y - r) / ECELDA)); var y1 := int(floor((p.y + r) / ECELDA))
	for cx in range(x0, x1 + 1):
		for cy in range(y0, y1 + 1):
			var k := Vector2i(cx, cy)
			if _egrid.has(k): out.append_array(_egrid[k])
	return out

func spawn_bullet(p: Vector2, dir: Vector2, dmg: float):
	var b := Node2D.new(); b.set_script(load("res://bullet.gd")); b.position = p
	b.vel = dir * 1100.0; b.dmg = dmg; add_child(b)
	return b

var _chispa := false
func damage_enemy(e, d: float, dir := Vector2.ZERO, can_crit := true, silent := false) -> void:
	if not is_instance_valid(e) or e.ally > 0.0: return
	if "es_planta" in e:   # p22: flora que ataca: su propia vida y defensa (planta.gd, data/flora_ataca.json); se calma un rato
		e.golpeada(dir, d, silent)
		return
	if comp_src: comp_dano += min(d, e.hp)
	if e.kind == 4: d *= 1.0 + st("dano_jefe")
	if pj == "lira" and player and e.position.distance_to(player.position) > 400: d *= 1.2
	var crit := false
	if can_crit:
		var cc := st("crit")
		if player and player.post_dash: crit = true; player.post_dash = false
		if crit or randf() < cc: crit = true; d *= 2.5 + st("crit_dano")
	if st("robo_vida") > 0 and player: player.curar(min(d * st("robo_vida"), 5.0))
	if not silent:
		e.hit_flash(dir)
		var hp_pos0: Vector2 = e.position + e.center
		FX.burst(self, hp_pos0 - dir * 10, Color(1, 0.9, 0.5) if crit else Color(1, 1, 0.8), 8, 320, 4)
		if crit: float_text(hp_pos0 + Vector2(0, -40), "¡%d!" % int(d), Color(1, 0.85, 0.2))
		hits += 1
		if pj == "pip" and hits % 5 == 0 and not _chispa:
			_chispa = true; chain_lightning(player.position + Vector2(0, -50), e, 10.0 * (1.0 + st("dano")), 3, false); _chispa = false
	if "d" in e and e.d is Dictionary and e.d.has("frontal") and player and e.estado != "recupera":   # p19: coraza frontal (Corchín)
		var fr: Array = e.d["frontal"]; var mira := Vector2(1 if e.mira_der else -1, 0)
		if abs(mira.angle_to(player.position - e.position)) < deg_to_rad(float(fr[1]) * 0.5): d *= 1.0 - float(fr[0])
	if "k_jefe_arma" in e: d *= e.k_jefe_arma(arma)   # p19: Bellotón (sala de pruebas): ajuste por arma, ver data/jefes.json
	var hp_pos: Vector2 = e.position + e.center
	if "corteza_hp" in e and e.corteza_hp > 0.0:   # p17: protección de corteza de la Esporina: se come el daño primero
		var ab: float = min(d, e.corteza_hp); e.corteza_hp -= ab; d -= ab
		if e.corteza_hp <= 0.0: e.quitar_corteza()
	e.hp -= d
	if e.hp <= 0 and is_instance_valid(e) and enemies.has(e) and modo in ["bosque", "zona"]: _calmado(e, hp_pos); return
func float_text(p: Vector2, txt: String, col: Color) -> void:
	var l := Label.new(); l.text = tr(txt); l.position = p - Vector2(60, 0); l.size = Vector2(120, 30); l.z_index = 20
	l.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER; l.add_theme_font_size_override("font_size", 24); l.add_theme_color_override("font_color", col)
	l.add_theme_color_override("font_outline_color", Color.BLACK); l.add_theme_constant_override("outline_size", 6); add_child(l)
	var tw := l.create_tween(); tw.tween_property(l, "position:y", p.y - 50, 0.6); tw.parallel().tween_property(l, "modulate:a", 0.0, 0.6).set_delay(0.3); tw.tween_callback(l.queue_free)

func chain_lightning(from: Vector2, first, dmg: float, jumps: int, slow: bool) -> void:
	var pts: Array = [from]; var hit: Array = []; var cur = first
	for i in jumps:
		if cur == null or not is_instance_valid(cur): break
		hit.append(cur); pts.append(cur.position + cur.center)
		var nxt = nearest_enemy_ex(cur.position, 300.0, hit, false)
		damage_enemy(cur, dmg, Vector2.ZERO)
		if slow and is_instance_valid(cur): cur.freeze(0.3)
		cur = nxt
	var fx := Node2D.new(); fx.set_script(load("res://rayo_fx.gd")); fx.pts = pts; add_child(fx)

func _touch_test() -> void:
	# simula un dedo arrastrando (con saltos raros) y un pellizco sobre el árbol
	await get_tree().create_timer(0.8).timeout
	var ev := func(e): Input.parse_input_event(e)
	var t := InputEventScreenTouch.new(); t.index = 0; t.position = Vector2(600, 350); t.pressed = true; ev.call(t)
	for i in 30:
		var d := InputEventScreenDrag.new(); d.index = 0; d.position = Vector2(600 + i * 25, 350 + i * 12); d.relative = Vector2(5000, 5000); ev.call(d)
		var m := InputEventMouseMotion.new(); m.device = InputEvent.DEVICE_ID_EMULATION; m.relative = Vector2(-9000, 4000); m.position = d.position; m.button_mask = MOUSE_BUTTON_MASK_LEFT; ev.call(m)
		await get_tree().process_frame
	t = InputEventScreenTouch.new(); t.index = 0; t.position = Vector2(1350, 710); t.pressed = false; ev.call(t)
	# pellizco para alejar al máximo
	for f in [0, 1]:
		var p := InputEventScreenTouch.new(); p.index = f; p.position = Vector2(640 + (f * 2 - 1) * 300, 360); p.pressed = true; ev.call(p)
	for i in 20:
		for f in [0, 1]:
			var d := InputEventScreenDrag.new(); d.index = f; d.position = Vector2(640 + (f * 2 - 1) * (300 - i * 14), 360); ev.call(d)
		await get_tree().process_frame
	for f in [0, 1]:
		var p := InputEventScreenTouch.new(); p.index = f; p.position = Vector2(640, 360); p.pressed = false; ev.call(p)
	print("TOUCH zoom/off ", get_tree().root.find_children("*", "Control", true, false).filter(func(c): return c.get_script() == load("res://arbol_ui.gd")).map(func(c): return [c.zoom, c.off]))

func ar(rama: String, i: int) -> bool: return Arbol.tiene_n(rama, i, pj)   # nodo i de la rama del árbol de cristal
func fury_mult() -> float:
	var m := 1.0
	if pj == "brontus" and player: m += 0.04 * floor((1.0 - player.hp / player.max_hp) * 10.0)
	return m

func shake(a: float) -> void: if Guardado.d.get("temblor", true): shake_amt = max(shake_amt, a)

# Ajustes > Sonido: tres buses independientes (ambiente del bosque, efectos de combate, voces y avisos) sobre el Master
const BUSES := {"Ambiente": "vol_amb", "Efectos": "vol_sfx", "Avisos": "vol_avisos"}
func _crear_buses() -> void:
	for b in BUSES:
		if AudioServer.get_bus_index(b) == -1:
			AudioServer.add_bus(); var i := AudioServer.bus_count - 1; AudioServer.set_bus_name(i, b); AudioServer.set_bus_send(i, "Master")
func _aplicar_volumen() -> void:
	var v: float = Guardado.d.get("vol", 0.8)
	AudioServer.set_bus_volume_db(0, linear_to_db(max(v, 0.0001))); AudioServer.set_bus_mute(0, v <= 0.01)
	for b in BUSES:
		var i := AudioServer.get_bus_index(b)
		if i < 0: continue
		var vb: float = float(Guardado.d.get(BUSES[b], 0.8)); AudioServer.set_bus_volume_db(i, linear_to_db(max(vb, 0.0001))); AudioServer.set_bus_mute(i, vb <= 0.01)
	FX.suave = not bool(Guardado.d.get("destellos", true))

var sala_prueba := false   # p19: sala de pruebas del jefe (--sala_jefe): no guarda y los desmayos no te sacan
var sala_nodo: Node = null
func _on_died() -> void:
	if sala_prueba and sala_nodo: sala_nodo.desmayo(); return
	if modo in ["bosque", "zona"]: _desmayo(); return
	# Raizal es segura; una muerte forzada vuelve al poblado con la aventura intacta.
	start_raizal("desmayo")


func popup_text(txt: String, col: Color) -> void:
	aviso_banner.text = tr(txt); aviso_banner.add_theme_color_override("font_color", col); banner_t = 1.6
	aviso_banner.add_theme_font_size_override("font_size", 30 if modo in ["raizal", "bosque"] else 44)


func _ring(p: Vector2, r: float, col: Color) -> void:
	var b := Node2D.new(); b.set_script(load("res://ring.gd")); b.position = p; b.r = r; b.col = col; add_child(b)

func echo_pulse(p: Vector2, r: float, dmg: float, stun := false) -> void:
	_ring(p + Vector2(0, -40), r, Color(1, 0.85, 0.35)); shake(4)
	for e in enemies.duplicate():
		if is_instance_valid(e) and e.position.distance_to(p) < r:
			e.knock = (e.position - p).normalized() * 600.0
			damage_enemy(e, dmg, (e.position - p).normalized())
			if stun and is_instance_valid(e): e.freeze(0.5)

func add_trail(p: Vector2, dps: float, rad := 30.0, life := 1.2) -> void:
	trails.append([p, life, dps, rad])

func _physics_process(delta: float) -> void:
	if state != "jugando": return
	for t_r in trails: t_r[1] -= delta
	trails = trails.filter(func(x): return x[1] > 0)
	if trails.is_empty(): return
	for e in enemies.duplicate():
		if not is_instance_valid(e): continue
		for t_r in trails:
			if e.position.distance_to(t_r[0]) < t_r[3]:
				damage_enemy(e, t_r[2] * delta * 4.0, Vector2.ZERO, false, true); break

func play_sfx(n: String, p: Vector2) -> void:
	var a := AudioStreamPlayer2D.new(); a.stream = sfx[n]; a.position = p; a.max_distance = 3000; a.bus = "Avisos" if n == "aviso" else "Efectos"
	if Guardado.d.get("senales", false) and n != "mejora":   # Ajustes > Señales visuales de sonido: los avisos también se ven
		float_text(p + Vector2(0, -70), "¡!" if n == "aviso" else tr("JUEGO_BUM"), Color(1, 0.85, 0.4))
	a.process_mode = Node.PROCESS_MODE_ALWAYS; add_child(a); a.play(); a.finished.connect(a.queue_free)

# --- Obstaculos solidos ---
# rejilla espacial de obstáculos (celdas de 256 px): cada consulta mira solo las 9 celdas vecinas en vez de todos los obstáculos
const CELDA := 256.0
var _rej := {}
var _rej_de: Array = []
func _cerca(p: Vector2) -> Array:
	if not is_same(_rej_de, obst):
		_rej = {}; _rej_de = obst
		for o in obst:
			var rr: float = o[1] + 160.0
			for cx in range(int(floor((o[0].x - rr) / CELDA)), int(floor((o[0].x + rr) / CELDA)) + 1):
				for cy in range(int(floor((o[0].y - rr) / CELDA)), int(floor((o[0].y + rr) / CELDA)) + 1):
					var key := Vector2i(cx, cy)
					if not _rej.has(key): _rej[key] = []
					_rej[key].append(o)
	return _rej.get(Vector2i(int(floor(p.x / CELDA)), int(floor(p.y / CELDA))), [])

func resolve(p: Vector2, r: float) -> Vector2:
	if dentro != "" and interior: return interior.resolver(p, r)
	if modo == "zona" and zona_n: return zona_n.resolver(p, r)
	for o in _cerca(p):
		var d: Vector2 = p - o[0]; var m: float = o[1] + r
		if d.length_squared() < m * m:
			p = o[0] + (d.normalized() if d.length() > 0.01 else Vector2.RIGHT) * m
	return p

func blocked(p: Vector2, r := 0.0) -> bool:
	for o in _cerca(p):
		if p.distance_to(o[0]) < o[1] + r: return true
	return false

func avoid(p: Vector2, want: Vector2, r: float) -> Vector2:
	# direccion deseada + rodeo tangencial de los obstaculos que hay delante
	if want.length() < 1.0: return want
	var spd := want.length(); var dir := want / spd; var steer := dir
	for o in _cerca(p):
		var d: Vector2 = o[0] - p; var dist := d.length(); var m: float = o[1] + r + 60.0
		if dist < m and dir.dot(d) > 0.0:
			var tang := d.orthogonal().normalized()
			if tang.dot(dir) < 0: tang = -tang
			var w: float = (m - dist) / m * 2.5
			steer += tang * w - d.normalized() * w * 0.4
	return steer.normalized() * spd

# fuente de modificadores (p7): cada estadística sabe de dónde viene cada trozo ([origen, valor]) para la pausa.
# «efectos» = modificadores temporales (positivos o negativos) que el juego podrá añadir más adelante (p. ej. el frío);
# por ahora no se añade ninguno. Formato: {"stat": "vel_mov", "valor": -0.1, "origen": "Escarcha"}
const TOPES := {"cadencia": 1.5, "dano": 1.5, "vel_mov": 0.6, "reduccion": 0.4, "crit": 0.4, "dash_cd": 0.6, "ralentizar": 0.5, "evasion": 0.3, "invuln": 0.6, "crit_dano": 1.5, "alcance": 0.5, "vel_bala": 0.8, "tam_bala": 0.8, "knock": 1.0, "dano_jefe": 0.5, "robo_vida": 0.10, "iman": 200.0, "suerte": 100.0, "vida_max": 200.0, "regen": 3.0}
var stats_de: Dictionary = {}
var efectos: Array = []
func _mod(sname: String, v: float, origen: String) -> void:
	if v == 0.0: return
	stats[sname] = stats.get(sname, 0.0) + v
	if not stats_de.has(sname): stats_de[sname] = []
	stats_de[sname].append([tr(origen), v])
func recalc_stats() -> void:
	stats = {}; stats_de = {}
	var arb: Dictionary = Arbol.stats()
	for sname in arb: _mod(sname, arb[sname], tr("JUEGO_ARBOL_CRISTAL"))
	for sname in Personajes.LISTA[pj]["mods"]: _mod(sname, Personajes.LISTA[pj]["mods"][sname], Personajes.LISTA[pj]["n"])
	if modo in ["raizal", "bosque", "zona"] and not arpg.is_empty():   # progreso ARPG del personaje: nivel y mejora del arma en la forja
		_mod("dano", 0.15 * arpg["arma_mas"], tr("JUEGO_FORJA_BRASAS"))
		_mod("dano", 0.04 * (arpg["nivel"] - 1), tr("JUEGO_NIVEL"))
		_mod("vida_max", 10.0 * (arpg["nivel"] - 1), tr("JUEGO_NIVEL"))
		for ob in Secretos.lista(arpg, "objetos"):   # objetos únicos de las zonas secretas
			if Secretos.OBJETOS.has(ob): _mod(Secretos.OBJETOS[ob]["stat"], Secretos.OBJETOS[ob]["v"], Secretos.OBJETOS[ob]["n"])
	for ef in efectos + (arpg.get("efectos", []) if not arpg.is_empty() else []): _mod(ef["stat"], ef["valor"], ef.get("origen", tr("JUEGO_EFECTO")))
	for sname in TOPES: if stats.has(sname): stats[sname] = min(stats[sname], TOPES[sname])
	if player:
		player.max_hp = max(20.0, 100.0 + st("vida_max")); player.hp = min(player.hp, player.max_hp)

func st(n: String) -> float: return stats.get(n, 0.0)

# p19: ¿se ve este punto en pantalla? (los enemigos no empiezan ataques fuera de ella; especificación BEST-A1-1.0)
func en_pantalla(p: Vector2, margen := 30.0) -> bool:
	if test_mode and get_viewport() == null: return true
	var r: Rect2 = get_viewport().get_canvas_transform().affine_inverse() * get_viewport().get_visible_rect()
	return r.grow(-margen).has_point(p)

func los(a: Vector2, b: Vector2) -> bool:
	# segmento a-b contra cada circulo de obstaculo
	var ab := b - a; var l2 := ab.length_squared()
	var n: int = int(sqrt(l2) / (CELDA * 0.5)) + 1   # p21: solo las celdas por las que pasa (el bosque tiene miles de círculos)
	for i in n + 1:
		for o in _cerca(a + ab * (float(i) / n)):
			var c: Vector2 = o[0]; var r: float = o[1] - 6.0
			var t: float = 0.0 if l2 == 0.0 else clamp((c - a).dot(ab) / l2, 0.0, 1.0)
			if (a + ab * t).distance_squared_to(c) < r * r: return false
	return true

# (19/10) Minijuego «Busca tu Compañero» eliminado (mapa, entrada del Corral, textos). Los compañeros siguen en el código, dormidos (COMPANEROS_ACTIVOS).

# Limpieza completa entre mapas y partidas: todo lo que nace durante una partida cuelga de main
# y se libera aquí; los nodos fijos (cámara, UI, audio, rastro, escenario, jugador) se conservan.
const _FIJOS := ["res://trail.gd", "res://player.gd"]
func limpiar_partida() -> void:
	for c in get_children():
		if c == player or c == cam or c is CanvasLayer or c is AudioStreamPlayer or c.name == "Escenario": continue
		var sc = c.get_script()
		if sc != null and sc.resource_path in _FIJOS: continue
		if c is Timer: continue
		c.queue_free()
	enemies.clear(); trails.clear()
	banner_t = 0.0; aviso_banner.modulate.a = 0.0
	shake_amt = 0.0
	if check_fugas: get_tree().process_frame.connect(func(): print("FUGAS tras limpiar: ", _contar_restos()), CONNECT_ONE_SHOT)
var check_fugas := "--fugas" in OS.get_cmdline_user_args()
func _contar_restos() -> int:
	var n := 0
	for c in get_children():
		if c == player or c == cam or c is CanvasLayer or c is AudioStreamPlayer or c.name == "Escenario" or c is Timer: continue
		var sc = c.get_script()
		if sc != null and sc.resource_path in _FIJOS: continue
		n += 1
	return n

# compañeros conocidos (dormido: se conserva para cuando vuelvan los compañeros)
static func conocidos_comp(nuevo := "") -> Array:
	var l: Array = (Guardado.d.get("comp_conocidos", []) as Array).duplicate()
	var eq := str(Guardado.d.get("companero", ""))
	for k in [eq, nuevo]: if Companeros.TIPOS.has(k) and not (k in l): l.append(k)
	return l

# HUD de la aventura: personaje, vida, experiencia, encargo y recursos.
var hud_izq: PanelContainer
var hud_nombre: Label
var hud_vida_t: Label
var hud_xp_t: Label
var hud_centro: PanelContainer
var hud_zona: Label
var hud_encargo: PanelContainer
var enc_nombre: Label; var enc_paso: Label; var enc_opc: Label; var enc_flecha: TextureRect
var enc_ult := ""
var hud_ola: Label
var hud_abajo: Label
var hud_raiz: Control
var hud_avatar: Control
var hud_avatar_pj := ""
func _hud_panel(cm := 10.0) -> PanelContainer:
	var p := PanelContainer.new(); var sb := Estilo.caja(Color(0.06, 0.17, 0.17, 0.82), Color(0.86, 0.73, 0.46, 0.38), 10, cm); p.add_theme_stylebox_override("panel", sb)
	p.mouse_filter = Control.MOUSE_FILTER_IGNORE; return p
func _barra(col: Color, alto: float) -> ProgressBar:
	var b := ProgressBar.new(); b.show_percentage = false; b.custom_minimum_size = Vector2(0, alto); b.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	var f := Estilo.caja(col, Color(0, 0, 0, 0), 4, 0.0, 0); b.add_theme_stylebox_override("fill", f)
	var g := Estilo.caja(Color(0.02, 0.07, 0.07, 0.9), Color(0.86, 0.73, 0.46, 0.2), 4, 0.0); b.add_theme_stylebox_override("background", g)
	b.mouse_filter = Control.MOUSE_FILTER_IGNORE; return b
func _hud_crear(ui: CanvasLayer) -> void:
	hud_raiz = Control.new(); hud_raiz.position = Vector2.ZERO; hud_raiz.mouse_filter = Control.MOUSE_FILTER_IGNORE; ui.add_child(hud_raiz)
	hud_izq = _hud_panel(); hud_izq.position = Vector2(14, 12); hud_izq.custom_minimum_size = Vector2(300, 0); hud_raiz.add_child(hud_izq)
	var hh := HBoxContainer.new(); hh.add_theme_constant_override("separation", 10); hud_izq.add_child(hh)
	hud_avatar = Control.new(); hud_avatar.custom_minimum_size = Vector2(52, 52); hud_avatar.mouse_filter = Control.MOUSE_FILTER_IGNORE; hh.add_child(hud_avatar)
	var vb := VBoxContainer.new(); vb.add_theme_constant_override("separation", 3); vb.size_flags_horizontal = Control.SIZE_EXPAND_FILL; hh.add_child(vb)
	hud_nombre = Estilo.texto(tr("JUEGO_ECO_NIVEL_1"), 17, Estilo.CREMA); hud_nombre.add_theme_font_override("font", Estilo.negrita()); vb.add_child(hud_nombre)
	var h1 := HBoxContainer.new(); h1.add_theme_constant_override("separation", 8); vb.add_child(h1)
	hp_bar = _barra(Color(0.85, 0.38, 0.33), 12); h1.add_child(hp_bar)
	hud_vida_t = Estilo.texto("100 / 100", 14, Estilo.CREMA); hud_vida_t.custom_minimum_size.x = 76; hud_vida_t.horizontal_alignment = HORIZONTAL_ALIGNMENT_RIGHT; h1.add_child(hud_vida_t)
	var h2 := HBoxContainer.new(); h2.add_theme_constant_override("separation", 8); vb.add_child(h2)
	xp_bar = _barra(Estilo.ORO, 7); h2.add_child(xp_bar); xp_bar.size_flags_vertical = Control.SIZE_SHRINK_CENTER
	hud_xp_t = Estilo.texto("0 / 5", 12, Estilo.SUAVE); hud_xp_t.custom_minimum_size.x = 76; hud_xp_t.horizontal_alignment = HORIZONTAL_ALIGNMENT_RIGHT; h2.add_child(hud_xp_t)
	hud_centro = _hud_panel(8.0); hud_raiz.add_child(hud_centro)
	var vc := VBoxContainer.new(); vc.add_theme_constant_override("separation", 0); hud_centro.add_child(vc)
	hud_zona = Estilo.texto(tr("JUEGO_BOSQUE_2"), 19, Estilo.CREMA); hud_zona.add_theme_font_override("font", Estilo.serif()); hud_zona.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER; vc.add_child(hud_zona)
	hud_ola = Estilo.texto(tr("JUEGO_POBLADO_GRAN_ARBOL_ZONA_SEGURA"), 13, Estilo.SUAVE); hud_ola.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER; vc.add_child(hud_ola)
	# seguimiento del encargo activo (p7): madera y pergamino, arriba; tocar/clic = flecha guía sí/no (se guarda)
	hud_encargo = PanelContainer.new(); hud_encargo.add_theme_stylebox_override("panel", Madera.caja(-4.0)); hud_encargo.mouse_filter = Control.MOUSE_FILTER_STOP
	hud_encargo.mouse_default_cursor_shape = Control.CURSOR_POINTING_HAND; hud_raiz.add_child(hud_encargo)
	var eh := HBoxContainer.new(); eh.add_theme_constant_override("separation", 10); eh.mouse_filter = Control.MOUSE_FILTER_IGNORE; hud_encargo.add_child(eh)
	var ev := VBoxContainer.new(); ev.add_theme_constant_override("separation", 0); ev.mouse_filter = Control.MOUSE_FILTER_IGNORE; eh.add_child(ev)
	enc_nombre = Madera.texto("", 17, Madera.TINTA, true); ev.add_child(enc_nombre)
	enc_paso = Madera.texto("", 14, Madera.TINTA2); ev.add_child(enc_paso)
	enc_opc = Madera.texto("", 13, Color(0.24, 0.45, 0.2)); ev.add_child(enc_opc)
	enc_flecha = TextureRect.new(); enc_flecha.texture = load("res://assets/ui/flecha_guia.png"); enc_flecha.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
	enc_flecha.custom_minimum_size = Vector2(30, 30); enc_flecha.size_flags_vertical = Control.SIZE_SHRINK_CENTER; enc_flecha.mouse_filter = Control.MOUSE_FILTER_IGNORE; eh.add_child(enc_flecha)
	var tacha := Line2D.new(); tacha.name = "Tacha"; tacha.points = PackedVector2Array([Vector2(4, 26), Vector2(26, 4)]); tacha.width = 3.5; tacha.default_color = Color(0.62, 0.2, 0.12); enc_flecha.add_child(tacha)
	hud_encargo.gui_input.connect(func(ev2: InputEvent):
		if (ev2 is InputEventMouseButton and ev2.pressed and ev2.button_index == MOUSE_BUTTON_LEFT) or (ev2 is InputEventScreenTouch and ev2.pressed):
			_flecha_cambiar(); hud_encargo.accept_event())
	hud_encargo.visible = false
	var pa := _hud_panel(8.0); pa.name = "Abajo"; hud_raiz.add_child(pa)
	var sb: StyleBoxFlat = pa.get_theme_stylebox("panel"); sb.set_corner_radius_all(16)
	hud_abajo = Estilo.texto(tr("JUEGO_0_ORO_0_CRIATURAS_CALMADAS"), 15, Estilo.CREMA); pa.add_child(hud_abajo)
	hud_raiz.visible = false
	# HUD D2 (maqueta A): bolas de vida y rocío, retrato, nivel, huecos, experiencia y fila de objetos. Sustituye al panel
	# de arriba a la izquierda (vida/experiencia) y a la línea de oro de abajo, que se quedan sin mostrar.
	hud_izq.visible = false; pa.visible = false
	hud_d2 = Control.new(); hud_d2.set_script(load("res://hud_d2.gd")); hud_d2.visible = false; ui.add_child(hud_d2)
var hud_d2: Control
var esc_hud := 1.0   # escala del HUD de juego (con la cámara alejada el HUD de antes quedaba demasiado grande)
const ESC_HUD_H := 0.78   # PC y móvil horizontal
const ESC_HUD_V := 0.74   # móvil vertical (encima del ×1,65 general de la interfaz en vertical)
var hud_clave_ult := ""
func _hud_actualizar() -> void:
	var vs: Vector2 = get_viewport().get_visible_rect().size; var vert: bool = vs.y > vs.x
	esc_hud = ESC_HUD_V if vert else ESC_HUD_H
	hud_raiz.scale = Vector2.ONE * esc_hud; hud_raiz.size = vs / esc_hud; vs = vs / esc_hud
	hud_raiz.visible = state in ["jugando", "pausa"]
	if hud_avatar_pj != pj:   # retrato del personaje en el panel de arriba a la izquierda
		hud_avatar_pj = pj
		for c in hud_avatar.get_children(): c.queue_free()
		var r := Estilo.retrato(pj, 52.0); r.position = Vector2.ZERO; r.size = Vector2(52, 52); hud_avatar.add_child(r)
	hp_bar.max_value = player.max_hp; hp_bar.value = player.hp; hud_vida_t.text = "%d / %d" % [int(ceil(player.hp)), int(player.max_hp)]
	xp_bar.get_parent().visible = true
	if modo in ["raizal", "bosque", "zona"]:
		hud_nombre.text = tr("JUEGO_NIVEL_3") % [tr(Personajes.LISTA[pj]["n"]), arpg["nivel"]]; xp_bar.get_parent().visible = true
		xp_bar.max_value = Arpg.xp_nivel(arpg["nivel"]); xp_bar.value = arpg["xp"]; hud_xp_t.text = "%d / %d" % [arpg["xp"], Arpg.xp_nivel(arpg["nivel"])]
		var abajo_t: String = tr("JUEGO_ORO_CASCARAS_BELLOTA") % [Estilo.miles(arpg["oro"]), arpg["cascaras"]]
		if int(arpg.get("esporas", 0)) > 0: abajo_t += tr("JUEGO_ESPORAS") % int(arpg["esporas"])
		if arpg["arma_mas"] > 0: abajo_t += " · %s +%d" % [Armas.n(arma), arpg["arma_mas"]]
		hud_abajo.text = abajo_t
	if modo == "raizal":
		hud_zona.text = tr("JUEGO_RAIZAL"); hud_ola.text = tr("JUEGO_POBLADO_GRAN_ARBOL_ZONA_SEGURA")
	elif modo == "bosque":
		hud_zona.text = tr("JUEGO_BOSQUE_SUSURRANTE")
		hud_ola.text = (tr("JUEGO_CALMA_BICHOS_CLARO") % [guard_tot - guard_vivos, guard_tot]) if arpg["hojas"] == 2 and guard_vivos > 0 else (tr("JUEGO_ENCIENDE_FAROLILLO_RAIZ") if arpg["hojas"] == 2 else tr("JUEGO_BOSQUE_POQUITO_MAS_CALENTITO"))
	elif modo == "zona" and zona_n:
		hud_zona.text = tr("JUEGO_REFUGIO_BRUJA") if zona_id == "refugio" else tr(Secretos.ZONAS[zona_id]["n"])
		hud_ola.text = tr("JUEGO_ZONA_SEGURA") if zona_n.segura else tr("JUEGO_ZONA_SECRETA")
	# HUD D2: bolas, nivel, experiencia y fila de objetos (iconos con número, sin palabras)
	hud_d2.visible = hud_raiz.visible
	if hud_d2.visible and modo in ["raizal", "bosque", "zona"]:
		var items: Array = []
		items.append(["res://assets/ui/pausa/ico_oro_v2.png", Estilo.miles(arpg["oro"])])
		items.append(["res://assets/ui/hud/ico_cascara_v2.png", str(arpg["cascaras"])])
		if int(arpg.get("esporas", 0)) > 0: items.append(["res://assets/ui/hud/ico_esporas.png", str(int(arpg["esporas"]))])
		if te_activo and modo == "bosque": items.append(["res://assets/ui/hud/ico_te.png", ""])
		if arpg["arma_mas"] >= 1: items.append(["res://assets/ui/pausa/ico_arma.png", "+%d" % arpg["arma_mas"]])
		hud_d2.actualizar(player.hp, player.max_hp, arpg["nivel"], float(arpg["xp"]) / max(1.0, float(Arpg.xp_nivel(arpg["nivel"]))), pj, items)
	# colocación
	hud_izq.custom_minimum_size.x = 330.0 if vert else 360.0
	var enc: Array = _encargo() if modo in ["raizal", "bosque", "zona"] and not arpg.is_empty() else []
	hud_encargo.visible = not enc.is_empty(); hud_centro.visible = enc.is_empty()
	if not enc.is_empty():
		enc_nombre.text = tr(enc[0]); enc_paso.text = tr(enc[1]); enc_opc.text = tr(enc[2]); enc_opc.visible = enc[2] != ""
		var on: bool = flecha_on()
		enc_flecha.modulate = Color.WHITE if on else Color(0.55, 0.5, 0.42, 0.75); enc_flecha.get_node("Tacha").visible = not on
		var clave: String = "%s|%s|%s" % enc
		if clave != enc_ult:
			enc_ult = clave
			if bot_on or test_mode: print("ENCARGO «%s» · %s%s" % [enc[0], enc[1], (" · " + enc[2]) if enc[2] != "" else ""])
	# colocación: solo si ha cambiado algo (antes se recalculaba todo el HUD en cada fotograma)
	var clave_hud := "%s|%s|%s|%s|%s|%s|%s|%s|%s" % [vs, vert, enc, hud_nombre.text, hud_abajo.text, hud_ola.text, hud_zona.text, hud_encargo.visible, enc_opc.visible]
	if clave_hud == hud_clave_ult: return
	hud_clave_ult = clave_hud
	if not enc.is_empty():
		hud_encargo.reset_size()
		hud_encargo.position = Vector2((vs.x - hud_encargo.size.x) / 2.0, 8) if not vert else Vector2(vs.x - 14 - hud_encargo.size.x, 12 + 62)
	hud_centro.reset_size()
	hud_centro.position = Vector2((vs.x - hud_centro.size.x) / 2.0, 12) if not vert else Vector2(vs.x - 14 - hud_centro.size.x, 12 + 62)
	var ab: Control = hud_raiz.get_node("Abajo"); ab.reset_size(); ab.position = Vector2(14, vs.y - ab.size.y - 14)

# En vertical, el "expand" deja un lienzo lógico de 1280 px de ancho (la UI se vería diminuta en un móvil):
# se amplía todo el lienzo y la cámara se aleja lo mismo, así el mundo se ve igual y la UI a tamaño legible.
var _esc_ui := 1.0
func _ajustar_escala() -> void:
	var w: Vector2i = get_window().size
	var k: float = 1.65 if w.y > w.x else 1.0
	if OS.is_debug_build() and "--dbg_escala" in OS.get_cmdline_user_args(): print("ESCALA ", w, " k=", k)
	if is_equal_approx(k, _esc_ui) and get_window().content_scale_factor == k: return
	_esc_ui = k; get_window().content_scale_factor = k
	if cam: _zoom_mundo()
	if menu and menu.visible: menu.call_deferred("mostrar", menu.pantalla)

# ===================== RAIZAL (ARPG, sprint 1) =====================
# Poblado del Gran Árbol: zona segura para pasear. Salidas: Árbol de Cristal,
# Puerta del Bosque (próximamente) y Puerta de la Corteza (Academia, cerrada). Habitantes con una frase provisional.
func _limites_cam() -> void:
	cam.limit_left = int(arena.position.x); cam.limit_top = int(arena.position.y); cam.limit_right = int(arena.end.x); cam.limit_bottom = int(arena.end.y)
func _zoom_mundo() -> void:
	# mismas unidades de mundo en el lado corto de la pantalla en PC, móvil vertical y horizontal
	if cam == null: return
	var vs: Vector2 = get_viewport().get_visible_rect().size
	var S: float = S_EXPLORA
	# p21: durante la pelea con Bellotón la cámara se aleja poco a poco hasta que su arena cabe entera, y al acabar vuelve
	var S_obj: float = S
	if jefe_vista.has_area():
		S_obj = max(S, min(vs.x, vs.y) / min(vs.x / (jefe_vista.size.x * 1.06), vs.y / (jefe_vista.size.y * 1.06))); _s_suave = true
	if _s_suave:
		if _s_cam <= 0.0: _s_cam = S
		_s_cam = lerp(_s_cam, S_obj, 1.0 - exp(-get_process_delta_time() * 2.5))
		if not jefe_vista.has_area() and abs(_s_cam - S_obj) < 2.0: _s_suave = false; _s_cam = S_obj
		S = _s_cam
	else: _s_cam = S
	cam.zoom = Vector2.ONE * (min(vs.x, vs.y) / S)
	if zoom_fijo != Vector2.ZERO: cam.zoom = zoom_fijo; return   # solo capturas de prueba (p14: zoom de la puerta)
	if vista_total: cam.zoom = Vector2.ONE * min(vs.x / arena.size.x, vs.y / arena.size.y); return
	if dentro != "":   # la sala ocupa casi toda la pantalla (85-90 %), sin hacer al niño diminuto en vertical
		var cabe: float = 0.88 * min(vs.x / Interior.TAM.x, vs.y / Interior.TAM.y)
		cam.zoom = Vector2.ONE * max(cabe, min(vs.x, vs.y) / S * 0.95)

func start_raizal(desde := "") -> void:
	if modo in ["bosque", "zona"] and not arpg.is_empty(): arpg_guardar()
	limpiar_partida(); modo = "raizal"; companero = null; bosque_esc = null; zona_n = null; zona_id = ""; lento_jug = 0.0
	for e in enemies: if is_instance_valid(e): e.queue_free()
	enemies.clear(); trails.clear(); stats = {}; get_tree().paused = false
	pj = Personajes.valido(Guardado.d.get("personaje", "echo"))
	if not Personajes.desbloqueado(pj) and not test_mode: pj = "echo"
	arma = Personajes.LISTA[pj]["arma"]; arma_nv = 1; kills = 0
	if has_node("Escenario"): var old := get_node("Escenario"); remove_child(old); old.queue_free()
	if interior: interior.queue_free(); interior = null
	dentro = ""; puerta_guarda = 0.0; puerta_armada = true
	arena = Raizal.ARENA; _limites_cam()
	obst = Raizal.build(self); raizal_esc = get_node("Escenario")
	RenderingServer.set_default_clear_color(Color(0.05, 0.07, 0.06))
	if player: player.queue_free()
	player = Node2D.new(); player.set_script(load("res://player.gd")); add_child(player)
	player.died.connect(_on_died)
	player.position = Vector2(0, 650) if shot_pos == Vector2.INF or desde != "" else shot_pos
	if desde == "bosque": player.position = Raizal.PUERTA_BOSQUE + Vector2(0, -210)
	if desde == "tuneles": player.position = Raizal.CASAS_DECO[Raizal.PIEDRA_DECO][1] + Vector2(0, 72)
	if shot_mira != "": player.mira = _vec_mira(shot_mira)
	else: player.mira = Vector2.DOWN   # de frente a la cámara al llegar, al volver y tras desmayarse
	cam.position = player.position; cam.reset_smoothing()
	alive_time = 0.0; state = "jugando"
	arpg = Arpg.de(pj); saludo_hecho = false
	if "--etapa" in str(OS.get_cmdline_user_args()):
		for a in OS.get_cmdline_user_args(): if a.begins_with("--etapa="): arpg["hojas"] = int(a.split("=")[1])
	recalc_stats(); player.max_hp = 100.0 + st("vida_max"); player.hp = player.max_hp
	_estado_raizal()
	_args_secretos()
	if Secretos.tiene(arpg, "pistas", "tuneles"): raizal_esc.abrir_piedra(); _rej_de = []
	if desde == "tuneles":   # se sube por la trampilla: de vuelta dentro de la casa de piedra, junto a ella
		for pu in raizal_esc.puertas: if pu[0] == "piedra": _entrar_ya(pu)
		if interior: player.position = interior.resolver(interior.trampilla_pos() + Vector2(80, 50), 16.0); tram_t = 1.0
		cam.position = _cam_meta(); cam.reset_smoothing()
	if "--sin_flecha" in OS.get_cmdline_user_args(): Guardado.d["flecha_guia"] = false
	for a in OS.get_cmdline_user_args():   # capturas: --demo_dialogo=plumas abre esa conversación al llegar
		if a.begins_with("--demo_dialogo="): saludo_hecho = true; get_tree().create_timer(1.0).timeout.connect(func(): _conversar(a.split("=")[1]))
	_zoom_mundo()
	var forzar_tip: bool = "--tip" in OS.get_cmdline_user_args()
	if desde == "" and (forzar_tip or (not Guardado.d.get("tip_controles", false) and not test_mode and shot_path == "")): _tip_controles()

# consejo de controles: una sola vez, al llegar a Raizal por primera vez. Discreto (arriba, se va solo), sin teclas de diálogo.
func _tip_controles() -> void:
	Guardado.d["tip_controles"] = true; Guardado.guardar()
	var tactil := DisplayServer.is_touchscreen_available() or "--tactil" in OS.get_cmdline_user_args()
	var mando := not Input.get_connected_joypads().is_empty()
	var l1 := tr("JUEGO_ARRASTRA_DEDO_PARA_ANDAR") if tactil else (tr("JUEGO_MUEVE_STICK_PARA_ANDAR") if mando else tr("JUEGO_MUEVETE_WASD_O_FLECHAS"))
	var pc := PanelContainer.new(); pc.name = "TipControles"; pc.mouse_filter = Control.MOUSE_FILTER_IGNORE
	pc.add_theme_stylebox_override("panel", Estilo.caja(Color(0.05, 0.14, 0.14, 0.8), Color(0.86, 0.73, 0.46, 0.4), 18, 10.0))
	var vb := VBoxContainer.new(); vb.add_theme_constant_override("separation", 2); pc.add_child(vb)
	for t in [[l1, 18, Estilo.CREMA], [tr("JUEGO_ACERCATE_ALGUIEN_PARA_HABLAR"), 15, Estilo.SUAVE], [tr("JUEGO_ARMA_DISPARA_SOLA"), 15, Estilo.SUAVE]]:
		var l := Estilo.texto(t[0], t[1], t[2]); l.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER; vb.add_child(l)
	ui_capa.add_child(pc); pc.modulate.a = 0.0
	await get_tree().process_frame
	if not is_instance_valid(pc): return
	var v := get_viewport().get_visible_rect().size
	pc.reset_size(); pc.position = Vector2((v.x - pc.size.x) / 2.0, v.y * 0.17)
	var tw := pc.create_tween(); tw.tween_property(pc, "modulate:a", 1.0, 0.5).set_delay(0.6); tw.tween_interval(7.0); tw.tween_property(pc, "modulate:a", 0.0, 0.8); tw.tween_callback(pc.queue_free)
func _vec_mira(d: String) -> Vector2:
	var i: int = ["este", "sureste", "sur", "suroeste", "oeste", "noroeste", "norte", "noreste"].find(d)
	return Vector2.from_angle(i * PI / 4.0) if i >= 0 else Vector2.UP

func _crear_ui_raizal(ui: CanvasLayer) -> void:
	ui_accion = Madera.boton(tr("JUEGO_ENTRAR"), false, 13); ui_accion.visible = false; ui_accion.focus_mode = Control.FOCUS_NONE; ui_accion.custom_minimum_size = Vector2(0, 30)
	ui.add_child(ui_accion); ui_accion.pressed.connect(func(): _usar_salida(salida_cerca))
	ui_burbuja = PanelContainer.new(); ui_burbuja.mouse_filter = Control.MOUSE_FILTER_IGNORE; ui_burbuja.visible = false
	ui_burbuja.add_theme_stylebox_override("panel", Estilo.caja(Color(0.98, 0.94, 0.84, 0.95), Color(0.55, 0.38, 0.2, 0.9), 10, 7.0, 2))
	ui_burbuja_l = Label.new(); ui_burbuja_l.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART; ui_burbuja_l.custom_minimum_size = Vector2(240, 0)
	ui_burbuja_l.add_theme_color_override("font_color", Color(0.18, 0.12, 0.06)); ui_burbuja_l.add_theme_font_size_override("font_size", 13)
	ui_burbuja.add_child(ui_burbuja_l); ui.add_child(ui_burbuja); ui.move_child(ui_burbuja, 0)
	# aviso para hablar (p7): bocadillo pequeño que flota y se mece sobre la cabeza de quien está cerca, con su nombre debajo
	ui_aviso = Control.new(); ui_aviso.mouse_filter = Control.MOUSE_FILTER_IGNORE; ui_aviso.visible = false; ui.add_child(ui_aviso); ui.move_child(ui_aviso, 0)
	var ic := TextureRect.new(); ic.name = "Icono"; ic.texture = load("res://assets/ui/burbuja_hablar.png"); ic.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
	ic.custom_minimum_size = Vector2(34, 34); ic.size = Vector2(34, 34); ic.position = Vector2(-17, -34); ic.mouse_filter = Control.MOUSE_FILTER_IGNORE; ui_aviso.add_child(ic)
	ui_aviso_l = Madera.texto("", 12, Madera.CREMA, true); ui_aviso_l.add_theme_color_override("font_outline_color", Color(0.18, 0.1, 0.04)); ui_aviso_l.add_theme_constant_override("outline_size", 5)
	ui_aviso_l.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER; ui_aviso.add_child(ui_aviso_l)
	fundido = ColorRect.new(); fundido.color = Color(0.02, 0.02, 0.03, 0.0); fundido.mouse_filter = Control.MOUSE_FILTER_IGNORE
	fundido.set_anchors_preset(Control.PRESET_FULL_RECT); ui.add_child(fundido)

var ui_aviso: Control
var ui_aviso_l: Label
var hablando = null       # [nodo, nombre, frase] del habitante con el que se habla
var hablar_hasta := 0.0
var npc_cerca = null
func _raizal(_delta: float) -> void:
	_guia_raizal()
	if state != "jugando": ui_accion.visible = false; ui_aviso.visible = false; return
	_martillo(_delta)
	# guion de Francisco: sin escena forzada. Cerca de la plaza (o a los pocos segundos) cae una hoja escarchada a tus pies
	if arpg["hojas"] == 0 and not saludo_hecho and dentro == "" and alive_time > 1.5 and (player.position.distance_to(PLAZA) < 200.0 or alive_time > 8.0):
		saludo_hecho = true; _hoja_escarcha(); return
	var vs: Vector2 = get_viewport().get_visible_rect().size; var vert: bool = vs.y > vs.x
	var ct: Transform2D = get_viewport().get_canvas_transform()
	# UNA sola forma de interactuar: acercarse + E / botón A / botón en pantalla ("Hablar" o "Entrar")
	salida_cerca = ""; npc_cerca = null
	if _puertas(): return   # pack 2: se entra y se sale de las casas andando contra la puerta
	if _trampilla(_delta): return
	var md := 170.0; var dn := 170.0
	for h in _gente():
		var d: float = player.position.distance_to(h[0].position)
		if String(h[3]).begins_with("v:"): d += 50.0   # los vecinos de ambiente, solo si estás muy cerca (no tapan a los PNJ)
		if d < md: md = d; npc_cerca = h; dn = player.position.distance_to(h[0].position)
	if npc_cerca == null:
		if dentro == "":
			for sd in Raizal.SALIDAS:
				if player.position.distance_to(sd[2]) < sd[3]: salida_cerca = sd[0]; ui_accion.text = sd[1]; accion_en = sd[2] + Vector2(0, -150)
	else:
		salida_cerca = "hablar"
	if dentro != "" and interior:
		var mueble := interior.accion(player.position)
		if not mueble.is_empty() and player.position.distance_to(mueble["pie"] * Interior.DS) < dn:   # un mueble solo gana si está más cerca que la persona (Tobías junto a la forja)
			npc_cerca = null; salida_cerca = "mueble:" + mueble["id"]
			ui_accion.text = tr({"asiento": "INT_SENTARSE", "cama": "INT_DORMIR", "baul": "INT_ABRIR_BAUL"}[mueble["tipo"]])
			accion_en = mueble["pos"] * Interior.DS + Vector2(0, -95)
	if hablando != null and (t > hablar_hasta or player.position.distance_to(hablando[0].position) > 260.0): hablando = null
	# hablar: bocadillo flotante sobre la cabeza (sin tecla ni texto largo). Otras acciones: cartelito de madera sobre el sitio
	ui_aviso.visible = npc_cerca != null and state == "jugando" and not (hablando != null and hablando == npc_cerca)
	if ui_aviso.visible:
		var nd: Node2D = npc_cerca[0]
		var nom: String = String(npc_cerca[1]).split(",")[0]
		ui_aviso_l.text = tr(nom); ui_aviso_l.reset_size(); ui_aviso_l.position = Vector2(-ui_aviso_l.size.x / 2.0, 0)
		ui_aviso.position = ct * (nd.position + Vector2(0, -nd.alto - 12.0)) + Vector2(0, sin(t * 3.2) * 4.0 - 16.0)
	ui_accion.visible = salida_cerca != "" and salida_cerca != "hablar" and state == "jugando"
	if ui_accion.visible: _poner_accion(ct, vs)
	if (Input.is_action_just_pressed("interactuar") or (usar_test and alive_time > 1.0)) and salida_cerca != "" and t - fin_dialogo_t > 0.3:
		usar_test = false; _usar_salida(salida_cerca); return
	if usar_test and alive_time > 1.0: usar_test = false
	# burbuja: encima del habitante, apartada del jugador para no taparlo, y dentro de la pantalla
	ui_burbuja.visible = hablando != null
	if hablando != null:
		ui_burbuja_l.text = "%s\n%s" % [tr(hablando[1]), tr(hablando[2])]
		ui_burbuja_l.custom_minimum_size.x = min(230.0, vs.x - 40.0); ui_burbuja.reset_size()
		var bs: Vector2 = ui_burbuja.size
		var cabeza: Vector2 = ct * (hablando[0].position + Vector2(0, -hablando[0].alto - 14.0))
		var pos := Vector2(cabeza.x - bs.x / 2.0, cabeza.y - bs.y)
		var pj_pies: Vector2 = ct * player.position; var pj_cab: Vector2 = ct * (player.position + Vector2(0, -player.alto * 1.05))
		var pj_r := Rect2(pj_cab - Vector2(30, 6), Vector2(60, pj_pies.y - pj_cab.y + 12))
		if Rect2(pos, bs).intersects(pj_r):   # taparía al jugador: se aparta hacia el lado contrario
			pos.x = (pj_r.position.x - bs.x - 10.0) if pj_pies.x > cabeza.x else (pj_r.end.x + 10.0)
		ui_burbuja.position = Vector2(clamp(pos.x, 12.0, vs.x - bs.x - 12.0), clamp(pos.y, 70.0, vs.y - bs.y - 12.0))

var accion_en := Vector2.ZERO   # sitio del mundo sobre el que flota el cartelito de acción (puerta del bosque, farolillo…)
func _poner_accion(ct: Transform2D, vs: Vector2) -> void:
	ui_accion.reset_size()
	var p: Vector2 = ct * accion_en + Vector2(-ui_accion.size.x / 2.0, -ui_accion.size.y + sin(t * 3.2) * 4.0)
	ui_accion.position = Vector2(clamp(p.x, 10.0, vs.x - ui_accion.size.x - 10.0), clamp(p.y, 80.0, vs.y - ui_accion.size.y - 90.0))

func _usar_salida(id: String) -> void:
	if id == "" or state != "jugando": return
	ui_accion.visible = false; ui_burbuja.visible = false
	if ui_aviso: ui_aviso.visible = false
	if id.begins_with("mueble:") and interior: interior.usar(id.trim_prefix("mueble:")); return
	if id.begins_with("atajo"): bosque_esc.usar_atajo(id, self); return
	match id:
		"hablar":
			if npc_cerca != null:
				if String(npc_cerca[3]).begins_with("v:"): _saludar(npc_cerca)
				else: _conversar(npc_cerca[3])
		"arbol":
			state = "menu"; menu.volver_cb = func(): menu.visible = false; state = "jugando"
			menu.mostrar("arbol")
		"bosque":
			if arpg["hojas"] >= 2: start_bosque(); return
			popup_text(tr("JUEGO_PUERTA_BOSQUE_ESTA_CERRADA"), Estilo.CREMA)
			float_text(player.position + Vector2(0, -130), tr("JUEGO_HABLA_ANTES_DONA_PLUMAS"), Color(1, 0.9, 0.6))
		"portal":
			popup_text(tr("JUEGO_VUELTA_RAIZAL"), Estilo.ORO); start_raizal("bosque")
		"farolillo":
			if guard_vivos > 0:
				float_text(player.position + Vector2(0, -130), tr("JUEGO_BICHOS_CLARO_NO_DEJAN_ACERCARTE") % guard_vivos, Color(1, 0.9, 0.6))
			else: _encender_farolillo()
		"cofre":
			_abrir_cofre()
		"cofre_zona":
			_abrir_cofre_z()
		"salir_zona":
			_salir_zona()
		"academia":
			popup_text(tr("JUEGO_PUERTA_CORTEZA_ESTA_CERRADA"), Estilo.CREMA)
			float_text(player.position + Vector2(0, -130), tr("JUEGO_AHORA_NO_ABRE"), Color(1, 0.9, 0.6))
# ===================== Pack 2: vecinos que saludan, puertas y interiores =====================
var dentro := ""              # casa en la que estás ("" = en la calle)
var interior: Interior = null
var puerta_guarda := 0.0      # tras cruzar una puerta, un ratito sin poder volver a cruzarla
var puerta_armada := true     # y además hay que apartarse de la puerta antes de que vuelva a funcionar
var puerta_de := Vector2.ZERO # la puerta de la calle por la que entraste
var fundido: ColorRect

func _gente() -> Array:
	if modo == "zona": return zona_n.habitantes if zona_n else []
	if dentro != "" and interior: return interior.habitantes
	if raizal_esc == null: return []
	return raizal_esc.habitantes + raizal_esc.vecinos

func _saludar(h: Array) -> void:
	h[0].saludar(); hablando = h; hablar_hasta = t + 2.4
	if bot_on: print("BOT saluda ", h[1])

func _puertas() -> bool:
	puerta_guarda = max(0.0, puerta_guarda - get_process_delta_time())
	if state != "jugando": return false
	var p: Vector2 = player.position
	if dentro == "":
		if raizal_esc == null: return false
		var cerca := false
		for pu in raizal_esc.puertas:
			var d: float = p.distance_to(pu[1] + Vector2(0, 14))
			if d < 70.0: cerca = true
			# andar CONTRA la puerta (hacia arriba): sin tecla, sin botón y sin cartel
			if d < 34.0 and puerta_armada and puerta_guarda <= 0.0 and player.vel.y < -8.0:
				_entrar(pu); return true
		if not cerca: puerta_armada = true
	else:
		if p.y > interior.salida_y and puerta_armada and puerta_guarda <= 0.0: _salir(); return true
		if p.y < interior.salida_y - 60.0: puerta_armada = true
	return false

func _fundir(cambio: Callable) -> void:
	state = "puerta"; ui_accion.visible = false; ui_burbuja.visible = false; ui_aviso.visible = false; hablando = null
	if player: player.vel = Vector2.ZERO
	var tw := create_tween(); tw.tween_property(fundido, "color:a", 1.0, 0.18)
	tw.tween_callback(func(): cambio.call(); cam.position = _cam_meta(); cam.reset_smoothing())
	tw.tween_property(fundido, "color:a", 0.0, 0.22)
	tw.tween_callback(func(): if state == "puerta": state = "jugando")

func _entrar(pu: Array) -> void: _fundir(func(): _entrar_ya(pu))
func _entrar_ya(pu: Array) -> void:
	puerta_de = pu[1]
	if true:
		dentro = pu[0]
		raizal_esc.visible = false; raizal_esc.process_mode = Node.PROCESS_MODE_DISABLED
		if raizal_esc.luces: raizal_esc.luces.mostrar(false)
		interior = Interior.build(self, dentro)
		player.position = interior.aparece; player.mira = Vector2.UP; player.vel = Vector2.ZERO
		arena = Rect2(Vector2.ZERO, Interior.TAM); _limites_libres()
		puerta_guarda = 0.4; puerta_armada = false
		popup_text(interior.nombre(), Estilo.CREMA)
		RenderingServer.set_default_clear_color(Color(0.05, 0.04, 0.03))
		if bot_on or "--casa_traza" in OS.get_cmdline_user_args(): print("CASA entra ", dentro)

func _salir() -> void:
	_fundir(func():
		interior.queue_free(); interior = null; dentro = ""
		raizal_esc.visible = true; raizal_esc.process_mode = Node.PROCESS_MODE_INHERIT
		if raizal_esc.luces: raizal_esc.luces.mostrar(true)
		arena = Raizal.ARENA; _limites_cam()
		player.position = puerta_de + Vector2(0, 72); player.mira = Vector2.DOWN; player.vel = Vector2.ZERO   # delante de la puerta, de espaldas a ella
		puerta_guarda = 0.6; puerta_armada = false
		RenderingServer.set_default_clear_color(Color(0.05, 0.07, 0.06))
		if bot_on or "--casa_traza" in OS.get_cmdline_user_args(): print("CASA sale pos=", player.position))

func _limites_libres() -> void:
	cam.limit_left = -100000; cam.limit_top = -100000; cam.limit_right = 100000; cam.limit_bottom = 100000

# dentro: la sala ocupa ~88 % de la pantalla; si no cabe (móvil en vertical), la cámara sigue al jugador sin salirse de la sala
func _cam_meta() -> Vector2:
	if cam_fija != Vector2.INF: return cam_fija   # solo capturas de prueba (p14)
	if jefe_vista.has_area():   # p21: pelea con Bellotón: la arena entera en pantalla (si no cabe, sigue al niño dentro de ella)
		var vj: Vector2 = get_viewport().get_visible_rect().size / cam.zoom; var mj := Vector2.ZERO
		for k in 2: mj[k] = jefe_vista.get_center()[k] if jefe_vista.size[k] <= vj[k] else clamp(player.position[k], jefe_vista.position[k] + vj[k] / 2.0, jefe_vista.end[k] - vj[k] / 2.0)
		return mj
	if vista_total: return arena.get_center()
	if modo == "zona" and zona_n and zona_n.segura:   # refugio: como un interior (la sala entera en pantalla si cabe)
		var vz: Vector2 = get_viewport().get_visible_rect().size / cam.zoom; var mz := Vector2.ZERO
		for k in 2: mz[k] = zona_n.tam[k] / 2.0 if zona_n.tam[k] <= vz[k] else clamp(player.position[k], vz[k] / 2.0, zona_n.tam[k] - vz[k] / 2.0)
		return mz
	if dentro == "" or interior == null: return player.position
	var vs: Vector2 = get_viewport().get_visible_rect().size / cam.zoom
	var m := Vector2.ZERO
	for k in 2:
		var tam: float = Interior.TAM[k]
		m[k] = tam / 2.0 if tam <= vs[k] else clamp(player.position[k], vs[k] / 2.0, tam - vs[k] / 2.0)
	return m

func _ocultar_ui_raizal() -> void:
	hablando = null
	if ui_accion: ui_accion.visible = false
	if ui_aviso: ui_aviso.visible = false
	if ui_burbuja: ui_burbuja.visible = false

# ===================== Sprint 2: primer encargo («Las hojas que caen»), Bosque Susurrante y forja =====================
# Sin objetivos en pantalla al llegar: Doña Plumas viene volando a saludarte y te manda con Doña Gusana; Gusana te devuelve
# con Plumas, que da el encargo (pack 2: la Directora y la Academia se reservan para el último acto).
# Solo DESPUÉS de cada conversación aparece la guía sutil (guia.gd). El progreso va por personaje (arpg.gd).
var arpg: Dictionary = {}
var bosque_esc = null
var lento_jug := 0.0
var guia: Control
var dialogo: Control
var saludo_hecho := false
var guion_vec := Vector2.ZERO      # el jugador anda solo durante una escena (Gusana te acompaña a la puerta)
var te_activo := false             # Té de raíz de Gusana: recuperas vida poco a poco en la próxima salida al bosque
var tuto_vivo := false             # la criatura escarchada del sendero (aprendizaje del combate) aún no se ha calmado
var martillo_t := 2.0              # golpes de Brasas en la forja (ambiente)
const PLAZA := Vector2(-20, 270)
const PLUMAS_ARBOL := Vector2(170, -70)   # al volver del claro, Plumas te espera junto al Gran Árbol
const ESCARCHA_TUTO := Vector2(-190, -1995)   # entre unas raíces, al borde del sendero (bosque)
var fin_dialogo_t := -9.0   # la tecla que cierra un diálogo no vuelve a abrir otro
var guard_tot := 0
var guard_vivos := 0
var bot_on := "--bot_encargo" in OS.get_cmdline_user_args()
# p21: el bosque es un mapa vacío para pasear; las bandas, los guardianes del claro y el murciélago del guion solo salen con --bandas_p17
var bandas_p17 := "--bandas_p17" in OS.get_cmdline_user_args()
var bot_plano := "--bot_plano" in OS.get_cmdline_user_args()   # p21: bot que recorre el plano del bosque (bot_plano.gd)
var bot_vec := Vector2.ZERO
var bot_fotos := ""          # prefijo de las capturas del bot (p. ej. /workspace/juego/capturas_ui/encargo_)
var bot_hechas := {}
var bot_reg := {"t0": 0.0, "bosque_t": 0.0, "vida_perdida": 0.0, "desmayos": 0, "golpes": 0}
var bot_tt := 0.0
var bot_wp := 0
var bot_hp_ant := -1.0
var bot_atasco := 0.0
var bot_ult_pos := Vector2.ZERO

# ---- p18: ciclo de día y noche ----
func hora() -> float: return float(arpg.get("hora", Ciclo.HORA_INICIO)) if not arpg.is_empty() else Ciclo.HORA_INICIO
func _ciclo(delta: float) -> void:
	if arpg.is_empty() or not modo in ["raizal", "bosque", "zona"]: return
	if hora_forzada != "":
		arpg["hora"] = Ciclo.inicio_de(hora_forzada) + 1.0 if not hora_forzada.is_valid_float() else float(hora_forzada); hora_forzada = ""
	if state in ["jugando", "dialogo"]:
		arpg["hora"] = fposmod(hora() + delta * ciclo_x, Ciclo.TOTAL)
		ciclo_guarda_t += delta; _stats_tick(delta)
		if ciclo_guarda_t > 30.0: ciclo_guarda_t = 0.0; arpg_guardar()   # la hora va en la partida
	aplicar_hora()
# estadísticas de la partida (Ajustes → Partida guardada): tiempo jugado, zona más lejana y callejones
var stats_t := 0.0
func _stats_tick(delta: float) -> void:
	if sala_prueba: return
	arpg["t_jugado"] = float(arpg.get("t_jugado", 0.0)) + delta
	stats_t += delta
	if stats_t < 0.5 or player == null: return
	stats_t = 0.0
	if modo == "bosque":
		var p: Vector2 = player.position
		arpg["zona_max"] = max(int(arpg.get("zona_max", 0)), Arpg.zona_bosque(p))
		for c in Arpg.CALLEJONES: if p.distance_to(Arpg.CALLEJONES[c]) < 350.0: Arpg.marcar_callejon(arpg, c)
	elif modo == "zona": Arpg.marcar_callejon(arpg, zona_id)
func oro_mas(n: int) -> void:   # todo el oro que se gana pasa por aquí (cuenta el total conseguido)
	arpg["oro"] += n; arpg["oro_tot"] = int(arpg.get("oro_tot", 0)) + n
func luces_actuales() -> MapaLuz:
	if modo == "bosque" and bosque_esc: return bosque_esc.luces
	if modo == "zona" and zona_n: return zona_n.luces
	if modo == "raizal" and raizal_esc: return raizal_esc.luces
	return null
func aplicar_hora() -> void:
	var h: float = hora(); var k: float = Ciclo.farolas(h); ciclo_k = k
	var l: MapaLuz = null; var pal: Array = []
	if modo == "raizal" and raizal_esc: l = raizal_esc.luces; pal = Ciclo.RAIZAL
	elif modo == "bosque" and bosque_esc: l = bosque_esc.luces; pal = Ciclo.BOSQUE; bosque_esc.k_noche = k
	elif modo == "zona" and zona_n and zona_n.d.has("claro") and zona_id != "cueva_helada": l = zona_n.luces; pal = Ciclo.paleta_zona(zona_n.d["noche"])
	if l == null or not is_instance_valid(l): return
	l.hora(Ciclo.color(pal, h), k)

func arpg_guardar() -> void:
	if arpg.is_empty() or sala_prueba: return
	Arpg.guardar()

func _nombre_pj() -> String: return tr(Personajes.LISTA[pj]["n"])
func _nombre_arma() -> String: return Armas.n(arma)

func _npc(id: String) -> Array:
	if modo == "zona" and zona_n != null:
		for h in zona_n.habitantes: if h[3] == id: return h
		return []
	if dentro != "" and interior != null:   # Gusana atiende dentro de su tienda de pociones
		for h in interior.habitantes: if h[3] == id: return h
	if raizal_esc == null: return []
	for h in raizal_esc.habitantes: if h[3] == id: return h
	return []

# ---- diálogo ----
func _hablar(lineas: Array, fin := Callable(), ops := [], elegir := Callable(), con := "") -> void:
	state = "dialogo"; ui_accion.visible = false; ui_aviso.visible = false
	var n: Array = _npc(con)
	if not n.is_empty(): n[0].hablar(true)
	var nom := _nombre_pj(); var arm := _nombre_arma()
	var l2: Array = []
	for l in lineas: l2.append([l[0], String(l[1]).replace("{pj}", nom).replace("{arma}", arm)])
	var o2: Array = []
	for o in ops: o2.append(String(o).replace("{arma}", arm))
	var cerrar := func():
		state = "jugando"; fin_dialogo_t = t
		if player: player.mira = Vector2.DOWN   # tras hablar, de frente a la cámara
		if not n.is_empty(): n[0].hablar(false)
	dialogo.abrir(l2, o2, func(k): cerrar.call(); if elegir.is_valid(): elegir.call(k), func(): cerrar.call(); if fin.is_valid(): fin.call())
	if bot_on and con != "" and not bot_hechas.has("d_" + con + str(arpg["hojas"])): bot_hechas["d_" + con + str(arpg["hojas"])] = true; _foto("%s_%d" % [con, arpg["hojas"]], 0.55)

# estado del pueblo según el encargo: hoja congelada en la rama de Plumas y Plumas junto al Gran Árbol al volver del claro
func _estado_raizal() -> void:
	if arpg["hojas"] == 1: arpg["hojas"] = 2; arpg_guardar()   # partidas antiguas: el paso «ve a ver a Gusana» ya no existe (la puerta ya se abre con Plumas)
	var h: Array = _npc("plumas")
	if h.is_empty(): return
	var nodo: Node2D = h[0]
	if not nodo.has_meta("rama"): nodo.set_meta("rama", nodo.position)
	if arpg["hojas"] >= 2: _hoja_en_rama(nodo.get_meta("rama"))
	if arpg["hojas"] == 3: nodo.position = PLUMAS_ARBOL; nodo.posado = false

# hoja helada del Gran Árbol (arte de Francisco, escarcha_v1): ~46 u de ancho en el suelo (el niño mide ~100 u)
const HOJA_TEX := preload("res://assets/bosque/escarcha/hoja_helada.png")
func _hoja_nodo() -> Node2D:
	var n := Node2D.new()
	var sp := Sprite2D.new(); sp.texture = HOJA_TEX; sp.scale = Vector2.ONE * (46.0 / HOJA_TEX.get_width()); sp.texture_filter = CanvasItem.TEXTURE_FILTER_LINEAR_WITH_MIPMAPS
	n.add_child(sp)
	return n

func _hoja_en_rama(rama: Vector2) -> void:
	if raizal_esc == null or raizal_esc.find_child("HojaRama", true, false) != null: return
	var hj := _hoja_nodo(); hj.name = "HojaRama"; hj.position = rama + Vector2(40, 2); hj.rotation = 0.5; hj.scale = Vector2.ONE * 0.62; hj.z_index = 1
	var pl: Array = _npc("plumas")
	if not pl.is_empty() and pl[0].has_method("punto_rama") and pl[0].position.distance_to(rama) < 4.0 and arpg["hojas"] != 3:   # encima de la rama flotante (se mece con ella)
		hj.position = pl[0].punto_rama(); pl[0].rama.add_child(hj); return
	raizal_esc.add_child(hj)

func _hoja_escarcha() -> void:
	var h: Array = _npc("plumas")
	if h.is_empty(): return
	state = "dialogo"   # quieto mientras dura la escena
	player.mira = Vector2.DOWN
	var pie: Vector2 = player.position + Vector2(44, 16)
	var ini: Vector2 = pie + Vector2(-70, -430)
	var hoja := _hoja_nodo(); hoja.z_index = 30; hoja.position = ini; raizal_esc.add_child(hoja)
	var nodo: Node2D = h[0]; var rama: Vector2 = nodo.get_meta("rama", nodo.position)
	var dest: Vector2 = pie + Vector2(76, 4)
	var tw := create_tween()
	tw.tween_method(func(k: float): hoja.position = ini.lerp(pie, k) + Vector2(sin(k * TAU * 1.5) * 46.0, 0.0); hoja.rotation = sin(k * TAU * 1.5) * 0.7, 0.0, 1.0, 2.0)
	tw.tween_callback(func(): hoja.rotation = 0.25; hoja.z_index = 0; FX.burst(self, pie, Color(0.85, 0.95, 1.0), 10, 110, 4))
	tw.tween_interval(0.4)
	tw.tween_callback(func(): nodo.posado = false)
	tw.tween_method(func(k: float): nodo.position = rama.lerp(dest, k) + Vector2(0, -sin(k * PI) * 120.0), 0.0, 1.0, 1.3).set_trans(Tween.TRANS_SINE)
	tw.tween_callback(func():
		_hablar([["pj", tr("DLG_PJ_ESTA_CONGELADA")],
			["plumas", tr("DLG_PLUMAS_TERCERA_ESTA_MANANA")],
			["plumas", tr("DLG_PLUMAS_FAROLILLO_RAIZ_CLARO_LUCIERNAGAS_APAGO")],
			["pj", tr("DLG_PJ_PODEMOS_VOLVER_ENCENDERLO")],
			["plumas", tr("DLG_PLUMAS_ESO_ESPERO_SENDERO_SALE_PUERTA")]], func():
				arpg["hojas"] = 2; arpg["cadena"] = 0; arpg_guardar()
				popup_text(tr("JUEGO_ENCIENDE_FAROLILLO_CLARO"), Estilo.ORO)
				# Plumas se aparta: vuelve a su rama con la hoja y la deja allí
				var tw2 := create_tween()
				tw2.tween_method(func(k: float):
					nodo.position = dest.lerp(rama, k) + Vector2(0, -sin(k * PI) * 120.0)
					if is_instance_valid(hoja): hoja.position = nodo.position + Vector2(-34, -22), 0.0, 1.0, 1.3).set_trans(Tween.TRANS_SINE)
				tw2.tween_callback(func():
					nodo.posado = true
					if is_instance_valid(hoja): hoja.queue_free()
					_hoja_en_rama(rama))
				if bot_on: _foto("guia", 2.0), [], Callable(), "plumas"))

# Gusana: tras el té te acompaña hasta la puerta (andando los dos) y se despide
func _te_gusana() -> void:
	arpg["te_gusana"] = true; arpg["te_raiz"] = true; arpg_guardar()
	popup_text(tr("JUEGO_RAIZ_RECUPERAS_VIDA_POCO_POCO"), Color(0.75, 1.0, 0.6))
	var h: Array = _npc("gusana")
	if h.is_empty() or interior == null: return
	state = "dialogo"
	var gu: Node2D = h[0]; var meta: Vector2 = interior.aparece + Vector2(0, -40)
	var g_ini: Vector2 = gu.position; var g_fin: Vector2 = meta + Vector2(-70, -10)
	create_tween().tween_property(gu, "position", g_fin, 1.8).set_trans(Tween.TRANS_SINE)
	var t0 := t
	while is_instance_valid(player) and dentro != "" and player.position.distance_to(meta) > 24.0 and t - t0 < 4.0:
		guion_vec = (meta - player.position).normalized()
		await get_tree().process_frame
	guion_vec = Vector2.ZERO
	if dentro == "": return
	player.mira = Vector2.LEFT
	_hablar([["gusana", tr("DLG_GUSANA_CUANDO_VUELVAS_CUENTAME_COMO_ESTA")]], Callable(), [], Callable(), "gusana")

func _conversar(id: String) -> void:
	var e: int = arpg["hojas"]
	match id:
		"bruja": _bruja_hablar()
		"plumas":
			if e == 3:
				_hablar([["plumas", tr("DLG_PLUMAS_HAN_VUELTO_LUCIERNAGAS_HE_VISTO")],
					["pj", tr("DLG_PJ_PERO_TODAVIA_QUEDA_HIELO_JUNTO")],
					["plumas", tr("DLG_PLUMAS_ENTONCES_TENDRE_MIRAR_MAS_LEJOS")]], func():
						oro_mas(100); popup_text(tr("JUEGO_100_ORO"), Estilo.ORO); _ganar_xp(150); arpg_guardar()
						_hablar([["plumas", tr("DLG_PLUMAS_ANTES_VOLVER_AL_BOSQUE_PASA")]], func():
							arpg["hojas"] = 4; arpg_guardar()
							var hp: Array = _npc("plumas")   # vuelve a su rama
							if not hp.is_empty():
								var nd: Node2D = hp[0]; var de: Vector2 = nd.position; var a: Vector2 = nd.get_meta("rama", de)
								var tw := create_tween(); tw.tween_method(func(k: float): nd.position = de.lerp(a, k) + Vector2(0, -sin(k * PI) * 140.0), 0.0, 1.0, 1.6).set_trans(Tween.TRANS_SINE)
								tw.tween_callback(func(): nd.posado = true), [], Callable(), "plumas"), [], Callable(), "plumas")
			else:
				var f := tr("DLG_PLUMAS_UUH_UUH_HAS_OIDO_CARNICERITO")
				if e <= 2: f = tr("DLG_PLUMAS_SENDERO_SALE_PUERTA_SUR_ABRIGATE")
				elif e == 4: f = tr("DLG_PLUMAS_PASA_FORJA_BRASAS_PODRA_AYUDARTE")
				elif e >= 5 and not Secretos.tiene(arpg, "pistas", "tuneles"):   # zona secreta 1: túneles bajo Raizal
					_hablar([["plumas", tr("DLG_PLUMAS_UUH_UUH_CASA_PIEDRA_CALLE")],
						["pj", tr("DLG_PJ_RUIDOS")],
						["plumas", tr("DLG_PLUMAS_TAC_TAC_TAC_COMO_UNITAS")]], func():
							_dar_pista("tuneles"); raizal_esc.abrir_piedra(); _rej_de = []
							popup_text(tr("JUEGO_CASA_PIEDRA_ESTA_ABIERTA"), Estilo.CREMA), [], Callable(), "plumas")
					return
				_hablar([["plumas", f]], Callable(), [], Callable(), "plumas")
		"brasas":
			if e < 4:
				_hablar([["brasas", tr("DLG_BRASAS_BIENVENIDO_FORJA_AQUI_ARREGLA_TODO")]], Callable(), [], Callable(), "brasas")
				return
			var n: int = arpg["arma_mas"] + 1
			if n > 3:
				_hablar([["brasas", tr("DLG_BRASAS_ARMA_YA_ESTA_3_NO")]], Callable(), [], Callable(), "brasas"); return
			var intro := tr("DLG_BRASAS_ESTAS_SIRVEN_DEJAME_ENSENARTE_PUEDO") if n == 1 else tr("DLG_BRASAS_OTRA_MEJORA_ESO_ME_ALEGRA")
			if pj == "musgo":   # el tótem de Musgo es de la Naturaleza: Brasas no lo golpea, le pide permiso
				intro = tr("DLG_BRASAS_ESTAS_SIRVEN_PERO_TOTEM_NO") if n == 1 else tr("DLG_BRASAS_OTRA_VEZ_TOTEM_CUIDADO_COMO")
			_hablar([["brasas", intro]], func(): _forja_ui(n), [], Callable(), "brasas")
		"gusana":
			if e == 2 and not arpg.get("te_gusana", false):
				_hablar([["gusana", tr("DLG_GUSANA_VEN_PJ_ESTABA_GUARDANDO_POCO")],
					["pj", tr("DLG_PJ_VOY_AL_CLARO_PLUMAS_ME")],
					["gusana", tr("DLG_GUSANA_ENTONCES_BEBE_ANTES_SALIR_ESTA")]], func(): _te_gusana(), [], Callable(), "gusana")
				return
			var f := tr("DLG_GUSANA_YA_HAS_VUELTO_SIENTATE_CUENTAME")
			if e <= 1: f = tr("DLG_GUSANA_BUENOS_DIAS_PJ_FRIO_MAS")
			elif e == 2: f = tr("DLG_GUSANA_CUANDO_VUELVAS_CUENTAME_COMO_ESTA")
			_hablar([["gusana", f]], Callable(), [], Callable(), "gusana")

# golpes del martillo de Brasas (ambiente): dos o tres golpes, una pausa… solo en la calle y cerca de la forja
func _martillo(d: float) -> void:
	if dentro != "" or raizal_esc == null or not sfx.has("martillo"): return
	martillo_t -= d
	if martillo_t > 0.0: return
	var h: Array = _npc("brasas")
	if h.is_empty(): return
	var p: Vector2 = h[0].position + Vector2(-40, -30)
	if player.position.distance_to(p) > 1500.0: martillo_t = 1.0; return
	var golpes := randi_range(2, 3)
	for k in golpes: get_tree().create_timer(k * 0.42).timeout.connect(func(): if modo == "raizal" and dentro == "": _sfx_suave("martillo", p, 0.6 + 0.08 * k))
	martillo_t = randf_range(2.6, 4.2)

func _sfx_suave(n: String, p: Vector2, pitch := 1.0) -> void:
	var a := AudioStreamPlayer2D.new(); a.stream = sfx[n]; a.position = p; a.max_distance = 1500; a.attenuation = 1.6; a.bus = "Efectos"; a.pitch_scale = pitch; a.volume_db = -6.0
	add_child(a); a.play(); a.finished.connect(a.queue_free)

# ---- pantalla de la forja: la mejora con su coste y su efecto bien a la vista (guion: «Se abre la primera mejora») ----
func _forja_ui(n: int) -> void:
	var oro_c: int = 80 * n; var cas_c: int = 3 * n
	var ok: bool = arpg["oro"] >= oro_c and arpg["cascaras"] >= cas_c
	state = "dialogo"; ui_accion.visible = false
	var capa: Control = Control.new(); capa.name = "Forja"; capa.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT); capa.process_mode = Node.PROCESS_MODE_ALWAYS
	var velo := ColorRect.new(); velo.color = Color(0, 0, 0, 0.35); velo.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT); capa.add_child(velo)
	var pc := PanelContainer.new(); pc.add_theme_stylebox_override("panel", Madera.caja(10.0)); capa.add_child(pc)
	var vb := VBoxContainer.new(); vb.add_theme_constant_override("separation", 8); pc.add_child(vb)
	var tab := PanelContainer.new(); tab.add_theme_stylebox_override("panel", Madera.pestana(14, 4)); tab.size_flags_horizontal = Control.SIZE_SHRINK_CENTER
	tab.add_child(Madera.texto(tr("JUEGO_FORJA_BRASAS"), 17, Madera.CREMA, true)); vb.add_child(tab)
	var l1 := Madera.texto("%s  +%d  ›  +%d" % [_nombre_arma(), n - 1, n], 24, Madera.TINTA, true); l1.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER; vb.add_child(l1)
	var l2 := Madera.texto(tr("JUEGO_EFECTO_15_DANO"), 17, Color(0.18, 0.42, 0.16)); l2.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER; vb.add_child(l2)
	var l3 := Madera.texto(tr("JUEGO_COSTE_ORO_CASCARAS") % [oro_c, cas_c], 17, Madera.TINTA); l3.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER; vb.add_child(l3)
	var l4 := Madera.texto(tr("JUEGO_TIENES_ORO_CASCARAS") % [arpg["oro"], arpg["cascaras"]], 14, Madera.TINTA2 if ok else Color(0.66, 0.16, 0.1)); l4.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER; vb.add_child(l4)
	var hb := HBoxContainer.new(); hb.alignment = BoxContainer.ALIGNMENT_CENTER; hb.add_theme_constant_override("separation", 12); vb.add_child(hb)
	var b1 := Madera.boton(tr("JUEGO_PEDIR_PERMISO") if pj == "musgo" else tr("JUEGO_FORJAR"), true, 17); b1.custom_minimum_size = Vector2(130, 42); b1.disabled = not ok; hb.add_child(b1)
	var b2 := Madera.boton(tr("JUEGO_AHORA_NO"), false, 16); b2.custom_minimum_size = Vector2(120, 42); hb.add_child(b2)
	ui_capa.add_child(capa)
	await get_tree().process_frame
	var vs: Vector2 = get_viewport().get_visible_rect().size
	pc.reset_size(); pc.position = (vs - pc.size) / 2.0 - Vector2(0, vs.y * 0.06)
	(b1 if ok else b2).grab_focus()
	var cerrar := func(compra: bool):
		capa.queue_free(); state = "jugando"; fin_dialogo_t = t
		if not compra:
			_hablar([["brasas", tr("DLG_BRASAS_AQUI_ESPERO_AVIVANDO_FUEGO") if ok else tr("JUEGO_FALTAN_ORO_O_CASCARAS_BELLOTAS")]], Callable(), [], Callable(), "brasas"); return
		arpg["oro"] -= oro_c; arpg["cascaras"] -= cas_c; arpg["arma_mas"] = n
		if arpg["hojas"] == 4: arpg["hojas"] = 5
		arpg_guardar(); recalc_stats()
		var h: Array = _npc("brasas")
		if not h.is_empty(): FX.burst(self, h[0].position + Vector2(0, -60), Color(1, 0.6, 0.2), 30, 360, 7)
		shake(6.0); popup_text("¡%s +%d!" % [_nombre_arma(), n], Estilo.ORO)
		var fin_l: Array = [["brasas", tr("DLG_BRASAS_MARTILLAZO_VA_LISTO_ARMA_PEGA") % n]]
		if pj == "musgo": fin_l = [["brasas", tr("DLG_BRASAS_YA_ESTA_NO_HE_TOCADO") % n]]
		if n == 1:   # el rumor de Carnicerito, solo tras la primera mejora
			fin_l.append(["brasas", tr("DLG_BRASAS_CIERTO_DICEN_GRANJA_SUR_VIVE")])
			fin_l.append(["pj", tr("DLG_PJ_HELADO_COMO_SENDERO")])
			fin_l.append(["brasas", tr("DLG_BRASAS_ESO_DIGO_YO_PERO_MOMENTO")])
		_hablar(fin_l, Callable(), [], Callable(), "brasas")
	b1.pressed.connect(func(): cerrar.call(true))
	b2.pressed.connect(func(): cerrar.call(false))
	if bot_on:
		_foto("forja_ui", 0.5)
		get_tree().create_timer(1.2).timeout.connect(func(): if is_instance_valid(capa): cerrar.call(ok))

# ---- XP y nivel del personaje ----
func _ganar_xp(n: int) -> void:
	arpg["xp"] += n
	while arpg["xp"] >= Arpg.xp_nivel(arpg["nivel"]):
		arpg["xp"] -= Arpg.xp_nivel(arpg["nivel"]); arpg["nivel"] += 1
		recalc_stats(); player.hp = player.max_hp
		popup_text(tr("JUEGO_NIVEL_10_VIDA_4_DANO") % arpg["nivel"], Color(0.75, 1.0, 0.6))
		FX.burst(self, player.position + Vector2(0, -50), Color(0.8, 1.0, 0.5), 30, 300, 6)

# ---- seguimiento del encargo activo: [nombre, paso (4-5 palabras), paso opcional] ----
func _encargo() -> Array:
	var r: Array = _encargo_base()
	var sec: Array = _secreto_activo()
	if sec.is_empty(): return r
	if r.is_empty() or modo == "zona": return [sec[0], sec[1], ""]
	if r[2] == "": r[2] = tr("JUEGO_SECRETO") + tr(sec[0])
	return r
func _encargo_base() -> Array:
	var e: int = arpg.get("hojas", 0)
	var opc := tr("JUEGO_OPCIONAL_TIENDA_GUSANA") if e == 2 and not arpg.get("te_gusana", false) else ""
	match e:
		2:
			var paso := tr("JUEGO_ENCIENDE_FAROLILLO_CLARO")
			if modo == "bosque":
				if tuto_vivo: paso = tr("JUEGO_CALMA_CRIATURA_HELADA")
				elif guard_vivos > 0: paso = tr("JUEGO_CALMA_CLARO") % [guard_tot - guard_vivos, guard_tot]
			return [tr("JUEGO_LUZ_CLARO"), paso, opc]
		3: return [tr("JUEGO_LUZ_CLARO"), tr("JUEGO_ABRE_COFRE_CLARO") if modo == "bosque" and not arpg["cofre"] else tr("JUEGO_VUELVE_DONA_PLUMAS"), ""]
		4: return [tr("JUEGO_RETO_HERRERO"), tr("JUEGO_LLEVA_CASCARAS_BRASAS"), ""]
	return []

func flecha_on() -> bool: return Guardado.d.get("flecha_guia", true)
func _flecha_cambiar() -> void:
	Guardado.d["flecha_guia"] = not flecha_on(); Guardado.guardar()
	float_text(player.position + Vector2(0, -130), tr("JUEGO_FLECHA_GUIA_SI") if flecha_on() else tr("JUEGO_FLECHA_GUIA_NO"), Color(1, 0.9, 0.6))
	if bot_on or test_mode: print("FLECHA ", flecha_on())

# ---- guía sutil ----
func _guia_raizal() -> void:
	var e: int = arpg.get("hojas", 0); var o = null
	var h: Array = []
	if dentro != "" and interior != null:
		guia.objetivo = {"pos": interior.aparece + Vector2(0, 40), "alto": 0.0, "s": ""} if e in [2, 3, 4] else null; return
	if e == 3: h = _npc("plumas")
	elif e == 4: h = _npc("brasas")
	if not h.is_empty(): o = {"pos": h[0].position, "alto": h[0].alto, "s": "?" if e == 3 else "!"}
	elif e == 2: o = {"pos": Raizal.PUERTA_BOSQUE + Vector2(0, -50), "alto": 200.0, "s": ""}
	guia.objetivo = o

var zarzas_aviso := -9.0
func _guia_bosque() -> void:
	var e: int = arpg["hojas"]; var o = null
	var sec: Array = _secreto_activo()
	if e >= 3 and not sec.is_empty() and sec[0] == Secretos.ZONAS["claro_musgo"]["pista"]: guia.objetivo = {"pos": Bosque.ZARZAS + Vector2(0, -40), "alto": 0.0, "s": ""}; return
	if e >= 3 and not sec.is_empty() and sec[0] == tr("JUEGO_REFUGIO_BRUJA_2"): guia.objetivo = {"pos": Bosque.REFUGIO, "alto": 120.0, "s": "!"}; return
	if e == 2 and tuto_vivo: o = {"pos": ESCARCHA_TUTO, "alto": 0.0, "s": ""}
	elif e == 2: o = {"pos": Bosque.CLARO_C, "alto": 0.0, "s": ""} if guard_vivos > 0 else {"pos": Bosque.FAROLILLO, "alto": 150.0, "s": "!"}
	elif e == 3 and not arpg["cofre"]: o = {"pos": Bosque.COFRE, "alto": 60.0, "s": "!"}
	elif e == 3: o = {"pos": Bosque.PORTAL_C, "alto": 160.0, "s": ""}
	guia.objetivo = o

# ---- Bosque Susurrante (mapa 1) ----
func start_bosque(desde := "") -> void:
	if not arpg.is_empty(): arpg_guardar()
	limpiar_partida(); modo = "bosque"; companero = null; raizal_esc = null; zona_n = null; zona_id = ""
	for e in enemies: if is_instance_valid(e): e.queue_free()
	enemies.clear(); trails.clear(); stats = {}; get_tree().paused = false
	arma = Personajes.LISTA[pj]["arma"]; arma_nv = 1; kills = 0; lento_jug = 0.0
	if has_node("Escenario"): var old := get_node("Escenario"); remove_child(old); old.queue_free()
	arena = Bosque.ARENA; _limites_cam()
	obst = Bosque.build(self); bosque_esc = get_node("Escenario"); _rej_de = []
	RenderingServer.set_default_clear_color(Color(0.03, 0.05, 0.06))
	if player: player.queue_free()
	player = Node2D.new(); player.set_script(load("res://player.gd")); add_child(player)
	player.died.connect(_on_died)
	player.position = Bosque.ENTRADA; player.mira = Vector2.DOWN
	if desde == "refugio": player.position = Bosque.REFUGIO + Vector2(0, 80)
	elif desde == "zarzas": player.position = Bosque.ZARZAS + Vector2(40, 110)
	cam.position = player.position; cam.reset_smoothing()
	alive_time = 0.0; state = "jugando"
	recalc_stats(); player.hp = player.max_hp
	# bichos: si el farolillo ya está encendido, el claro está en calma (sin guardianes)
	var lit: bool = arpg["hojas"] >= 3
	guard_tot = 0; guard_vivos = 0
	var rng := RandomNumberGenerator.new(); rng.randomize()
	bandas = []; turnos = {}
	for g in Bosque.GRUPOS:
		if not bandas_p17: break
		if g[2] and lit: continue
		var lista: Array = g[1].slice(arpg["calmados"]) if g[2] else g[1]   # los del claro que ya calmaste siguen tranquilos aunque te desmayes
		if g[2]: guard_tot = g[1].size() - lista.size(); guard_vivos = 0
		for e in poner_banda(g[0], lista, g[2], g[3], rng):
			if g[2]: guard_tot += 1; guard_vivos += 1
	for b in enemies: b.escarcha = true   # todos llevan escarcha: al calmarlos se les desprende (sin cambiar su forma de pelear)
	tuto_vivo = false
	if arpg["hojas"] == 2:   # guion: una criatura escarchada se esconde entre raíces al borde del sendero; al acercarte se vuelve y ataca
		bosque_esc.helar(true)
	if arpg["hojas"] == 2 and bandas_p17:
		bosque_esc._sprite("escarcha/planta_raices", ESCARCHA_TUTO + Vector2(-10, 18), 104.0, false)   # su escondite: raíces heladas (escarcha_v1)
		var tb := Node2D.new(); tb.set_script(load("res://bicho.gd")); tb.setup("murcielago", ESCARCHA_TUTO, false); add_child(tb)   # entra en «enemies» al dejar de esconderse (el arma no la ve antes). p17: es un Dormur (el más débil, el único que va solo), dormido entre las raíces
		tb.escarcha = true; tb.escondida = true; tb.tuto = true; tuto_vivo = true
	te_activo = arpg.get("te_raiz", false); arpg["te_raiz"] = false
	if te_activo: get_tree().create_timer(1.2).timeout.connect(func(): if modo == "bosque": float_text(player.position + Vector2(0, -130), tr("JUEGO_GUSANA_CALIENTA"), Color(0.75, 1.0, 0.6)))
	if lit:
		bosque_esc.encender_farolillo(false); bosque_esc.poner_cofre(arpg["cofre"]); bosque_esc.poner_portal_claro(); _rej_de = []
	_zoom_mundo()
	popup_text(tr("JUEGO_BOSQUE_SUSURRANTE"), Estilo.ORO)
	_poner_companero(); _poner_misterios("bosque")
	if bot_on: bot_wp = 0; bot_swp = 0; bot_visita += 1; _foto("bosque", 1.6)
	if bot_plano and not has_node("BotPlano"): var bp := Node.new(); bp.name = "BotPlano"; bp.set_script(load("res://bot_plano.gd")); add_child(bp)

func _bosque(delta: float) -> void:
	lento_jug = max(0.0, lento_jug - delta)
	_misterios_tick()
	if te_activo and player and state == "jugando": player.hp = min(player.max_hp, player.hp + 1.5 * delta)
	_guia_bosque()
	if state != "jugando": ui_accion.visible = false; return
	var vs: Vector2 = get_viewport().get_visible_rect().size; var vert: bool = vs.y > vs.x
	salida_cerca = ""
	# refugio de la bruja y zarzas del oeste: se entra andando contra la puerta / la boca (como las casas de Raizal)
	var pp: Vector2 = player.position
	if alive_time > 0.6 and player.vel.y < -8.0:
		if pp.distance_to(Bosque.REFUGIO + Vector2(0, 14)) < 40.0: _fundir(func(): start_zona("refugio")); return
		if pp.distance_to(Bosque.ZARZAS + Vector2(0, -24)) < 56.0:
			if arpg["hojas"] >= 3: _fundir(func(): start_zona("claro_musgo")); return
			elif t - zarzas_aviso > 3.0: zarzas_aviso = t; float_text(pp + Vector2(0, -130), tr("JUEGO_ZARZAS_NO_CEDEN_DEMASIADO_FRIO"), Color(0.8, 0.93, 1.0))
	var opciones := [["portal", tr("JUEGO_VOLVER_RAIZAL"), Bosque.PORTAL_N, 170.0, 210.0]]
	if arpg["hojas"] == 2: opciones.append(["farolillo", tr("JUEGO_ENCENDER"), Bosque.FAROLILLO, 150.0, 190.0])
	if arpg["hojas"] >= 3 and not arpg["cofre"]: opciones.append(["cofre", tr("JUEGO_ABRIR"), Bosque.COFRE, 130.0, 90.0])
	if arpg["hojas"] >= 3: opciones.append(["portal", tr("JUEGO_VOLVER_RAIZAL"), Bosque.PORTAL_C, 150.0, 200.0])
	opciones.append_array(bosque_esc.atajos_cerca(pp))   # p21: atajos A1 (tronco) y A2 (raíces), solo se abren desde el sur
	for o in opciones:
		if player.position.distance_to(o[2]) < o[3]: salida_cerca = o[0]; ui_accion.text = o[1]; accion_en = o[2] + Vector2(0, -o[4])
	ui_accion.visible = salida_cerca != ""
	if ui_accion.visible: _poner_accion(get_viewport().get_canvas_transform(), vs)
	if Input.is_action_just_pressed("interactuar") and salida_cerca != "" and t - fin_dialogo_t > 0.3: _usar_salida(salida_cerca)

# --- p17: bandas con líder y turnos de ataque -------------------------------------------------------------------------
var bandas: Array = []
func poner_banda(c: Vector2, tipos: Array, guard: bool, reparto: float, rng: RandomNumberGenerator, vida_k := 1.0) -> Array:
	# «lider:tipo» = el líder. Una sola criatura sin «lider:» va suelta (solo los Dormur, los más débiles)
	var bd = Banda.new() if tipos.size() > 1 else null
	if bd: bd.centro = c; bandas.append(bd)
	var out: Array = []
	for i in tipos.size():
		var tp: String = tipos[i]; var es_lider: bool = tp.begins_with("lider:"); tp = tp.trim_prefix("lider:")
		var p: Vector2 = c if reparto <= 0.0 else c + Vector2.from_angle(rng.randf() * TAU) * rng.randf_range(30.0, reparto)
		if es_lider: p = c
		p = resolve(p, 34.0)
		var b := Node2D.new(); b.set_script(load("res://bestia.gd") if Criaturas.es_bestia(tp) else load("res://bicho.gd"))
		b.setup(tp, p, guard)
		if es_lider and bd: b.hacer_lider(); bd.lider = b
		b.hp *= vida_k; b.max_hp = b.hp
		if bd: b.banda = bd; bd.miembros.append(b)
		add_child(b); enemies.append(b); out.append(b)
	return out
# como mucho 2 enemigos pegando cuerpo a cuerpo y 2 disparando a la vez: una banda de 7 sigue siendo justa
const TURNOS_CERCA := 2
const TURNOS_LEJOS := 2
var turnos := {}
func _turnos_limpia() -> void:
	for k in turnos.keys():
		var v: Array = turnos[k]
		if not is_instance_valid(v[0]) or not enemies.has(v[0]) or t - v[2] > 4.0: turnos.erase(k)
func turno_ataque(e, lejos: bool) -> bool:
	var id: int = e.get_instance_id()
	if turnos.has(id): return true
	_turnos_limpia()
	var n := 0
	for v in turnos.values(): if v[1] == lejos: n += 1
	if n >= (TURNOS_LEJOS if lejos else TURNOS_CERCA): return false
	turnos[id] = [e, lejos, t]; return true
func hay_turno(e) -> bool:
	if turnos.has(e.get_instance_id()): return true
	_turnos_limpia()
	var n := 0
	for v in turnos.values(): if not v[1]: n += 1
	return n < TURNOS_CERCA
func suelta_turno(e) -> void: turnos.erase(e.get_instance_id())
func revivir_enemigo(e) -> void:
	if not enemies.has(e): enemies.append(e)
	if e.guardian:
		guard_vivos += 1; arpg["calmados"] = max(0, int(arpg["calmados"]) - 1)
	if bot_on: print("BANDA revive %s" % e.tipo)
# registro de golpes (pruebas): cada ataque tiene que hacer daño UNA vez
var golpes_reg: Array = []
func registro_golpe(tp: String, id: int) -> void: golpes_reg.append([tp, id, t])
var sueltas_reg: Array = []
var prep_regs: Array = []   # p18: preparación de la Esporina Mayor antes de soltar (pruebas)
func registro_prep(e, r: Dictionary) -> void: prep_regs.append([e.tipo, r.duplicate()])
func registro_suelta(tp: String, fr: int, esperado: int) -> void: sueltas_reg.append([tp, fr, esperado, t])

func _calmado(e, hp_pos: Vector2) -> void:
	# Recompensas de la aventura: experiencia directa, monedas y materiales.
	kills += 1; enemies.erase(e)
	FX.burst(self, hp_pos, Color(0.7, 1.0, 0.55), 22, 340, 6); shake(3.0)
	if not e.sin_premio:   # p17: el que reviene (revivido por su líder) ya no da premio otra vez
		arpg["calmados_tot"] = int(arpg.get("calmados_tot", 0)) + 1
		var xp_n: int = e.xp_de(); var oro_n: int = randi_range(2, 5) * (2 if e.lider else 1)
		oro_mas(oro_n); _ganar_xp(xp_n)
		if e.tipo in Arpg.JEFES: arpg["jefes_tot"] = int(arpg.get("jefes_tot", 0)) + 1
		var txt := tr("JUEGO_ORO") % oro_n
		if e.tipo in ["bellota", "escarabajo", "guardacorteza"] and randf() < 0.45: arpg["cascaras"] += 1; txt += tr("JUEGO_1_CASCARA")
		if e.tipo in ["seta", "esporina", "esporina_mayor"] and randf() < 0.35: arpg["esporas"] = int(arpg.get("esporas", 0)) + 1; txt += tr("JUEGO_1_ESPORA")
		float_text(hp_pos + Vector2(0, -50), txt, Color(1.0, 0.88, 0.5))
	if bot_on: print("BOT calmado %s t=%.1f hp=%.0f" % [e.tipo, t - bot_reg["t0"], player.hp])
	if bot_on and not bot_hechas.has("libre"): bot_hechas["libre"] = true; _foto("libre_a", 0.25); _foto("libre_b", 0.85)
	if e.tuto:
		tuto_vivo = false
		popup_text(tr("JUEGO_ESCARCHA_DESPRENDE"), Color(0.8, 0.93, 1.0))
	if e.guardian:
		guard_vivos -= 1; arpg["calmados"] += 1
		if guard_vivos == 0 and arpg["hojas"] == 2:
			popup_text(tr("JUEGO_CLARO_ESTA_CALMA_ENCIENDE_FAROLILLO"), Color(0.75, 1.0, 0.6))
			if bot_on: _foto("claro", 0.6)
	e.morir()

func _encender_farolillo() -> void:
	arpg["hojas"] = 3; bosque_esc.encender_farolillo(true); shake(5.0)
	popup_text(tr("JUEGO_FAROLILLO_RAIZ_BRILLA_OTRA_VEZ"), Estilo.ORO)
	_ganar_xp(40)
	get_tree().create_timer(2.6).timeout.connect(func():   # después de que la luz recorra las raíces y vuelvan las luciérnagas
		if modo != "bosque": return
		bosque_esc.poner_cofre(false); _rej_de = []; bosque_esc.poner_portal_claro()
		float_text(Bosque.COFRE + Vector2(0, -120), tr("JUEGO_HA_APARECIDO_COFRE"), Color(1, 0.9, 0.6)))
	arpg_guardar()
	bosque_esc.abrir_zarzas()
	get_tree().create_timer(4.0).timeout.connect(func():
		if modo != "bosque": return
		if _dar_pista("claro_musgo"): float_text(player.position + Vector2(0, -130), tr("JUEGO_ALGO_CRUJE_ZARZAS_OESTE"), Color(0.75, 1.0, 0.6)))
	if bot_on: _foto("farolillo", 1.6); _foto("derretido", 4.2)

func _abrir_cofre() -> void:
	arpg["cofre"] = true; bosque_esc.poner_cofre(true)
	oro_mas(60); arpg["cascaras"] += 3
	FX.burst(self, Bosque.COFRE + Vector2(0, -50), Color(1, 0.85, 0.4), 36, 380, 7)
	popup_text(tr("JUEGO_60_ORO_3_CASCARAS_BELLOTA"), Estilo.ORO)
	_ganar_xp(80); arpg_guardar()
	if bot_on: _foto("cofre", 0.5)

func _desmayo() -> void:
	if state != "jugando": return
	state = "desmayo"; bot_reg["desmayos"] += 1
	popup_text(tr("JUEGO_UY_HAS_DESMAYADO"), Color(1, 0.75, 0.6))
	print("BOT desmayo t=%.0f" % (t - bot_reg["t0"]))
	get_tree().create_timer(1.8).timeout.connect(func():
		start_raizal("bosque")
		popup_text(tr("JUEGO_DONA_PLUMAS_HA_TRAIDO_VUELTA"), Estilo.CREMA))

# ---- capturas del bot ----
func _foto(n: String, retraso: float) -> void:
	if bot_fotos == "": return
	get_tree().create_timer(retraso).timeout.connect(func():
		await RenderingServer.frame_post_draw
		get_viewport().get_texture().get_image().save_png(bot_fotos + n + ".png"); print("FOTO ", n))

# ---- bot de pruebas: juega el bucle entero (--bot_encargo [--god] [--bot_fotos=prefijo]) ----
func _bot(delta: float) -> void:
	bot_vec = Vector2.ZERO
	if state != "jugando" or player == null: return
	bot_tt += delta
	if bot_hp_ant >= 0.0 and player.hp < bot_hp_ant: bot_reg["vida_perdida"] += bot_hp_ant - player.hp; bot_reg["golpes"] += 1
	bot_hp_ant = player.hp
	if "--bot_traza" in OS.get_cmdline_user_args() and modo == "bosque" and int(bot_tt) != int(bot_tt - delta):
		var cerca := 0
		for en in enemies: if is_instance_valid(en) and en.position.distance_to(player.position) < 120.0: cerca += 1
		print("TRAZA t=%.0f pos=%s hp=%.0f cerca=%d guard=%d wp=%d lento=%.2f" % [t - bot_reg["t0"], Vector2i(player.position), player.hp, cerca, guard_vivos, bot_wp, lento_jug])
	var meta = null; var usar := ""
	var e: int = arpg["hojas"]
	if modo == "raizal":
		match e:
			0: return
			3:
				if dentro != "": meta = interior.aparece + Vector2(0, 200)
				else: meta = _npc("plumas")[0].position + Vector2(0, 70); usar = "hablar"
			2:
				# la visita a Gusana es opcional: el bot la hace para probarla (entra en su tienda, toma el té y sale)
				if not arpg.get("te_gusana", false) and not "--bot_sin_gusana" in OS.get_cmdline_user_args():
					if dentro == "herbolario": meta = _npc("gusana")[0].position + Vector2(0, 60); usar = "hablar"
					else:
						for pu in raizal_esc.puertas:
							if pu[0] != "herbolario": continue
							var ante: Vector2 = pu[1] + Vector2(0, 70)   # primero delante de la puerta, luego andar hacia ella
							if player.position.distance_to(ante) < 60.0: bot_hechas["ante_gusana"] = true
							meta = pu[1] + Vector2(0, -12) if bot_hechas.has("ante_gusana") else ante
				elif dentro != "": meta = interior.aparece + Vector2(0, 200)
				else: meta = Raizal.PUERTA_BOSQUE + Vector2(0, -60); usar = "bosque"
			4:
				if not bot_hechas.has("recompensa"):   # el primer encargo debe dar para la primera mejora (80 oro y 3 cáscaras)
					bot_hechas["recompensa"] = true
					print("BOT RECOMPENSA oro=%d cáscaras=%d %s" % [arpg["oro"], arpg["cascaras"], "OK" if arpg["oro"] >= 80 and arpg["cascaras"] >= 3 else "FALLA"])
				if dentro != "": meta = interior.aparece + Vector2(0, 200)
				else: meta = _npc("brasas")[0].position + Vector2(60, 70); usar = "hablar"
			_:
				if bot_hechas.has("fin"): return
				if bot_sec:
					var rs: Array = _bot_sec_raizal(); meta = rs[0]; usar = rs[1]
				else:
					print("BOT FIN t=%.0f s · bosque %.0f s · vida perdida %.0f · golpes %d · desmayos %d · nivel %d · oro %d · cáscaras %d · %s +%d" % [t - bot_reg["t0"], bot_reg["bosque_t"], bot_reg["vida_perdida"], bot_reg["golpes"], bot_reg["desmayos"], arpg["nivel"], arpg["oro"], arpg["cascaras"], _nombre_arma(), arpg["arma_mas"]])
					bot_hechas["fin"] = true
					if bot_fotos != "": _foto("fin", 0.8); get_tree().create_timer(2.0).timeout.connect(get_tree().quit)
					else: get_tree().quit()
					return
	elif modo == "zona":
		var rz: Array = _bot_zona(); meta = rz[0]; usar = rz[1]
	else:
		bot_reg["bosque_t"] += delta
		var ruta: Array = Bosque.SENDAS[0] + [Bosque.CLARO_C + Vector2(0, -150)]
		if e == 2:
			if bot_wp < ruta.size() and player.position.distance_to(ruta[bot_wp]) < 90.0: bot_wp += 1
			if bot_wp < ruta.size(): meta = ruta[bot_wp]
			elif guard_vivos > 0:
				var best = null; var bd := INF
				for en in enemies: if is_instance_valid(en) and en.guardian and en.position.distance_to(player.position) < bd: bd = en.position.distance_to(player.position); best = en
				meta = (best.position + (player.position - best.position).normalized() * 170.0) if best != null else Bosque.CLARO_C
			else: meta = Bosque.FAROLILLO + Vector2(0, 60); usar = "farolillo"
		elif not arpg["cofre"]: meta = Bosque.COFRE + Vector2(0, 50); usar = "cofre"
		else: meta = Bosque.PORTAL_C + Vector2(0, 30); usar = "portal"
		if bot_sec and e >= 5: var rb: Array = _bot_sec_bosque(); meta = rb[0]; usar = rb[1]
		if not bot_hechas.has("combate") and get_tree().get_nodes_in_group("marcas").size() > 0: bot_hechas["combate"] = true; _foto("combate", 0.25)
	if meta == null: return
	if "--bot_traza_sec" in OS.get_cmdline_user_args() and int(bot_tt / bot_traza_k) != int((bot_tt - delta) / bot_traza_k): print("TRAZA %s/%s/%s pos=%s meta=%s usar=%s cerca=%s vel=%s bichos=%s state=%s" % [modo, dentro, zona_id, Vector2i(player.position), Vector2i(meta), usar, salida_cerca, Vector2i(player.vel), enemies.filter(func(en): return is_instance_valid(en) and en.position.distance_to(player.position) < 260.0).map(func(en): return [en.kind, Vector2i(en.position)]), state])
	if modo == "raizal" and dentro == "" and not (e == 2 and not arpg.get("te_gusana", false) and meta.distance_to(player.position) < 140.0) and not (bot_sec and e >= 5): meta = _por_la_calle(meta)
	if bot_sec and (e >= 5 or modo == "zona") and meta.distance_to(player.position) > 130.0:
		var m0: Vector2 = meta; meta = _bot_camino(meta)
		if "--bot_traza_sec" in OS.get_cmdline_user_args() and int(bot_tt / bot_traza_k) != int((bot_tt - delta) / bot_traza_k): print("  CAMINO hacia %s -> %s" % [Vector2i(m0), Vector2i(meta)])
	var dv: Vector2 = meta - player.position
	var v: Vector2 = dv.normalized() if dv.length() > (10.0 if bot_sec and e >= 5 else 40.0) else Vector2.ZERO
	# esquivar: huir de los bichos muy cercanos y de las marcas del suelo
	if modo in ["bosque", "zona"] and not "--bot_torpe" in OS.get_cmdline_user_args():
		var huir := Vector2.ZERO
		for en in enemies:
			if not is_instance_valid(en): continue
			var d: Vector2 = player.position - en.position; var l: float = d.length()
			if l < 210.0 and l > 1.0: huir += d / l * (210.0 - l) / 210.0
		for mk in get_tree().get_nodes_in_group("marcas"):
			var d2: Vector2 = player.position - mk.position
			if mk.forma == "anillo":
				if d2.length() < mk.largo + 50.0: huir += d2.normalized() * 2.0
			else:
				var a_l: float = d2.dot(mk.dir); var lat: float = d2.dot(mk.dir.orthogonal())
				if a_l > -40.0 and a_l < mk.largo + 60.0 and abs(lat) < 90.0: huir += mk.dir.orthogonal() * (1.0 if lat >= 0.0 else -1.0) * 2.5
		if huir.length() > 0.3: v = (huir.normalized() * 1.4 + huir.orthogonal().normalized() * 0.6 + v * 0.5).normalized()
	# atasco: si no avanza, rodea
	if int(bot_tt * 2.0) != int((bot_tt - delta) * 2.0):
		if player.position.distance_to(bot_ult_pos) < 15.0 and v != Vector2.ZERO: bot_atasco = 0.8
		bot_ult_pos = player.position
	if bot_atasco > 0.0: bot_atasco -= delta; v = (v.orthogonal() + v * 0.3).normalized()
	bot_vec = v
	if usar != "" and salida_cerca == usar and (usar != "hablar" or modo == "zona" or npc_cerca != null and npc_cerca[3] == ("brasas" if e == 4 else ("gusana" if e == 2 else "plumas"))):
		if int(bot_tt * 2.0) != int((bot_tt - delta) * 2.0): _usar_salida(usar)

# ---- prueba: tira de 8 direcciones TAL CUAL se ven en el juego (--raizal --tira8=ruta.png) ----
func _tira8(ruta: String) -> void:
	await get_tree().create_timer(0.5).timeout
	var dirs := ["este", "sureste", "sur", "suroeste", "oeste", "noroeste", "norte", "noreste"]
	var lado := 180; var img := Image.create(lado * 4, lado * 8, false, Image.FORMAT_RGBA8)
	Engine.time_scale = 0.12   # cámara lenta: así cada fotograma del paso se captura aunque el render vaya lento
	var log := []
	for r in 8:
		var dv: Vector2 = _vec_mira(dirs[r])
		player.position = Vector2(0, 470) - dv * 120.0; cam.position = player.position; cam.reset_smoothing()
		andar_dir = dv
		await get_tree().create_timer(0.5 * 0.12, true, false, false).timeout
		var fila := []
		for i in 4:
			var esperado: Texture2D = player.fr8["caminar"][player.dir_anim()][i]
			var n := 0
			while player.spr.texture != esperado and n < 120: await get_tree().process_frame; n += 1
			await get_tree().process_frame   # medio paso dentro del fotograma (con el bote ya aplicado)
			await RenderingServer.frame_post_draw
			var vimg := get_viewport().get_texture().get_image()
			var sp: Vector2 = get_viewport().get_final_transform() * (get_viewport().get_canvas_transform() * (player.position + Vector2(0, -45)))
			var rect := Rect2i(int(sp.x) - lado / 2, int(sp.y) - lado / 2, lado, lado)
			img.blit_rect(vimg.convert_to(Image.FORMAT_RGBA8) if vimg.get_format() != Image.FORMAT_RGBA8 else vimg, rect, Vector2i(i * lado, r * lado))
			fila.append("%s flip=%s" % [player.spr.texture.resource_path.get_file().get_basename(), player.spr.flip_h])
		log.append("%-9s mira=%s -> %s" % [dirs[r], player.dir_act, " | ".join(fila)])
	andar_dir = Vector2.ZERO
	img.save_png(ruta)
	for l in log: print("TIRA ", l)
	get_tree().quit()

# ---- prueba: barrido lento del ángulo (como un stick) y cuenta de cambios de dirección ----
func _barrido() -> void:
	await get_tree().create_timer(0.5).timeout
	var cambios := 0; var ant := ""; var n := 0
	for k in 720:   # 2 vueltas en 12 s, con un temblor de ±4° como un stick real
		andar_dir = Vector2.from_angle(k * TAU / 360.0 + deg_to_rad(randf_range(-4.0, 4.0)))
		player.position = Vector2(0, 470)
		await get_tree().process_frame
		var d: String = player.spr.texture.resource_path.get_file().get_basename().rsplit("_", true, 1)[0]
		if d != ant: cambios += 1; ant = d
		n += 1
	print("BARRIDO fotogramas=%d cambios_de_direccion=%d (ideal 16)" % [n, cambios])
	cambios = 0
	for k in 300:   # 5 s con el stick justo en la frontera este/sureste (22,5°) y temblor de ±4°
		andar_dir = Vector2.from_angle(deg_to_rad(22.5 + randf_range(-4.0, 4.0)))
		player.position = Vector2(0, 470)
		await get_tree().process_frame
		var d: String = player.spr.texture.resource_path.get_file().get_basename().rsplit("_", true, 1)[0]
		if d != ant: cambios += 1; ant = d
	print("FRONTERA 5 s en 22,5°: cambios_de_direccion=%d (ideal 0-1)" % cambios)
	get_tree().quit()

# ---- prueba del diálogo: cualquier tecla / botón / clic avanza, con guarda de 0,15 s (--raizal --test_dlg) ----
func _test_dlg() -> void:
	await get_tree().create_timer(1.0).timeout
	var dl = dialogo
	var pos0 := player.position
	_hablar([["plumas", "Uno."], ["plumas", "Dos."], ["plumas", "Tres."], ["plumas", "Cuatro."], ["plumas", "Cinco."]], func(): print("DLG fin"), [], Callable(), "")
	var evs := []
	var k1 := InputEventKey.new(); k1.keycode = KEY_W; k1.physical_keycode = KEY_W; k1.pressed = true; evs.append(["tecla W (en guarda)", k1, 0.05])
	var k2 := InputEventKey.new(); k2.keycode = KEY_SPACE; k2.physical_keycode = KEY_SPACE; k2.pressed = true; evs.append(["Espacio", k2, 0.4])
	var k3 := InputEventKey.new(); k3.keycode = KEY_SPACE; k3.physical_keycode = KEY_SPACE; k3.pressed = true; k3.echo = true; evs.append(["Espacio auto-repetición", k3, 0.4])
	var m1 := InputEventMouseButton.new(); m1.button_index = MOUSE_BUTTON_RIGHT; m1.pressed = true; m1.position = Vector2(300, 300); evs.append(["clic derecho", m1, 0.4])
	var j1 := InputEventJoypadButton.new(); j1.button_index = JOY_BUTTON_B; j1.pressed = true; evs.append(["mando B", j1, 0.4])
	var k4 := InputEventKey.new(); k4.keycode = KEY_D; k4.physical_keycode = KEY_D; k4.pressed = true; evs.append(["tecla D", k4, 0.4])
	var k5 := InputEventKey.new(); k5.keycode = KEY_X; k5.physical_keycode = KEY_X; k5.pressed = true; evs.append(["tecla X (cierra)", k5, 0.4])
	for ev in evs:
		await get_tree().create_timer(ev[2]).timeout
		if ev[0] == "tecla D": Input.action_press("der")
		Input.parse_input_event(ev[1])
		await get_tree().process_frame
		print("DLG %s -> línea %d abierto=%s pos_mueve=%s" % [ev[0], dl.i, dl.abierto, player.position.distance_to(pos0) > 1.0])
	Input.action_release("der")
	await get_tree().create_timer(0.5).timeout
	print("DLG final abierto=%s estado=%s" % [dl.abierto, state])
	get_tree().quit()

# ---- prueba: la copa del Gran Árbol es un muro, no se cruza de lado a lado por arriba (--raizal --test_cruce) ----
func _test_cruce() -> void:
	await get_tree().create_timer(0.5).timeout
	for y0 in [-1300.0, -1000.0, -800.0, -700.0, -600.0, -480.0]:
		for lado in [-1.0, 1.0]:
			player.position = Vector2(-1150.0 * lado, y0)
			var dirx := "izq" if lado < 0 else "der"
			Input.action_press(dirx); Input.action_press("arriba")
			await get_tree().create_timer(2.0).timeout
			Input.action_release("arriba")
			await get_tree().create_timer(5.0).timeout
			Input.action_release(dirx)
			print("CRUCE desde %s -> %s cruzado=%s" % [Vector2i(-1150.0 * lado, y0), Vector2i(player.position), player.position.x * lado > 0.0])
	get_tree().quit()

# ---- prueba: todo Raizal de un vistazo (--raizal --vista_total --shot=...) ----
var vista_total := false
func _vista_total() -> void:
	vista_total = true; _limites_libres()
	if raizal_esc: raizal_esc.get_node("CopaGranArbol").modulate.a = 1.0
	if "--sin_hud" in OS.get_cmdline_user_args():   # mapa limpio: sin HUD ni capas de interfaz
		get_tree().create_timer(0.5).timeout.connect(func():
			for n in get_children(): if n is CanvasLayer and n.layer > 0 and n.name != "Fundido": n.visible = false)

# ---- prueba: entrar y salir andando de todas las casas (--raizal --etapa=5 --test_puertas) ----
# el bot sigue la Calle Mayor (curva) cuando va o viene de la parte baja del pueblo
func _por_la_calle(meta: Vector2) -> Vector2:
	var p: Vector2 = player.position
	if p.y < 560.0 and meta.y < 560.0:
		# p15: el tronco y las raíces de la Academia (y los matorrales y el Árbol de Cristal del cruce) cortan la diagonal de
		# la plaza a las casas de detrás (herbolario): por encima de la plaza, el bot va por la rejilla (_bot_camino)
		if dentro == "" and (meta.y < -150.0 or p.y < -150.0) and p.distance_to(meta) > 130.0: return _bot_camino(meta)
		return meta
	if dentro == "" and p.y < -150.0: return _bot_camino(Vector2(clampf(p.x, -900.0, 900.0), 200.0))   # p15: y a la vuelta, igual, hasta la plaza
	var C: Array = Raizal.CALLE
	if meta.y > p.y + 150.0:
		for c in C: if c.y > p.y + 40.0: return c if c.y < meta.y else meta
	elif meta.y < p.y - 150.0:
		for i in range(C.size() - 1, -1, -1): if C[i].y < p.y - 40.0: return C[i] if C[i].y > meta.y else meta
	return meta

# alcance: rejilla de 20 u, celdas libres = sin obstáculo a menos de r+16; BFS desde la plaza a puertas, PNJ y puerta del bosque
func _test_alcance() -> void:
	await get_tree().create_timer(0.4).timeout
	var A: Rect2 = Raizal.ARENA; var S := 20.0
	var nx: int = int(A.size.x / S); var ny: int = int(A.size.y / S)
	var libre := PackedByteArray(); libre.resize(nx * ny)
	for j in ny:
		for i in nx:
			var q := A.position + Vector2(i + 0.5, j + 0.5) * S; var ok := 1
			for o in obst:
				if q.distance_to(o[0]) < o[1] + 16.0: ok = 0; break
			libre[j * nx + i] = ok
	var vis := PackedByteArray(); vis.resize(nx * ny)
	var ini := Vector2i(((Vector2(0, 300) - A.position) / S).floor())
	var cola: Array = [ini]; vis[ini.y * nx + ini.x] = 1
	while not cola.is_empty():
		var c: Vector2i = cola.pop_back()
		for dd in [Vector2i(1, 0), Vector2i(-1, 0), Vector2i(0, 1), Vector2i(0, -1)]:
			var n: Vector2i = c + dd
			if n.x < 0 or n.y < 0 or n.x >= nx or n.y >= ny: continue
			var k: int = n.y * nx + n.x
			if vis[k] == 0 and libre[k] == 1: vis[k] = 1; cola.append(n)
	var metas: Array = []
	for pu in raizal_esc.puertas: metas.append([pu[0], pu[1] + Vector2(0, 60)])
	metas.append(["academia (a 30 u de la puerta)", Vector2(0, -300)])
	metas.append(["bosque", Raizal.PUERTA_BOSQUE + Vector2(0, -60)]); metas.append(["vuelta_bosque", Raizal.PUERTA_BOSQUE + Vector2(0, -210)])
	for h in raizal_esc.habitantes: metas.append([h[3], h[0].position + Vector2(0, 70)])
	for v in raizal_esc.vecinos:
		for r in (v[0].ruta if not v[0].ruta.is_empty() else [v[0].position]): metas.append([v[3], r])
	var malos := 0
	for m in metas:
		var c := Vector2i(((m[1] - A.position) / S).floor()); var hay := false
		for dy in range(-2, 3):
			for dx in range(-2, 3):
				var k: int = (c.y + dy) * nx + c.x + dx
				if k >= 0 and k < vis.size() and vis[k] == 1: hay = true
		if not hay: malos += 1; print("NO ALCANZABLE ", m[0], " ", Vector2i(m[1]))
	# ninguna puerta tapada: delante de cada puerta (hasta 90 u) todo libre
	for pu in raizal_esc.puertas:
		for yy in [20.0, 50.0, 90.0]:
			var q2: Vector2 = pu[1] + Vector2(0, yy)
			for o in obst: if q2.distance_to(o[0]) < o[1] + 14.0: print("PUERTA TAPADA ", pu[0], " y+", yy, " por ", Vector2i(o[0]), " r", int(o[1])); malos += 1; break
	# p13: nadie se mete dentro de una casa (la planta baja de la fachada): ninguna celda alcanzable bajo el cuerpo de la casa
	var casas_t: Array = []
	for c in Raizal.CASAS: casas_t.append([c[0], c[1], c[2], false])
	for c in Raizal.CASAS_DECO: casas_t.append(["d_" + c[0], c[1], c[2], c[3]])
	for c in casas_t:
		var m2: Dictionary = Raizal.PACK2["casas2"][c[0].trim_prefix("d_")]
		var kk: float = c[2] / (float(m2["base_y"]) - 8.0); var px: float = float(m2["puerta_x"]) * float(m2["w"])
		if c[3]: px = float(m2["w"]) - px
		var izq: float = (px - 8.0) * kk; var der: float = (float(m2["w"]) - px - 8.0) * kk
		var dentro_n := 0
		for j in ny:
			for i in nx:
				if vis[j * nx + i] == 0: continue
				var q := A.position + Vector2(i + 0.5, j + 0.5) * S
				if q.x > c[1].x - izq * 0.75 and q.x < c[1].x + der * 0.75 and q.y < c[1].y - 34.0 and q.y > c[1].y - c[2] * 0.72: dentro_n += 1   # (más arriba el tejado se estrecha: esquinas sin pintar)
		if dentro_n > 0: malos += 1; print("SE ENTRA EN LA CASA %s %s: %d celdas alcanzables dentro" % [c[0], Vector2i(c[1]), dentro_n])
	# bordes: ninguna celda alcanzable cerca del tope invisible del borde (ARENA): siempre se para antes contra algo visible
	var fugas := 0
	for j in ny:
		for i in nx:
			if vis[j * nx + i] == 0: continue
			if i < 4 or j < 4 or i >= nx - 4 or j >= ny - 4:
				fugas += 1
				if fugas % 40 == 1: print("FUGA AL BORDE ", Vector2i(A.position + Vector2(i + 0.5, j + 0.5) * S))
	if fugas > 0: malos += 1
	print("BORDES %s (celdas alcanzables a menos de 80 u del borde: %d)" % ["OK" if fugas == 0 else "FALLA", fugas])
	# muros invisibles: cada círculo de colisión debe tener algo pintado encima (sprites opacos; el suelo no cuenta)
	var sps: Array = []; var cubos := {}
	var pila: Array = [raizal_esc]
	while not pila.is_empty():
		var nd: Node = pila.pop_back()
		for ch in nd.get_children(): if not (ch.name in ["Suelo", "MapaLuz"]) and not ch.has_meta("suelo"): pila.append(ch)
		if nd is Sprite2D and nd.texture != null and nd.visible:
			var rr: Rect2 = nd.get_global_transform() * nd.get_rect()
			var idx := sps.size(); sps.append(nd)
			for cx in range(int(floor(rr.position.x / 200.0)), int(floor(rr.end.x / 200.0)) + 1):
				for cy in range(int(floor(rr.position.y / 200.0)), int(floor(rr.end.y / 200.0)) + 1):
					var key := Vector2i(cx, cy)
					if not cubos.has(key): cubos[key] = []
					cubos[key].append(idx)
	var invis := 0; var junto := 0
	for o in obst:
		var vista := false
		for off in [Vector2.ZERO, Vector2(0.5, 0), Vector2(-0.5, 0), Vector2(0, 0.5), Vector2(0, -0.5)]:
			var q3: Vector2 = o[0] + off * o[1]
			for idx in cubos.get(Vector2i(int(floor(q3.x / 200.0)), int(floor(q3.y / 200.0))), []):
				var sp: Sprite2D = sps[idx]
				if sp.is_pixel_opaque(sp.to_local(q3)): vista = true; break
			if vista: break
		if not vista:   # p15: los círculos del contorno que impiden quedar tapado tocan el dibujo por el borde: vale si hay dibujo a <= 32 u del círculo (el ancho de la base de la pared)
			var cerca_d := false
			for dist in [8.0, 14.0, 20.0, 26.0, 32.0]:
				for ang in 8:
					var q5: Vector2 = o[0] + Vector2.from_angle(ang * TAU / 8.0) * (o[1] + dist)
					for idx in cubos.get(Vector2i(int(floor(q5.x / 200.0)), int(floor(q5.y / 200.0))), []):
						var sp5: Sprite2D = sps[idx]
						if sp5.is_pixel_opaque(sp5.to_local(q5)): cerca_d = true; break
					if cerca_d: break
				if cerca_d: break
			if not cerca_d:   # o el dibujo taparía al niño ahí (huecos estrechos entre dos casas pegadas)
				for ct in raizal_esc.contornos: if (ct[0] as Sprite2D).position.distance_to(o[0]) < 700.0 and raizal_esc.tapa(ct[0], o[0]) >= 0.2: cerca_d = true; break
			if cerca_d: junto += 1
			else:
				invis += 1
				if invis <= 40: print("COLISION SIN NADA VISIBLE ", Vector2i(o[0]), " r", int(o[1]))
	if invis > 0: malos += 1
	print("JUNTO AL DIBUJO %d círculos (a <= 32 u del borde pintado)" % junto)
	var control := 0   # control del propio test: puntos de hierba vacía no deben contar como pintados
	for q4 in [Vector2(0, 300), Vector2(-600, 600), Vector2(700, 1200)]:
		for idx in cubos.get(Vector2i(int(floor(q4.x / 200.0)), int(floor(q4.y / 200.0))), []):
			if sps[idx].is_pixel_opaque(sps[idx].to_local(q4)): control += 1; print("CONTROL pintado en ", q4, " por ", sps[idx].get_path(), " ", sps[idx].texture.resource_path, " ", sps[idx].texture.get_size(), " mat ", sps[idx].material)
	print("CONTROL TEST ", "OK" if control == 0 else "FALLA")
	print("INVISIBLES %s (%d de %d círculos sin nada pintado encima)" % ["OK" if invis == 0 else "FALLA", invis, obst.size()])
	var tapados := int(raizal_esc.get_meta("academia_tapados", 0))   # p15: nada de Raizal escondido bajo el árbol de la Academia
	print("ACADEMIA %s (%d cosas tapadas por el árbol)" % ["OK" if tapados == 0 else "FALLA", tapados]); malos += tapados
	print("ALCANCE %s (%d metas)" % ["OK" if malos == 0 else "FALLA %d" % malos, metas.size()])
	get_tree().quit()

# p15 · bot que intenta colarse en cada casa y edificio con contorno: rozando la fachada delantera (empujando hacia ella),
# en diagonal hacia la puerta desde los dos lados, desde los costados y desde detrás. En cada fotograma mide qué parte del
# cuerpo del niño tapa el dibujo (Raizal.tapa); fuera del hueco justo de la puerta no puede pasar del 40 %.
func _test_colarse() -> void:
	await get_tree().create_timer(0.6).timeout
	Engine.time_scale = 2.0
	if "--colarse_tirones" in OS.get_cmdline_user_args(): Engine.max_fps = 10   # p15c: pasos de ~45 u por fotograma (tirones)
	var malos := 0; var peor_g := 0.0
	for ct in raizal_esc.contornos:
		var sp: Sprite2D = ct[0]; var pu: Vector2 = ct[1]; var pies: Vector2 = sp.position
		var im: Image = raizal_esc.alfa_de(sp.texture); var k: float = sp.scale.x
		var o: Vector2 = sp.offset if not sp.centered else sp.offset - Vector2(im.get_width(), im.get_height()) / 2.0
		var r := Rect2(pies + o * k, Vector2(im.get_width(), im.get_height()) * k)
		var w: float = r.size.x
		var rutas: Array = [
			[Vector2(r.position.x - 30, pies.y + 12), Vector2(1, -0.35)], [Vector2(r.end.x + 30, pies.y + 12), Vector2(-1, -0.35)],
			[Vector2(r.position.x - 30, pies.y + 40), Vector2(1, -0.6)], [Vector2(r.end.x + 30, pies.y + 40), Vector2(-1, -0.6)],
			[pies + Vector2(-130, 130), Vector2(1, -1.3)], [pies + Vector2(130, 130), Vector2(-1, -1.3)],
			[pies + Vector2(-70, 70), Vector2(1, -1.6)], [pies + Vector2(70, 70), Vector2(-1, -1.6)],
			[pies + Vector2(-w * 0.3, 90), Vector2(0, -1)], [pies + Vector2(w * 0.3, 90), Vector2(0, -1)],
			[Vector2(r.position.x - 40, pies.y - 30), Vector2(1, 0)], [Vector2(r.end.x + 40, pies.y - 30), Vector2(-1, 0)],
			[Vector2(r.position.x - 40, pies.y - r.size.y * 0.4), Vector2(1, 0.15)], [Vector2(r.end.x + 40, pies.y - r.size.y * 0.4), Vector2(-1, 0.15)],
			[Vector2(pies.x, r.position.y - 40), Vector2(0, 1)], [Vector2(r.position.x, r.position.y - 30), Vector2(1, 1)], [Vector2(r.end.x, r.position.y - 30), Vector2(-1, 1)]]
		var peor := 0.0; var donde := Vector2.ZERO; var hechas := 0; var ru_peor = null
		for ru in rutas:
			var ini: Vector2 = ru[0]
			if raizal_esc.has_method("libre") and not raizal_esc.libre(ini, 16.0): continue
			var bloqueado := false
			for ob in raizal_esc.obst: if ini.distance_to(ob[0]) < ob[1] + 16.0: bloqueado = true; break
			if bloqueado: continue
			var tw := t
			while state != "jugando" and t - tw < 15.0:
				if dialogo.get("abierto"): dialogo.avanzar()
				await get_tree().create_timer(0.25).timeout
			player.position = ini; player.vel = Vector2.ZERO; cam.position = ini; andar_dir = (ru[1] as Vector2).normalized()
			puerta_guarda = 1e9; hechas += 1
			var t0 := t
			while t - t0 < 1.4 and dentro == "":
				await get_tree().process_frame
				var q: Vector2 = player.position
				if pu != Vector2.INF and absf(q.x - pu.x) < Raizal.HUECO_PUERTA.x and q.y > pu.y - Raizal.HUECO_PUERTA.y: continue   # el hueco de la puerta
				for ct2 in raizal_esc.contornos:
					if (ct2[0] as Sprite2D).position.distance_to(q) > 700.0: continue
					var c: float = raizal_esc.tapa(ct2[0], q)
					if c > peor: peor = c; donde = q; ru_peor = ru
			andar_dir = Vector2.ZERO
		puerta_guarda = 0.0
		peor_g = maxf(peor_g, peor)
		var ok := peor <= 0.4
		if not ok: malos += 1
		if not ok and ru_peor != null: print("COLARSE   ruta desde %s hacia %s" % [Vector2i(ru_peor[0]), ru_peor[1]])
		print("COLARSE %s %s %s: %d rutas, lo más tapado %d %% en %s" % ["OK" if ok else "FALLA", sp.name, Vector2i(pies), hechas, int(peor * 100), Vector2i(donde)])
	Engine.time_scale = 1.0
	print("COLARSE %s (%d de %d casas y edificios; lo más tapado %d %%)" % ["OK" if malos == 0 else "FALLA", malos, raizal_esc.contornos.size(), int(peor_g * 100)])
	get_tree().quit()

func _test_puertas() -> void:
	await get_tree().create_timer(0.6).timeout
	var ok := 0
	for pu in raizal_esc.puertas:
		# p15: a los ~8 s salta sola una escena con diálogo (estado "dialogo") y el niño ya no andaba: la prueba daba 3 / 10.
		# Se pasan las líneas del diálogo que esté abierto antes de probar cada puerta.
		var tw := t
		while state != "jugando" and t - tw < 15.0:
			if dialogo.get("abierto"): dialogo.avanzar()
			await get_tree().create_timer(0.25).timeout
		player.position = pu[1] + Vector2(0, 90); cam.position = player.position
		andar_dir = Vector2.UP
		var t0 := t
		while dentro == "" and t - t0 < 3.0: await get_tree().process_frame
		andar_dir = Vector2.ZERO
		var entro: bool = dentro == pu[0]
		await get_tree().create_timer(0.6).timeout
		var libre: bool = interior != null and interior.libre(interior.aparece, 16.0)
		var gente_ok := true
		if interior:
			for h in interior.habitantes: if not interior.libre(h[0].position, 6.0): gente_ok = false
		andar_dir = Vector2.DOWN
		t0 = t
		while dentro != "" and t - t0 < 4.0: await get_tree().process_frame
		andar_dir = Vector2.ZERO
		var salio: bool = dentro == ""
		await get_tree().create_timer(1.0).timeout
		var no_reentra: bool = dentro == "" and player.position.distance_to(pu[1]) > 40.0
		print("PUERTA %s entra=%s aparicion_libre=%s gente_en_suelo=%s sale=%s no_reentra=%s pos=%s" % [pu[0], entro, libre, gente_ok, salio, no_reentra, Vector2i(player.position)])
		if entro and salio and no_reentra and libre and gente_ok: ok += 1
	print("PUERTAS OK %d / %d" % [ok, raizal_esc.puertas.size()])
	# casas de adorno (p11): andar contra su puerta NO debe meterte dentro ni dejarte cruzar la fachada
	var cerradas := 0; var abiertas_ok: Array = []
	for pu in raizal_esc.puertas: abiertas_ok.append(pu[1])
	for k in Raizal.CASAS_DECO.size():
		var c: Array = Raizal.CASAS_DECO[k]
		if c[1] in abiertas_ok: cerradas += 1; continue   # casa de piedra ya abierta por la historia
		player.position = c[1] + Vector2(0, 90); cam.position = player.position
		andar_dir = Vector2.UP
		var t1 := t; var ymin: float = player.position.y
		while t - t1 < 2.5:
			await get_tree().process_frame; ymin = min(ymin, player.position.y)
		andar_dir = Vector2.ZERO
		var cerrada: bool = dentro == "" and state == "jugando" and ymin > c[1].y + 6.0   # ni siquiera sube al escalón
		print("CASA_ADORNO d%d %s cerrada=%s y_min_rel=%.0f dentro='%s'" % [k, c[0], cerrada, ymin - c[1].y, dentro])
		if cerrada: cerradas += 1
		if dentro != "": _salir(); await get_tree().create_timer(1.0).timeout
	print("CASAS_ADORNO CERRADAS %d / %d" % [cerradas, Raizal.CASAS_DECO.size()])
	print("ARCO_CORRAL %s" % ("MAL: sigue en Raizal" if raizal_esc.get_node_or_null("corral_entrada") else "fuera OK"))
	get_tree().quit()

# ---- prueba de menús: portada, 5 toques al título, pausa > Árbol > Volver; Compañeros no aparece en ningún menú (19/10, 20:15) ----
func _botones(n: Node) -> Array:
	var r: Array = []
	for c in n.get_children():
		if c is Button and c.is_visible_in_tree(): r.append(c)
		r += _botones(c)
	return r
func _textos(n: Node) -> Array: return _botones(n).map(func(b): return b.text)
func _test_menus() -> void:
	var mal := 0
	state = "menu"; menu.visible = true; menu.mostrar("principal"); await get_tree().process_frame; await get_tree().process_frame
	var t := _textos(menu); print("PORTADA ", t)
	for x in ["Árbol de Cristal", "Compañeros"]: if x in t: mal += 1; print("MAL: ", x, " sigue en la portada")
	if not (tr("JUEGO_NUEVA_PARTIDA") in t and tr("JUEGO_AJUSTES") in t): mal += 1
	var tit: Label = null
	for l in menu.find_children("*", "Label", true, false): if l.text == tr("JUEGO_ROOTHEART"): tit = l
	for i in 5:
		var ev := InputEventMouseButton.new(); ev.pressed = true; ev.button_index = MOUSE_BUTTON_LEFT; tit.gui_input.emit(ev)
	await get_tree().process_frame; await get_tree().process_frame
	t = _textos(menu); print("TRAS 5 TOQUES ", t)
	if "Modo clásico" in t: mal += 1; print("MAL: acceso clásico sigue disponible")
	menu.visible = false; start_raizal(); await get_tree().create_timer(0.5).timeout
	if state == "dialogo": state = "jugando"
	pausa.alternar(); await get_tree().process_frame
	var tp := _textos(pausa); print("PAUSA ", tp)
	if "Compañeros" in tp: mal += 1; print("MAL: Compañeros sigue en la pausa")
	menu.mostrar("companeros"); await get_tree().process_frame
	if menu.find_children("*", "GridContainer", true, false).size() > 0: mal += 1; print("MAL: la pantalla Compañeros todavía se abre")
	menu.visible = false; state = "pausa"
	# sin compañeros en ningún sitio: ni corral jugable, ni datos guardados, ni textos en la pausa/portada
	for sl in Raizal.SALIDAS: if sl[0] == "corral": mal += 1; print("MAL: el Corral sigue siendo una entrada")
	if modo != "zona" and modo != "bosque" and companero != null: mal += 1; print("MAL: hay un compañero activo fuera del ARPG")
	print("DATOS COMPAÑERO conservados: companero=", Guardado.d.get("companero", "-"), " conocidos=", Guardado.d.get("comp_conocidos", []))
	for tx in _textos(pausa) + _textos(menu): if "ompañer" in tx: mal += 1; print("MAL: texto con compañero: ", tx)
	pausa.alternar(); await get_tree().process_frame
	for dest in [tr("JUEGO_ARBOL_CRISTAL"), tr("JUEGO_AJUSTES")]:
		pausa.alternar(); await get_tree().process_frame
		var bs := _botones(pausa).filter(func(b): return b.text == dest)
		if bs.is_empty(): mal += 1; print("MAL: falta ", dest, " en la pausa"); continue
		bs[0].pressed.emit(); await get_tree().process_frame; await get_tree().process_frame
		print("ABIERTO ", dest, " pantalla=", menu.pantalla, " visible=", menu.visible, " state=", state)
		var vol := _botones(menu).filter(func(b): return b.name == "Volver")
		if vol.is_empty(): mal += 1; print("MAL: sin Volver"); continue
		vol[0].pressed.emit(); await get_tree().process_frame; await get_tree().process_frame
		print("VUELTA state=", state, " pausa=", pausa.panel != null, " menu.visible=", menu.visible)
		if state != "pausa" or pausa.panel == null or menu.visible: mal += 1
		pausa.alternar(); await get_tree().process_frame
	print("MENUS ", "OK" if mal == 0 else "FALLA %d" % mal)
	get_tree().quit(0 if mal == 0 else 1)


# ---- prueba de interiores (20/10, p7): --test_interiores ----
# Por cada sala: relleno desde la aparición (rejilla de 10 u, radio del jugador 16) -> % de suelo libre alcanzable;
# cada "zona" (cocina, dormitorios, rincones) alcanzable; ningún trozo de suelo libre sin llegar; la salida SOLO por el hueco
# de la puerta; y ningún mueble sólido que en el dibujo sea suelo (colisión invisible: color del suelo bajo el rectángulo).
func _test_interiores() -> void:
	await get_tree().process_frame
	var fallos := 0; var hechas := {}
	for casa in Interior.CASA_SALA.keys():
		var sid: String = Interior.CASA_SALA[casa]
		var it: Interior = Interior.build(self, casa); it.visible = false
		var malos := 0
		for h in it.habitantes:
			if not it.libre(h[0].position, 6.0): print("INT %s: %s fuera del suelo %s" % [casa, h[1], Vector2i(h[0].position / Interior.DS)]); malos += 1
		if not hechas.has(sid):
			hechas[sid] = true
			var S := 10.0; var nx: int = int(Interior.TAM.x / S); var ny: int = int(Interior.TAM.y / S)
			var libre := PackedByteArray(); libre.resize(nx * ny); var nlib := 0
			for j in ny:
				for i in nx:
					var q := Vector2(i + 0.5, j + 0.5) * S
					if q.y < it.suelo.end.y and it.libre(q, 16.0): libre[j * nx + i] = 1; nlib += 1
			var vis := PackedByteArray(); vis.resize(nx * ny)
			var c0 := Vector2i((it.aparece / S).floor()); var cola: Array = [c0]; vis[c0.y * nx + c0.x] = 1; var nvis := 1
			while not cola.is_empty():
				var c: Vector2i = cola.pop_back()
				for dd in [Vector2i(1, 0), Vector2i(-1, 0), Vector2i(0, 1), Vector2i(0, -1)]:
					var n: Vector2i = c + dd
					if n.x < 0 or n.y < 0 or n.x >= nx or n.y >= ny: continue
					var k: int = n.y * nx + n.x
					if vis[k] == 0 and libre[k] == 1: vis[k] = 1; nvis += 1; cola.append(n)
			# trozos de suelo libre a los que no se llega
			var sueltos := 0
			for j in ny:
				for i in nx:
					if libre[j * nx + i] == 1 and vis[j * nx + i] == 0:
						sueltos += 1
						if sueltos % 15 == 1: print("  suelto en px ", Vector2i(Vector2(i + 0.5, j + 0.5) * S / Interior.DS))
			if sueltos > 20: print("INT %s: %d celdas de suelo libre sin llegar" % [sid, sueltos]); malos += 1
			for z in it.sala.get("zonas", {}).keys():
				var zp: Vector2 = Vector2(it.sala["zonas"][z][0], it.sala["zonas"][z][1]) * Interior.DS
				var cz := Vector2i((zp / S).floor()); var hay := false
				for dy in range(-2, 3):
					for dx in range(-2, 3):
						var k2: int = (cz.y + dy) * nx + cz.x + dx
						if k2 >= 0 and k2 < vis.size() and vis[k2] == 1: hay = true
				if not hay: print("INT %s: zona '%s' sin llegar" % [sid, z]); malos += 1
			# puerta: bajando por el borde de abajo sólo se sale por el hueco
			var sale_fuera := 0; var sale_hueco := 0
			var x := it.suelo.position.x + 20.0
			while x < it.suelo.end.x - 20.0:
				var p := it.resolver(Vector2(x, it.suelo.end.y - 30.0), 16.0)
				var inicio_x := p.x # la muestra puede caer dentro de un sofá: evaluar desde el suelo al que se resolvió
				for k3 in 30: p = it.resolver(p + Vector2(0, 12), 16.0)
				if p.y > it.salida_y:
					if inicio_x > it.puerta.x + 16.0 and inicio_x < it.puerta.y - 16.0: sale_hueco += 1
					else: sale_fuera += 1; print("  sale fuera del hueco en px x=", int(x / Interior.DS), " (hueco ", Vector2i(it.puerta / Interior.DS), ")")
				x += 10.0
			if sale_fuera > 0 or sale_hueco == 0: print("INT %s: salida mal (fuera del hueco %d, por el hueco %d)" % [sid, sale_fuera, sale_hueco]); malos += 1
			# colisión invisible: rectángulo de mueble que en el dibujo es casi todo suelo
			var img: Image = load(Interior.R + it.sala["img"]).get_image(); img.resize(819, 460)
			var refs: Array = []
			for z in it.sala.get("zonas", {}).values() + [it.sala["sale"]]: refs.append(img.get_pixel(int(z[0]), int(z[1])))
			var invis := 0
			for s in it.sala["solidos"]:
				var tot := 0; var suelo_n := 0
				for yy in range(int(s[1]), int(s[3]), 3):
					for xx in range(int(s[0]), int(s[2]), 3):
						if xx < 0 or yy < 0 or xx >= 819 or yy >= 460: continue
						var col: Color = img.get_pixel(xx, yy); tot += 1
						for rc in refs:
							if absf(col.r - rc.r) + absf(col.g - rc.g) + absf(col.b - rc.b) < 0.16: suelo_n += 1; break
				if tot > 0 and float(suelo_n) / tot > 0.8: print("INT %s: mueble %s casi todo suelo (%d %%)" % [sid, s, 100 * suelo_n / tot]); invis += 1
			if invis > 0: malos += 1
			print("INTERIOR %s: suelo alcanzable %d %% (%d de %d celdas libres), zonas %d, sueltos %d, salida por hueco %d / fuera %d, muebles invisibles %d" % [sid, 100 * nvis / max(1, nlib), nvis, nlib, it.sala.get("zonas", {}).size(), sueltos, sale_hueco, sale_fuera, invis])
		if malos > 0: fallos += 1
		it.queue_free()
	print("INTERIORES %s (%d casas con fallos)" % ["OK" if fallos == 0 else "FALLA", fallos])
	get_tree().quit()

# ===================== Zonas secretas, compañeros por exploración y la bruja (19/10, 23:36) =====================
# Diseño aprobado (decisiones_noche.md §109, diseno_mvp.md): sin minijuego de caza ni pantalla de compañeros. Cada zona secreta
# guarda a uno de los cuatro (Brasa, Escarcha, Musguito, Chispa), un trozo del pergamino, un objeto único y un cofre.
# Uno te sigue y pelea contigo; los demás descansan en su rincón del refugio, donde la bruja te deja elegir y hacerlos crecer.
var zona_n: Zona = null
var zona_id := ""
var zona_t := 0.0
var comp_dormido = null       # el de esta zona, dormido hasta que llegas
var frag_spr: Node2D = null
var cofre_z: Sprite2D = null
var tram_t := 0.0
const COMP_MULT := 0.22       # equilibrio del daño de compañeros en el bosque
const TUNEL_HALL := Vector2(420, 280)   # px de la lámina: sala central de los túneles (el bot pasa por aquí)
var bot_sec := "--bot_secretos" in OS.get_cmdline_user_args()

func segura() -> bool: return modo == "raizal" or (modo == "zona" and zona_n != null and zona_n.segura)

func _dar_pista(zid: String) -> bool:
	if not Secretos.poner(arpg, "pistas", zid): return false
	arpg_guardar(); if bot_on: print("BOT pista ", zid)
	return true

# el que te sigue (si lo hay). Las Crías no pelean (20/10): solo su ayuda pasiva. Chispa lleva su luz (radio de la pasiva)
func _poner_companero() -> void:
	if companero != null and is_instance_valid(companero): companero.queue_free()
	companero = null
	var c: String = str(arpg.get("sigue", ""))
	if not COMPANEROS_ACTIVOS or not Secretos.tiene(arpg, "comps", c): return
	companero = _nodo_comp(c)
	if c == "chispa": _luz_chispa(companero)
func _nodo_comp(c: String, pos := Vector2.INF, reposa := false):
	var n := Node2D.new(); n.set_script(load("res://companero.gd")); n.tipo = c; n.mult = COMP_MULT; n.evo = Secretos.evo(arpg, c)
	if reposa: n.reposa = pos
	elif pos != Vector2.INF: n.aparecer_en = pos
	add_child(n); return n
func _luz_chispa(n) -> void:
	var l: MapaLuz = null
	if modo == "zona" and zona_n: l = zona_n.luces
	elif modo == "bosque" and bosque_esc: l = bosque_esc.luces
	if l: n.luz = l.luz(n.position, n.radio_luz() * 1.9, Color(0.62, 0.5, 0.85))   # su luz marca el radio que revela los objetos misteriosos

# ---- pasivas aprobadas (20/10): objetos misteriosos (Chispa) y avisos de secretos (Escarcha) ----
var misterios_n: Array = []   # [nodo, definición]
var avisos_hechos := {}
func _poner_misterios(mapa: String) -> void:
	for it in misterios_n: if is_instance_valid(it[0]): it[0].queue_free()
	misterios_n.clear(); avisos_hechos = {}
	for m in Secretos.MISTERIOS:
		if m["mapa"] != mapa or Secretos.tiene(arpg, "misterios", m["id"]): continue
		var n := Node2D.new(); n.name = "Misterio_" + m["id"]; n.visible = false
		n.position = zona_n.px(m["px"]) if m.has("px") and zona_n != null else m.get("pos", Vector2.ZERO)
		var sp := Sprite2D.new(); sp.texture = load("res://assets/bosque/bolsa_botin.png"); sp.centered = false
		sp.offset = Vector2(-sp.texture.get_width() / 2.0, -sp.texture.get_height() + 10.0); sp.scale = Vector2.ONE * (40.0 / sp.texture.get_height())
		sp.modulate = Color(0.85, 0.75, 1.0); sp.texture_filter = CanvasItem.TEXTURE_FILTER_LINEAR_WITH_MIPMAPS; n.add_child(sp)
		add_child(n); misterios_n.append([n, m])
		var l: MapaLuz = zona_n.luces if modo == "zona" and zona_n else (bosque_esc.luces if modo == "bosque" and bosque_esc else null)
		if l: var lz: Sprite2D = l.luz(n.position + Vector2(0, -12), 110.0, Color(0.7, 0.55, 1.0)); lz.visible = false; n.set_meta("luz", lz)
func chispa_revela(c: Vector2, r: float) -> void:   # lo llama Chispa cada frame: lo que cae dentro de su luz se ve
	for it in misterios_n:
		if is_instance_valid(it[0]) and it[0].position.distance_to(c) < r: it[0].set_meta("rev", t)
func _misterios_tick() -> void:
	for it in misterios_n.duplicate():
		var n: Node2D = it[0]
		if not is_instance_valid(n): misterios_n.erase(it); continue
		var antes: bool = n.visible
		n.visible = float(n.get_meta("rev", -9.0)) >= t - 0.06   # invisible fuera del radio de Chispa, también de día
		if n.has_meta("luz") and is_instance_valid(n.get_meta("luz")): n.get_meta("luz").visible = n.visible
		if n.visible:
			n.scale = Vector2.ONE * (1.0 + sin(t * 4.0) * 0.06)
			if not antes: FX.burst(self, n.position + Vector2(0, -14), Color(0.8, 0.7, 1.0), 10, 120, 3)
			if player and state == "jugando" and player.position.distance_to(n.position) < 42.0: _coger_misterio(it)
func _coger_misterio(it: Array) -> void:
	var m: Dictionary = it[1]; var da: Array = m["da"]
	Secretos.poner(arpg, "misterios", m["id"])
	oro_mas(da[0]); arpg["cascaras"] += da[1]; arpg["esporas"] = int(arpg.get("esporas", 0)) + da[2]
	var partes: Array = []
	if da[0] > 0: partes.append(tr("JUEGO_ORO") % da[0])
	if da[1] > 0: partes.append(tr("JUEGO_CASCARAS") % da[1])
	if da[2] > 0: partes.append(tr("JUEGO_ESPORAS_2") % da[2])
	FX.burst(self, it[0].position + Vector2(0, -16), Color(0.85, 0.75, 1.0), 22, 260, 5)
	popup_text(tr("JUEGO_OBJETO_MISTERIOSO") + " · ".join(partes), Color(0.85, 0.78, 1.0))
	if it[0].has_meta("luz") and is_instance_valid(it[0].get_meta("luz")): it[0].get_meta("luz").queue_free()
	it[0].queue_free(); misterios_n.erase(it); arpg_guardar()
	if bot_on: print("BOT misterio ", m["id"])
func escarcha_avisa(c: Vector2) -> void:   # lo llama Escarcha cada frame: avisa una vez por visita de cada secreto cercano
	var mapa: String = modo if modo in ["bosque", "raizal"] else zona_id
	if dentro != "": return   # dentro de una casa no hay secretos del pueblo que avisar
	for a in Secretos.AVISOS.get(mapa, []):
		if avisos_hechos.has(a[0]): continue
		var p: Vector2 = zona_n.px(a[1]) if modo == "zona" and zona_n != null else a[1]
		if c.distance_to(p) > 340.0: continue
		avisos_hechos[a[0]] = true
		FX.burst(self, p + Vector2(0, -20), Color(0.65, 0.88, 1.0), 18, 220, 4)
		float_text(p + Vector2(0, -80), a[2], Color(0.75, 0.92, 1.0))
		popup_text(tr("JUEGO_ESCARCHA_NOTA_ALGO"), Color(0.75, 0.92, 1.0))
		if bot_on: print("BOT aviso ", a[0])

func start_zona(zid: String, desde := "") -> void:
	if not arpg.is_empty(): arpg_guardar()
	limpiar_partida(); modo = "zona"; zona_id = zid; companero = null; raizal_esc = null; bosque_esc = null; comp_dormido = null; frag_spr = null; cofre_z = null
	if interior: interior.queue_free(); interior = null
	dentro = ""; zona_t = 0.0; bot_visita += 1; bot_swp = 0
	for e in enemies: if is_instance_valid(e): e.queue_free()
	enemies.clear(); trails.clear(); stats = {}; get_tree().paused = false
	arma = Personajes.LISTA[pj]["arma"]; arma_nv = 1; kills = 0; lento_jug = 0.0; tuto_vivo = false; guard_vivos = 0; guard_tot = 0
	if has_node("Escenario"): var old := get_node("Escenario"); remove_child(old); old.queue_free()
	zona_n = Zona.build(self, zid); obst = []; _rej_de = []
	arena = zona_n.arena
	RenderingServer.set_default_clear_color(Color(0.03, 0.03, 0.04))
	if player: player.queue_free()
	player = Node2D.new(); player.set_script(load("res://player.gd")); add_child(player)
	player.died.connect(_on_died)
	player.position = zona_n.aparece; player.mira = Vector2.UP
	alive_time = 0.0; state = "jugando"
	recalc_stats(); player.hp = player.max_hp
	if zid == "refugio":
		arpg["refugio_visto"] = true
		var b := Node2D.new(); b.set_script(load("res://bruja.gd")); b.position = zona_n.puntos["bruja"]; zona_n.add_child(b)
		zona_n.habitantes.append([b, tr("NOMBRE_BRUJA"), "", "bruja"])
		_rincones()
	else:
		var z: Dictionary = Secretos.ZONAS[zid]
		var bp: Array = []
		var lb: Array = zona_n.d.get("bichos", [])
		for k in lb.size():
			if lb[k] is Array: bp.append([lb[k][0], zona_n.px(lb[k][1])])
			else: bp.append([lb[k], zona_n.bichos_pos[k % zona_n.bichos_pos.size()]])
		# p17: los Dormur, sueltos; los demás, en una banda de 5 con su líder (flojitos: vida x0,6)
		bandas = []; turnos = {}
		var resto: Array = []; var c0 := Vector2.INF
		for bb in bp:
			if bb[0] == "murcielago":
				var e := Node2D.new(); e.set_script(load("res://bicho.gd")); e.setup(bb[0], bb[1], false); e.hp *= 0.6; e.max_hp = e.hp; add_child(e); e.escarcha = true; enemies.append(e)
			else:
				resto.append(bb[0])
				if c0 == Vector2.INF: c0 = bb[1]
		if not resto.is_empty():
			var tl: Array = resto.duplicate()
			while tl.size() < 4: tl.append(resto[tl.size() % resto.size()])
			tl.append("lider:" + resto[0])
			var rng2 := RandomNumberGenerator.new(); rng2.randomize()
			for e in poner_banda(c0, tl, false, 110.0, rng2, 0.6): e.escarcha = true
		if not Secretos.tiene(arpg, "comps", z["comp"]):
			comp_dormido = _nodo_comp(z["comp"], zona_n.puntos["comp"]); comp_dormido.duerme = true
			if zid == "tuneles": zona_n.luces.luz(zona_n.puntos["comp"], 140.0, Color(0.5, 0.4, 0.7))   # un brillito al fondo del túnel
		if not Secretos.tiene(arpg, "frags", z["frag"]): _poner_frag(z["frag"])
		cofre_z = _sprite_z(load("res://assets/bosque/cofre_%s.png" % ("abierto" if Secretos.tiene(arpg, "cofres_z", zid) else "cerrado")), zona_n.puntos["cofre"], 80.0)
	_poner_companero(); _poner_misterios(zid)
	cam.position = _cam_meta(); cam.reset_smoothing(); _limites_zona()
	_zoom_mundo()
	popup_text(tr("JUEGO_REFUGIO_BRUJA") if zid == "refugio" else tr(Secretos.ZONAS[zid]["n"]), Estilo.ORO)
	arpg_guardar()
	if bot_on: print("BOT zona ", zid); _foto("zona_" + zid, 1.2)

func _limites_zona() -> void:
	if zona_n == null: return
	if zona_n.segura: _limites_libres(); return
	cam.limit_left = int(arena.position.x); cam.limit_top = int(arena.position.y); cam.limit_right = int(arena.end.x); cam.limit_bottom = int(arena.end.y)

func _sprite_z(tex: Texture2D, pies: Vector2, alto: float) -> Sprite2D:
	var sp := Sprite2D.new(); sp.texture = tex; sp.centered = false; sp.offset = Vector2(-tex.get_width() / 2.0, -tex.get_height() + 8.0)
	sp.scale = Vector2.ONE * (alto / (tex.get_height() - 16.0)); sp.position = pies; sp.texture_filter = CanvasItem.TEXTURE_FILTER_LINEAR_WITH_MIPMAPS
	zona_n.add_child(sp); return sp

func _poner_frag(f: String) -> void:
	frag_spr = Node2D.new(); frag_spr.position = zona_n.puntos["frag"]; zona_n.add_child(frag_spr)
	var sp := Sprite2D.new(); sp.texture = load("res://assets/bruja/trozo_%s.png" % f); sp.scale = Vector2.ONE * (54.0 / sp.texture.get_width()); sp.position = Vector2(0, -40)
	sp.texture_filter = CanvasItem.TEXTURE_FILTER_LINEAR_WITH_MIPMAPS; sp.name = "Trozo"; frag_spr.add_child(sp)
	zona_n.luces.luz(frag_spr.position + Vector2(0, -40), 150.0, Color(0.8, 0.7, 0.45))
	var tw := frag_spr.create_tween().set_loops(); tw.tween_property(sp, "position:y", -52.0, 0.9).set_trans(Tween.TRANS_SINE); tw.tween_property(sp, "position:y", -40.0, 0.9).set_trans(Tween.TRANS_SINE)

# refugio: cada encontrado descansa en su rincón (brasas, escarcha, musgo, cristales), menos el que te sigue
var rincon_nodos: Array = []
func _rincones() -> void:
	for n in rincon_nodos: if is_instance_valid(n): n.queue_free()
	rincon_nodos.clear()
	for c in Secretos.lista(arpg, "comps"):
		if c == str(arpg.get("sigue", "")): continue
		rincon_nodos.append(_nodo_comp(c, zona_n.puntos["rincon_" + Secretos.RINCON[c]], true))

func _zona(delta: float) -> void:
	zona_t += delta
	_misterios_tick()
	_guia_zona()
	if state != "jugando": ui_accion.visible = false; ui_aviso.visible = false; return
	salida_cerca = ""; npc_cerca = null
	var p: Vector2 = player.position
	var vs: Vector2 = get_viewport().get_visible_rect().size
	if zona_id == "refugio":
		if zona_t > 0.6 and p.y > Zona.DEF["refugio"]["puerta_y"] * zona_n.K and player.vel.y > 8.0: _salir_zona(); return
		for h in zona_n.habitantes:
			if p.distance_to(h[0].position) < 170.0: npc_cerca = h; salida_cerca = "hablar"; ui_accion.text = tr("JUEGO_HABLAR"); accion_en = h[0].position + Vector2(0, -h[0].alto - 40.0)
	else:
		if p.distance_to(zona_n.puntos["subir"]) < 120.0: salida_cerca = "salir_zona"; ui_accion.text = tr("JUEGO_SUBIR") if zona_id == "tuneles" else tr("JUEGO_SALIR"); accion_en = zona_n.puntos["subir"] + Vector2(0, -120)
		if cofre_z and not Secretos.tiene(arpg, "cofres_z", zona_id) and p.distance_to(zona_n.puntos["cofre"]) < 130.0: salida_cerca = "cofre_zona"; ui_accion.text = tr("JUEGO_ABRIR"); accion_en = zona_n.puntos["cofre"] + Vector2(0, -100)
		if comp_dormido != null and p.distance_to(comp_dormido.position) < 150.0: _encontrar_comp()
		if frag_spr != null and p.distance_to(frag_spr.position) < 70.0: _coger_frag(); return
	ui_accion.visible = salida_cerca != ""
	if ui_accion.visible: _poner_accion(get_viewport().get_canvas_transform(), vs)
	if Input.is_action_just_pressed("interactuar") and salida_cerca != "" and t - fin_dialogo_t > 0.3: _usar_salida(salida_cerca)

func _salir_zona() -> void:
	var de := zona_id
	_fundir(func(): _salir_zona_ya(de))
func _salir_zona_ya(de: String) -> void:
	match de:
		"refugio": start_bosque("refugio")
		"tuneles": start_raizal("tuneles")
		"claro_musgo": start_bosque("zarzas")
		_: start_raizal("")

func _encontrar_comp() -> void:
	var c: String = Secretos.ZONAS[zona_id]["comp"]; var n = comp_dormido; comp_dormido = null
	Secretos.poner(arpg, "comps", c); arpg["sigue"] = c   # el nuevo te sigue ya; el de antes se va a descansar a su rincón del refugio
	if companero != null and is_instance_valid(companero): companero.queue_free()
	n.duerme = false; companero = n
	if c == "chispa": _luz_chispa(n)
	FX.burst(self, n.position + Vector2(0, -20), Companeros.TIPOS[c]["col"], 30, 320, 6); shake(3.0)
	popup_text(tr("JUEGO_DESPIERTA") % Secretos.nombre(c), Companeros.TIPOS[c]["col"].lightened(0.3))
	float_text(n.position + Vector2(0, -90), tr("JUEGO_SIGUE") % Secretos.nombre(c), Color(1, 0.92, 0.65))
	arpg_guardar()
	if bot_on: print("BOT encuentra ", c); _foto("encontrado_" + c, 1.0)

func _coger_frag() -> void:
	var f: String = Secretos.ZONAS[zona_id]["frag"]
	Secretos.poner(arpg, "frags", f)
	FX.burst(self, frag_spr.position + Vector2(0, -40), Color(1, 0.9, 0.6), 24, 260, 5)
	frag_spr.queue_free(); frag_spr = null
	popup_text(tr("JUEGO_TROZO_PERGAMINO") % tr(Secretos.FRAG_N[f]), Estilo.ORO)
	arpg_guardar()
	if bot_on: print("BOT trozo ", f)
	_pergamino_ui(Callable(), f)

func _abrir_cofre_z() -> void:
	if not Secretos.poner(arpg, "cofres_z", zona_id): return
	var z: Dictionary = Secretos.ZONAS[zona_id]; var c: Array = z["cofre"]
	cofre_z.texture = load("res://assets/bosque/cofre_abierto.png")
	oro_mas(c[0]); arpg["cascaras"] += c[1]; arpg["esporas"] = int(arpg.get("esporas", 0)) + c[2]
	Secretos.poner(arpg, "objetos", z["obj"]); recalc_stats()
	var ob: Dictionary = Secretos.OBJETOS[z["obj"]]
	FX.burst(self, cofre_z.position + Vector2(0, -50), Color(1, 0.85, 0.4), 36, 380, 7)
	popup_text(tr("JUEGO_ORO_CASCARAS_ESPORAS") % [c[0], c[1], c[2]], Estilo.ORO)
	float_text(cofre_z.position + Vector2(0, -140), "¡%s! %s" % [tr(ob["n"]), tr(ob["d"])], Color(0.75, 1.0, 0.6))
	_ganar_xp(60); arpg_guardar()
	if bot_on: print("BOT cofre ", zona_id, " ", z["obj"]); _foto("cofre_" + zona_id, 0.6)

# ---- la bruja: muy poco texto, nada de su origen ----
func _bruja_hablar() -> void:
	var comps: Array = Secretos.lista(arpg, "comps")
	if comps.is_empty():
		_hablar([["bruja", tr("DLG_BRUJA_LLEGAS_PRONTO")], ["pj", tr("DLG_PJ_PRONTO_PARA")], ["bruja", tr("DLG_BRUJA_CUATRO_RINCONES_DUERMEN_VACIOS")], ["bruja", tr("DLG_BRUJA_BUSCA_ESCONDE")]], Callable(), [], Callable(), "bruja")
		return
	var l: Array = [["bruja", tr("DLG_BRUJA_AH_HA_ENCONTRADO")]] if not arpg.get("bruja_vio", false) else [["bruja", [tr("DLG_BRUJA_CALDERO_ESCUCHA"), tr("DLG_BRUJA_ELIGE_CALMA"), tr("DLG_BRUJA_TODO_CRECE_DESPACIO")][randi() % 3]]]
	arpg["bruja_vio"] = true
	_hablar(l, func(): _bruja_ui(), [], Callable(), "bruja")

var bruja_capa: Control = null
func _bruja_ui() -> void:
	if bruja_capa: bruja_capa.queue_free()
	state = "dialogo"; ui_accion.visible = false
	var capa := Control.new(); capa.name = "BrujaUI"; capa.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT); capa.process_mode = Node.PROCESS_MODE_ALWAYS; bruja_capa = capa
	var velo := ColorRect.new(); velo.color = Color(0, 0, 0, 0.4); velo.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT); capa.add_child(velo)
	var pc := PanelContainer.new(); pc.add_theme_stylebox_override("panel", Madera.caja(10.0)); capa.add_child(pc)
	var vb := VBoxContainer.new(); vb.add_theme_constant_override("separation", 8); pc.add_child(vb)
	var tab := PanelContainer.new(); tab.add_theme_stylebox_override("panel", Madera.pestana(14, 4)); tab.size_flags_horizontal = Control.SIZE_SHRINK_CENTER
	tab.add_child(Madera.texto(tr("JUEGO_CUATRO_RINCONES"), 17, Madera.CREMA, true)); vb.add_child(tab)
	var vert: bool = Estilo.vertical()
	var gr := GridContainer.new(); gr.columns = 2 if vert else 4; gr.add_theme_constant_override("h_separation", 10); gr.add_theme_constant_override("v_separation", 10); vb.add_child(gr)
	var primero: Button = null
	for c in Secretos.ORDEN:
		var tiene: bool = Secretos.tiene(arpg, "comps", c)
		var cv := VBoxContainer.new(); cv.add_theme_constant_override("separation", 3); cv.custom_minimum_size.x = 170; gr.add_child(cv)
		var ic := Control.new(); ic.set_script(load("res://comp_icono.gd")); ic.col = Companeros.TIPOS[c]["col"]; ic.tipo = c; ic.evo = Secretos.evo(arpg, c); ic.conocido = tiene
		ic.custom_minimum_size = Vector2(84, 84); ic.size_flags_horizontal = Control.SIZE_SHRINK_CENTER; cv.add_child(ic)
		var nm := Madera.texto(Secretos.nombre(c) if tiene else "?", 18, Madera.TINTA, true); nm.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER; cv.add_child(nm)
		var ds := Madera.texto(tr(Secretos.DESC[c] if tiene else Secretos.DESC_FALTA[c]), 13, Madera.TINTA2); ds.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER; cv.add_child(ds)
		var est := ""
		if tiene: est = (tr("JUEGO_SIGUE_2") if str(arpg.get("sigue", "")) == c else tr("JUEGO_DESCANSA")) + " · " + Secretos.etapa_n(arpg, c)
		var le := Madera.texto(est, 13, Color(0.18, 0.42, 0.16)); le.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER; cv.add_child(le)
		var b1 := Madera.boton(tr("JUEGO_ME_SIGA"), false, 14); b1.disabled = not tiene or str(arpg.get("sigue", "")) == c; b1.name = "Sigue_" + c; cv.add_child(b1)
		b1.pressed.connect(func(): _bruja_elegir(c))
		var pe: Array = Secretos.puede_evo(arpg, c)
		var b2 := Madera.boton(tr("JUEGO_EVOLUCIONAR"), true, 14); b2.disabled = not pe[0]; b2.name = "Evo_" + c; cv.add_child(b2)
		b2.pressed.connect(func(): _bruja_evo(c))
		var rc := Madera.texto(Secretos.receta_txt(c) if Secretos.evo(arpg, c) == 0 else "", 11, Madera.TINTA2); rc.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER; rc.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART; cv.add_child(rc)
		var fl := Madera.texto(pe[1] if tiene and not pe[0] else "", 11, Color(0.66, 0.16, 0.1)); fl.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER; cv.add_child(fl)
		if primero == null and not b1.disabled: primero = b1
		if not b2.disabled: primero = b2
	var tn := Madera.texto(tr("JUEGO_TIENES_ORO_CASCARAS_ESPORAS_4") % [arpg["oro"], arpg["cascaras"], int(arpg.get("esporas", 0)), Secretos.lista(arpg, "frags").size()], 14, Madera.TINTA)
	tn.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER; vb.add_child(tn)
	var hb := HBoxContainer.new(); hb.alignment = BoxContainer.ALIGNMENT_CENTER; hb.add_theme_constant_override("separation", 12); vb.add_child(hb)
	var bp := Madera.boton(tr("JUEGO_PERGAMINO"), false, 15); bp.custom_minimum_size = Vector2(130, 40); hb.add_child(bp)
	bp.pressed.connect(func(): capa.visible = false; _pergamino_ui(func(): capa.visible = true; state = "dialogo"))
	var bx := Madera.boton(tr("JUEGO_ADIOS"), false, 15); bx.custom_minimum_size = Vector2(120, 40); hb.add_child(bx)
	bx.pressed.connect(func(): capa.queue_free(); bruja_capa = null; state = "jugando"; fin_dialogo_t = t)
	ui_capa.add_child(capa)
	await get_tree().process_frame
	if not is_instance_valid(capa): return
	var vs: Vector2 = get_viewport().get_visible_rect().size
	pc.reset_size(); pc.position = (vs - pc.size) / 2.0
	(primero if primero else bx).grab_focus()
	if bot_on: _bot_bruja(capa)

func _bruja_elegir(c: String) -> void:
	arpg["sigue"] = c; arpg_guardar()
	_poner_companero(); if zona_n: _rincones()
	popup_text(tr("JUEGO_SIGUE") % Secretos.nombre(c), Companeros.TIPOS[c]["col"].lightened(0.3))
	if bot_on: print("BOT sigue ", c)
	_bruja_ui()

func _bruja_evo(c: String) -> void:
	if not Secretos.puede_evo(arpg, c)[0]: return
	var r: Array = Secretos.RECETA[c]
	arpg["cascaras"] -= r[1]; arpg["esporas"] = int(arpg.get("esporas", 0)) - r[2]; arpg["oro"] -= r[3]
	if not (arpg.get("evo") is Dictionary): arpg["evo"] = {}
	arpg["evo"][c] = 1; arpg_guardar()
	_poner_companero(); if zona_n: _rincones()
	var donde: Vector2 = player.position
	for n in [companero] + rincon_nodos: if n != null and is_instance_valid(n) and n.tipo == c: donde = n.position
	FX.burst(self, donde + Vector2(0, -20), Companeros.TIPOS[c]["col"].lightened(0.3), 46, 420, 8); shake(5.0)
	popup_text(tr("JUEGO_HA_CRECIDO_YA_ES") % [Secretos.nombre(c), Secretos.etapa_n(arpg, c)], Estilo.ORO)
	if bot_on: print("BOT evoluciona ", c); _foto("evo_" + c, 0.4)
	if bruja_capa: bruja_capa.queue_free(); bruja_capa = null
	_hablar([["bruja", tr("DLG_BRUJA_ASI_MAS_LUZ")]], func(): _bruja_ui(), [], Callable(), "bruja")

# ---- pergamino: se va llenando (hojas arriba izq., musgo arriba der., cristales abajo izq., brasas abajo der.) ----
func _pergamino_ui(volver := Callable(), nuevo := "") -> void:
	var antes: String = state
	state = "dialogo"; ui_accion.visible = false
	var capa := Control.new(); capa.name = "Pergamino"; capa.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT); capa.process_mode = Node.PROCESS_MODE_ALWAYS
	var velo := ColorRect.new(); velo.color = Color(0, 0, 0, 0.45); velo.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT); capa.add_child(velo)
	var pc := PanelContainer.new(); pc.add_theme_stylebox_override("panel", Madera.caja(10.0)); capa.add_child(pc)
	var vb := VBoxContainer.new(); vb.add_theme_constant_override("separation", 8); pc.add_child(vb)
	var tab := PanelContainer.new(); tab.add_theme_stylebox_override("panel", Madera.pestana(14, 4)); tab.size_flags_horizontal = Control.SIZE_SHRINK_CENTER
	var fr: Array = Secretos.lista(arpg, "frags")
	tab.add_child(Madera.texto(tr("JUEGO_PERGAMINO_4") % fr.size(), 17, Madera.CREMA, true)); vb.add_child(tab)
	var vs: Vector2 = get_viewport().get_visible_rect().size
	var lado: float = min(vs.x * 0.42, vs.y * 0.5)
	var tex: Texture2D = load("res://assets/bruja/pergamino_entero.png"); var hw: float = tex.get_width() / 2.0; var hh: float = tex.get_height() / 2.0
	var gr := GridContainer.new(); gr.columns = 2; gr.add_theme_constant_override("h_separation", 2); gr.add_theme_constant_override("v_separation", 2); gr.size_flags_horizontal = Control.SIZE_SHRINK_CENTER; vb.add_child(gr)
	for k in 4:
		var f: String = Secretos.FRAGS[k]
		var at := AtlasTexture.new(); at.atlas = tex; at.region = Rect2((k % 2) * hw, (k / 2) * hh, hw, hh)
		var t_r := TextureRect.new(); t_r.texture = at; t_r.expand_mode = TextureRect.EXPAND_IGNORE_SIZE; t_r.stretch_mode = TextureRect.STRETCH_KEEP_ASPECT
		t_r.custom_minimum_size = Vector2(lado / 2.0, lado / 2.0 * hh / hw); t_r.name = "Trozo_" + f; gr.add_child(t_r)
		if not fr.has(f):
			t_r.modulate = Color(0.32, 0.27, 0.22, 0.32)
			var q := Madera.texto("?", 40, Color(1, 0.95, 0.8, 0.75), true); q.set_anchors_and_offsets_preset(Control.PRESET_CENTER); t_r.add_child(q)
		elif f == nuevo:
			t_r.modulate = Color(2, 2, 2, 1); var tw := t_r.create_tween(); tw.tween_property(t_r, "modulate", Color.WHITE, 0.9)
	var nombres: Array = []
	for f in Secretos.FRAGS: nombres.append(("✓ " if fr.has(f) else "· ") + tr(Secretos.FRAG_N[f]))
	var ln := Madera.texto("   ".join(nombres), 14, Madera.TINTA); ln.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER; vb.add_child(ln)
	var bx := Madera.boton(tr("JUEGO_CERRAR"), true, 15); bx.custom_minimum_size = Vector2(120, 40); bx.size_flags_horizontal = Control.SIZE_SHRINK_CENTER; vb.add_child(bx)
	var cerrar := func():
		capa.queue_free(); fin_dialogo_t = t
		if volver.is_valid(): volver.call()
		else: state = "jugando" if antes in ["jugando", "dialogo"] else antes
	bx.pressed.connect(cerrar)
	ui_capa.add_child(capa)
	await get_tree().process_frame
	pc.reset_size(); pc.position = (vs - pc.size) / 2.0; bx.grab_focus()
	if bot_on or "--pergamino_auto" in OS.get_cmdline_user_args():
		_foto("pergamino", 0.5)
		get_tree().create_timer(1.4).timeout.connect(func(): if is_instance_valid(capa): cerrar.call())

# ---- seguimiento: las zonas secretas solo salen cuando ya te han dado su pista ----
func _secreto_activo() -> Array:
	if modo == "zona" and Secretos.ZONAS.has(zona_id):
		var z: Dictionary = Secretos.ZONAS[zona_id]
		if not Secretos.tiene(arpg, "comps", z["comp"]): return [z["n"], z["paso_dentro"]]
		if not Secretos.tiene(arpg, "frags", z["frag"]): return [z["n"], tr("JUEGO_RECOGE_TROZO_PERGAMINO")]
		if not Secretos.tiene(arpg, "cofres_z", zona_id): return [z["n"], tr("JUEGO_ABRE_COFRE")]
		return [z["n"], tr("JUEGO_SUBE_ESCALERA") if zona_id == "tuneles" else tr("JUEGO_VUELVE_ZARZAS")]
	if modo == "zona" and zona_id == "refugio" and not Secretos.lista(arpg, "comps").is_empty() and not arpg.get("bruja_vio", false): return [tr("JUEGO_REFUGIO_BRUJA_2"), tr("JUEGO_HABLA_BRUJA")]
	for zid in ["tuneles", "claro_musgo", "cueva_helada", "hondonada"]:
		var z2: Dictionary = Secretos.ZONAS[zid]
		if Secretos.tiene(arpg, "pistas", zid) and not Secretos.tiene(arpg, "comps", z2["comp"]): return [z2["pista"], z2["paso"]]
	if not Secretos.lista(arpg, "comps").is_empty() and not arpg.get("bruja_vio", false): return [tr("JUEGO_REFUGIO_BRUJA_2"), tr("JUEGO_BUSCA_CASA_ENTRE_RAICES")]
	if arpg.get("hojas", 0) >= 5 and not Secretos.tiene(arpg, "pistas", "tuneles"): return [tr("JUEGO_RUMORES_PUEBLO"), tr("JUEGO_HABLA_DONA_PLUMAS")]
	return []

func _guia_zona() -> void:
	var o = null
	if zona_id == "refugio":
		if not Secretos.lista(arpg, "comps").is_empty() and not arpg.get("bruja_vio", false): o = {"pos": zona_n.puntos["bruja"], "alto": 128.0, "s": "!"}
	elif comp_dormido != null: o = {"pos": comp_dormido.position, "alto": 40.0, "s": ""}
	elif frag_spr != null: o = {"pos": frag_spr.position, "alto": 60.0, "s": ""}
	elif cofre_z and not Secretos.tiene(arpg, "cofres_z", zona_id): o = {"pos": zona_n.puntos["cofre"], "alto": 60.0, "s": "!"}
	elif zona_n: o = {"pos": zona_n.puntos["subir"], "alto": 0.0, "s": ""}
	guia.objetivo = o

# ---- casa de piedra: alfombra -> trampilla cerrada -> abierta (mismo ancla); se baja andando sobre ella ----
func _trampilla(delta: float) -> bool:
	if interior == null or dentro != "piedra": return false
	var n: int = interior.trampilla_n; var p: Vector2 = player.position
	tram_t -= delta
	if n == 0:
		if tram_t <= 0.0:   # ruiditos bajo el suelo
			tram_t = 2.6; float_text(interior.trampilla_pos() + Vector2(randf_range(-30, 30), -30), [tr("JUEGO_TAC_TAC"), tr("JUEGO_TIC_TIC"), tr("JUEGO_CRRR")][randi() % 3], Color(0.9, 0.88, 0.8, 0.85))
		if p.distance_to(interior.esquina_alfombra()) < 50.0:
			interior.poner_trampilla(1); arpg["trampilla"] = 1
			FX.burst(self, interior.trampilla_pos(), Color(0.75, 0.6, 0.4), 18, 160, 5)
			popup_text(tr("JUEGO_HAY_TRAMPILLA_DEBAJO"), Estilo.CREMA)
			get_tree().create_timer(0.9).timeout.connect(func():
				if interior and dentro == "piedra":
					interior.poner_trampilla(2); arpg["trampilla"] = 2; arpg_guardar(); shake(2.5)
					float_text(interior.trampilla_pos() + Vector2(0, -60), tr("JUEGO_ABRE_CRUJIDO"), Color(1, 0.9, 0.6)))
			if bot_on: _foto("trampilla_1", 0.3); _foto("trampilla_2", 1.4)
	elif n == 2 and p.distance_to(interior.trampilla_pos()) < 46.0 and tram_t <= 0.0 and state == "jugando":
		_fundir(func(): start_zona("tuneles")); return true
	return false

# ---- capturas y pruebas: --pistas=a,b --comps=a,b --frags=a,b --sigue=c --evo=c --oro=N --mats=c,e (cáscaras, esporas) ----
func _args_secretos() -> void:
	for a in OS.get_cmdline_user_args():
		var v: String = a.split("=")[1] if a.contains("=") else ""
		if a.begins_with("--pistas="): for x in v.split(","): Secretos.poner(arpg, "pistas", x)
		if a.begins_with("--comps="): for x in v.split(","): Secretos.poner(arpg, "comps", x)
		if a.begins_with("--trampilla="): arpg["trampilla"] = int(v)   # capturas: 0 alfombra · 1 cerrada · 2 abierta
		if a.begins_with("--frags="): for x in v.split(","): Secretos.poner(arpg, "frags", x)
		if a.begins_with("--sigue="): arpg["sigue"] = v
		if a.begins_with("--evo="): arpg["evo"] = {v: 1}
		if a.begins_with("--oro="): arpg["oro"] = int(v)
		if a.begins_with("--mats="): arpg["cascaras"] = int(v.split(",")[0]); arpg["esporas"] = int(v.split(",")[1])

# ---- prueba: zonas secretas y entradas del bosque alcanzables, sin muros invisibles (--test_zonas) ----
func _pintado(raiz: Node, q: Vector2, saltar: Array = []) -> bool:
	var pila: Array = [raiz]
	while not pila.is_empty():
		var nd: Node = pila.pop_back()
		for ch in nd.get_children(): if not (ch.name in ["Suelo", "MapaLuz"]): pila.append(ch)
		if nd is Sprite2D and nd.texture != null and nd.visible and not saltar.has(nd):
			if (nd.get_global_transform() * nd.get_rect()).has_point(q) and nd.is_pixel_opaque(nd.to_local(q)): return true
	return false

func _rejilla(A: Rect2, S: float, ok: Callable, ini: Vector2) -> Array:
	var nx: int = int(A.size.x / S); var ny: int = int(A.size.y / S)
	var lib := PackedByteArray(); lib.resize(nx * ny)
	for j in ny: for i in nx: lib[j * nx + i] = 1 if ok.call(A.position + Vector2(i + 0.5, j + 0.5) * S) else 0
	var vis := PackedByteArray(); vis.resize(nx * ny)
	var c0 := Vector2i(((ini - A.position) / S).floor())
	var cola: Array = [c0]; vis[c0.y * nx + c0.x] = 1
	while not cola.is_empty():
		var c: Vector2i = cola.pop_back()
		for dd in [Vector2i(1, 0), Vector2i(-1, 0), Vector2i(0, 1), Vector2i(0, -1)]:
			var n: Vector2i = c + dd
			if n.x < 0 or n.y < 0 or n.x >= nx or n.y >= ny: continue
			var k: int = n.y * nx + n.x
			if vis[k] == 0 and lib[k] == 1: vis[k] = 1; cola.append(n)
	return [vis, nx, ny]
func _alcanza(r: Array, A: Rect2, S: float, p: Vector2, rad := 2) -> bool:
	var c := Vector2i(((p - A.position) / S).floor())
	for dy in range(-rad, rad + 1):
		for dx in range(-rad, rad + 1):
			var x: int = c.x + dx; var y: int = c.y + dy
			if x >= 0 and y >= 0 and x < r[1] and y < r[2] and r[0][y * r[1] + x] == 1: return true
	return false

func _test_zonas() -> void:
	await get_tree().create_timer(0.3).timeout
	var malos := 0
	start_raizal(); arpg["hojas"] = 5
	for zid in ["refugio", "tuneles", "claro_musgo", "cueva_helada", "hondonada"]:
		start_zona(zid); await get_tree().process_frame; await get_tree().process_frame
		for e in enemies: if is_instance_valid(e): e.process_mode = Node.PROCESS_MODE_DISABLED
		var A: Rect2 = zona_n.arena; var S := 16.0
		var r: Array = _rejilla(A, S, func(q): return zona_n.libre(q, 16.0), zona_n.aparece)
		var m := 0; var nl := 0
		for k in zona_n.puntos:
			if k.begins_with("rincon_"):   # el rincón es un mueble: hay que poder llegar a su lado
				if not _alcanza(r, A, S, zona_n.puntos[k], 9): m += 1; print("NO ALCANZABLE ", zid, " ", k)
				continue
			nl += 1
			if not _alcanza(r, A, S, zona_n.puntos[k] + (Vector2(0, 60) if k in ["bruja", "cofre"] else Vector2.ZERO), 4): m += 1; print("NO ALCANZABLE ", zid, " ", k, " ", Vector2i(zona_n.puntos[k]))
		for mi in Secretos.MISTERIOS:   # objetos misteriosos de Chispa: hay que poder llegar
			if mi["mapa"] == zid:
				var mp: Vector2 = zona_n.px(mi["px"]) if mi.has("px") else mi["pos"]
				nl += 1
				if not _alcanza(r, A, S, mp, 4): m += 1; print("NO ALCANZABLE misterio ", mi["id"], " ", Vector2i(mp))
		if zid == "refugio":   # la puerta de salida
			var sale := false
			for j in r[2]: for i in r[1]: if r[0][j * r[1] + i] == 1 and A.position.y + (j + 0.5) * S > Zona.DEF["refugio"]["puerta_y"] * zona_n.K: sale = true
			if not sale: m += 1; print("NO SE PUEDE SALIR del refugio")
		# muros invisibles: justo fuera del suelo tiene que haber algo pintado (pared, roca, árboles); y no se pisa el vacío
		var pol: PackedVector2Array = zona_n.suelo; var sg: float = sign(Zona._area(pol)); var inv := 0; var vacio := 0
		var fondo: Array = [] if zona_n.d.has("img") else []
		for i in pol.size():
			var a: Vector2 = pol[i]; var b: Vector2 = pol[(i + 1) % pol.size()]
			var nrm: Vector2 = (b - a).normalized().orthogonal() * sg
			var n2: int = max(1, int(a.distance_to(b) / 24.0))
			for j in n2:
				var q0: Vector2 = a.lerp(b, (j + 0.5) / n2)
				var ok_b := false
				for dq in ([14.0] if zona_n.d.has("img") else [50.0, 90.0]): if _pintado(zona_n, q0 + nrm * dq): ok_b = true
				if not ok_b: inv += 1; if inv <= 6: print("BORDE SIN NADA PINTADO ", zid, " ", Vector2i(q0))
		if zona_n.d.has("img"):
			for j in r[2]: for i in r[1]:
				if r[0][j * r[1] + i] == 1 and not _pintado(zona_n, A.position + Vector2(i + 0.5, j + 0.5) * S): vacio += 1
		if inv > 0: m += 1
		if vacio > 0: m += 1; print("SE PISA EL VACÍO ", zid, " ", vacio, " celdas")
		print("ZONA %s %s (metas %d, borde sin pintar %d, vacío %d)" % [zid, "OK" if m == 0 else "FALLA", nl, inv, vacio])
		malos += m
	# bosque: refugio y zarzas (estas solo con el farolillo encendido); colisiones nuevas siempre bajo algo pintado
	for lit in [true, false]:
		arpg["hojas"] = 5 if lit else 2; start_bosque(); await get_tree().process_frame; await get_tree().process_frame
		for e in enemies: if is_instance_valid(e): e.process_mode = Node.PROCESS_MODE_DISABLED
		var A2: Rect2 = Bosque.ARENA; var S2 := 20.0
		var r2: Array = _rejilla(A2, S2, func(q): return not blocked(q, 16.0), Bosque.ENTRADA)
		var m2 := 0
		if not _alcanza(r2, A2, S2, Bosque.REFUGIO + Vector2(0, 30), 1): m2 += 1; print("NO ALCANZABLE puerta del refugio (farolillo %s)" % lit)
		var z_ok: bool = _alcanza(r2, A2, S2, Bosque.ZARZAS + Vector2(0, -28), 1)
		if z_ok != lit: m2 += 1; print("ZARZAS %s con el farolillo %s" % ["abiertas" if z_ok else "cerradas", "encendido" if lit else "apagado"])
		if lit:
			for mi in Secretos.MISTERIOS:
				if mi["mapa"] == "bosque" and not _alcanza(r2, A2, S2, mi["pos"], 1): m2 += 1; print("NO ALCANZABLE misterio ", mi["id"], " ", Vector2i(mi["pos"]))
		var inv2 := 0
		for o in obst:
			# p21: el bosque entero es nuevo, así que se miran todos los círculos (antes solo los del refugio y las zarzas)
			var vis_o := false   # el tronco o la pieza tapa el círculo (centro o a media distancia)
			for dq in [Vector2.ZERO, Vector2(0.5, 0), Vector2(-0.5, 0), Vector2(0, 0.5), Vector2(0, -0.5)]: if _pintado(bosque_esc, o[0] + dq * o[1]): vis_o = true
			if not vis_o: inv2 += 1; if inv2 <= 6 or OS.has_environment("ZONAS_TODO"): print("COLISION SIN NADA VISIBLE bosque ", Vector2i(o[0]), " ", int(o[1]))
		if inv2 > 0: m2 += 1
		print("BOSQUE ENTRADAS %s (farolillo %s, colisiones invisibles %d)" % ["OK" if m2 == 0 else "FALLA", "encendido" if lit else "apagado", inv2])
		malos += m2
	print("ZONAS %s" % ("OK" if malos == 0 else "FALLA %d" % malos))
	get_tree().quit()

# ---- bot (--bot_secretos): tras el primer encargo, recorre las zonas secretas alcanzables, junta trozos y hace crecer a uno ----
var bot_visita := 0
var bot_swp := 0
var bot_iwp := 0
func _bot_sec_raizal() -> Array:
	var p: Vector2 = player.position
	if not Secretos.tiene(arpg, "pistas", "tuneles"):
		if dentro != "": return [_bot_salir_casa(), ""]
		return [_npc("plumas")[0].position + Vector2(0, 70), "hablar"]
	if not Secretos.tiene(arpg, "comps", "chispa"):
		if dentro == "piedra":
			if interior.trampilla_n == 0:
				if not bot_hechas.has("foto_alfombra"): bot_hechas["foto_alfombra"] = true; _foto("trampilla_0", 0.8)
				return [interior.esquina_alfombra(), ""]
			return [interior.trampilla_pos(), ""] if interior.trampilla_n == 2 else [p, ""]
		if dentro != "": return [_bot_salir_casa(), ""]
		for pu in raizal_esc.puertas:
			if pu[0] != "piedra": continue
			var ante: Vector2 = pu[1] + Vector2(0, 70)
			if p.distance_to(ante) < 16.0: bot_hechas["ante_piedra"] = true
			return [pu[1] + Vector2(0, -70) if bot_hechas.has("ante_piedra") else ante, ""]
	if dentro != "": return [_bot_salir_casa(), ""]
	return [Raizal.PUERTA_BOSQUE + Vector2(0, -60), "bosque"]

func _bot_ruta(ruta: Array) -> Vector2:
	if bot_swp < ruta.size() - 1 and player.position.distance_to(ruta[bot_swp]) < 90.0: bot_swp += 1
	return ruta[min(bot_swp, ruta.size() - 1)]
func _bot_sec_bosque() -> Array:
	var p: Vector2 = player.position
	if not bot_hechas.has("bruja1") or (Secretos.tiene(arpg, "comps", "musgo") and not bot_hechas.has("bruja2")):
		var ante: Vector2 = Bosque.REFUGIO + Vector2(0, 75)
		if p.distance_to(ante) < 16.0: bot_hechas["ante_ref%d" % bot_visita] = true
		return [Bosque.REFUGIO + Vector2(0, -60) if bot_hechas.has("ante_ref%d" % bot_visita) else ante, ""]
	if not Secretos.tiene(arpg, "comps", "musgo"):
		var ante2: Vector2 = Bosque.ZARZAS + Vector2(0, 60)
		if p.distance_to(ante2) < 16.0: bot_hechas["ante_zarzas"] = true
		return [Bosque.ZARZAS + Vector2(0, -80) if bot_hechas.has("ante_zarzas") else ante2, ""]
	# ya ha crecido uno: a pelear un poco con él a tu lado (foto) y fin
	if companero != null and not bot_hechas.has("comp_combate"):
		for en in enemies:
			if is_instance_valid(en) and en.position.distance_to(p) < 330.0:
				bot_hechas["comp_combate"] = true; _foto("comp_combate", 0.2); _foto("comp_combate_b", 1.4)
				get_tree().create_timer(3.0).timeout.connect(_bot_sec_fin); break
	var best = null; var bd := INF
	for en in enemies: if is_instance_valid(en) and en.position.distance_to(p) < bd: bd = en.position.distance_to(p); best = en
	return [(best.position + (p - best.position).normalized() * 200.0) if best != null else Vector2(-120, -1900), ""]

func _bot_sec_fin() -> void:
	if bot_hechas.has("sec_fin"): return
	bot_hechas["sec_fin"] = true
	var evo_d: Dictionary = arpg.get("evo", {}) if arpg.get("evo") is Dictionary else {}
	print("BOT SECRETOS comps=%s frags=%s objetos=%s evo=%s sigue=%s oro=%d · %s" % [Secretos.lista(arpg, "comps"), Secretos.lista(arpg, "frags"), Secretos.lista(arpg, "objetos"), evo_d.keys(), arpg.get("sigue", ""), arpg["oro"],
		"OK" if Secretos.lista(arpg, "comps").size() >= 2 and Secretos.lista(arpg, "frags").size() >= 2 and evo_d.size() >= 1 else "FALLA"])
	print("BOT FIN t=%.0f s · bosque %.0f s · vida perdida %.0f · golpes %d · desmayos %d · nivel %d · oro %d · cáscaras %d · %s +%d" % [t - bot_reg["t0"], bot_reg["bosque_t"], bot_reg["vida_perdida"], bot_reg["golpes"], bot_reg["desmayos"], arpg["nivel"], arpg["oro"], arpg["cascaras"], _nombre_arma(), arpg["arma_mas"]])
	bot_hechas["fin"] = true
	if bot_fotos != "": get_tree().create_timer(2.0).timeout.connect(get_tree().quit)
	else: get_tree().quit()

func _bot_zona() -> Array:
	var p: Vector2 = player.position
	if zona_id == "refugio":
		if not bot_hechas.has("hablo_%d" % bot_visita): return [zona_n.puntos["bruja"] + Vector2(40, 70), "hablar"]
		return [Vector2(zona_n.aparece.x, zona_n.aparece.y + 220), ""]
	var obj: Vector2; var usar := ""
	if comp_dormido != null: obj = comp_dormido.position + Vector2(0, 40)
	elif frag_spr != null: obj = frag_spr.position
	elif not Secretos.tiene(arpg, "cofres_z", zona_id): obj = zona_n.puntos["cofre"] + Vector2(0, 55); usar = "cofre_zona"
	else: obj = zona_n.puntos["subir"]; usar = "salir_zona"
	if zona_id == "tuneles":   # pasillos: siempre por la sala central
		var hall: Vector2 = TUNEL_HALL * zona_n.K
		var clave := "hall_%d_%s" % [bot_visita, str(Vector2i(obj))]
		if p.distance_to(hall) < 110.0: bot_hechas[clave] = true
		if not bot_hechas.has(clave) and p.distance_to(obj) > 260.0: return [hall, ""]
	return [obj, usar]

func _bot_bruja(capa: Control) -> void:
	_foto("bruja_ui_%d" % bot_visita, 0.5)
	get_tree().create_timer(1.3).timeout.connect(func():
		if not is_instance_valid(capa): return
		var etapa := 2 if bot_hechas.has("bruja1") else 1
		if etapa == 2 and Secretos.puede_evo(arpg, "chispa")[0]: _bruja_evo("chispa"); return
		if etapa == 2 and Secretos.evo(arpg, "chispa") == 0: print("BOT EVO FALLA chispa: ", Secretos.puede_evo(arpg, "chispa")[1], " oro=%d cás=%d esp=%d" % [arpg["oro"], arpg["cascaras"], int(arpg.get("esporas", 0))])
		if etapa == 2 and str(arpg.get("sigue", "")) != "chispa": _bruja_elegir("chispa"); return
		capa.queue_free(); bruja_capa = null; state = "jugando"; fin_dialogo_t = t
		bot_hechas["bruja%d" % etapa] = true; bot_hechas["hablo_%d" % bot_visita] = true)

# camino del bot: BFS en rejilla de 20 u desde la meta (se rehace solo si cambia la meta o el mapa)
var _bc_meta = null
var _bc_A := Rect2()
var _bc_d := PackedInt32Array()
var _bc_nx := 0
var _bc_ny := 0
func _bot_libre(q: Vector2) -> bool:
	if dentro != "" and interior: return q.y < interior.salida_y - 8.0 and interior.resolver(q, 16.5).distance_to(q) < 0.5   # sin salir por la puerta
	if modo == "zona" and zona_n: return zona_n.libre(q, 16.0)   # mismo polígono encogido que el del niño (radio 16,2 -> 16)
	return not blocked(q, 18.0)
func _bot_camino(meta: Vector2) -> Vector2:
	var A: Rect2 = arena; var S := 20.0
	if dentro != "" and interior:
		if not interior.suelo.has_point(meta): return meta
		A = interior.suelo.grow(40.0); S = 12.0
	elif modo == "zona": S = 10.0
	if _bc_meta == null or _bc_meta.distance_to(meta) > 1.0 or _bc_A != A:
		_bc_meta = meta; _bc_A = A
		_bc_nx = int(A.size.x / S); _bc_ny = int(A.size.y / S)
		var lib := PackedByteArray(); lib.resize(_bc_nx * _bc_ny)
		for j in _bc_ny: for i in _bc_nx: lib[j * _bc_nx + i] = 1 if _bot_libre(A.position + Vector2(i + 0.5, j + 0.5) * S) else 0
		_bc_d = PackedInt32Array(); _bc_d.resize(_bc_nx * _bc_ny); _bc_d.fill(-1)
		var c0 := Vector2i(((meta - A.position) / S).floor()).clamp(Vector2i.ZERO, Vector2i(_bc_nx - 1, _bc_ny - 1))
		_bc_d[c0.y * _bc_nx + c0.x] = 0; var cola: Array = [c0]; var h := 0
		while h < cola.size():
			var c: Vector2i = cola[h]; h += 1
			for dd in [Vector2i(1, 0), Vector2i(-1, 0), Vector2i(0, 1), Vector2i(0, -1)]:
				var n: Vector2i = c + dd
				if n.x < 0 or n.y < 0 or n.x >= _bc_nx or n.y >= _bc_ny: continue
				var k: int = n.y * _bc_nx + n.x
				if _bc_d[k] < 0 and lib[k] == 1: _bc_d[k] = _bc_d[c.y * _bc_nx + c.x] + 1; cola.append(n)
	var cp := Vector2i(((player.position - A.position) / S).floor())
	if cp.x < 0 or cp.y < 0 or cp.x >= _bc_nx or cp.y >= _bc_ny or _bc_d[cp.y * _bc_nx + cp.x] < 0:
		var mejor0 = null; var md0 := INF   # pegado a un mueble: primero a la celda buena más cercana
		for dy in range(-8, 9):
			for dx in range(-8, 9):
				var n0 := cp + Vector2i(dx, dy)
				if n0.x < 0 or n0.y < 0 or n0.x >= _bc_nx or n0.y >= _bc_ny or _bc_d[n0.y * _bc_nx + n0.x] < 0: continue
				var pz: float = _bc_d[n0.y * _bc_nx + n0.x] + Vector2(dx, dy).length() * 0.5   # hacia delante, no a la más cercana
				if pz < md0: md0 = pz; mejor0 = n0
		if mejor0 == null: return meta
		var c0w: Vector2 = A.position + (Vector2(mejor0) + Vector2(0.5, 0.5)) * S
		return player.position + (c0w - player.position).normalized() * 70.0   # más allá de 40 u: si no, el bot se queda quieto
	for paso in int((50.0 if dentro != "" else 100.0) / S):   # ~100 u por delante (50 en casas) (el bot no se mueve si la meta está a menos de 40 u)
		var mejor: Vector2i = cp; var md: int = _bc_d[cp.y * _bc_nx + cp.x]
		for dd in [Vector2i(1, 0), Vector2i(-1, 0), Vector2i(0, 1), Vector2i(0, -1)]:
			var n: Vector2i = cp + dd
			if n.x < 0 or n.y < 0 or n.x >= _bc_nx or n.y >= _bc_ny: continue
			var dn: int = _bc_d[n.y * _bc_nx + n.x]
			if dn >= 0 and dn < md: md = dn; mejor = n
		if mejor == cp: break
		cp = mejor
	if _bc_d[cp.y * _bc_nx + cp.x] <= 1: return meta
	return A.position + (Vector2(cp) + Vector2(0.5, 0.5)) * S

func _bot_salir_casa() -> Vector2:
	if player.position.distance_to(interior.aparece) > 45.0 and not bot_hechas.has("en_puerta_%d" % interior.get_instance_id()): return interior.aparece
	bot_hechas["en_puerta_%d" % interior.get_instance_id()] = true
	return interior.aparece + Vector2(0, 220)
var bot_traza_k := 0.25 if "--bot_traza_fina" in OS.get_cmdline_user_args() else 3.0

# ---- capturas del andar de perfil (20/10): tira de fotogramas TAL CUAL se ven en el juego (--raizal --tira_lat=ruta.png) ----
func _tira_lat(ruta: String) -> void:
	await get_tree().create_timer(0.6).timeout
	_cap_limpio()
	var filas := [["derecha", Vector2.RIGHT], ["izquierda", Vector2.LEFT], ["abajo-der", Vector2(1, 1)], ["arriba-izq", Vector2(-1, -1)],
		["abajo-izq", Vector2(-1, 1)], ["arriba-der", Vector2(1, -1)], ["abajo", Vector2.DOWN], ["arriba", Vector2.UP]]
	var lado := 170; var img := Image.create(lado * 6, lado * filas.size(), false, Image.FORMAT_RGBA8)
	Engine.time_scale = 0.15
	var log := []
	for r in filas.size():
		var dv: Vector2 = filas[r][1].normalized()
		player.position = Vector2(0, 470) - dv * 160.0; cam.position = player.position; cam.reset_smoothing()
		andar_dir = dv
		await get_tree().create_timer(0.45 * 0.15, true, false, false).timeout
		var fila := []; var ant: Texture2D = null; var n := 0
		while fila.size() < 6 and n < 400:
			await get_tree().process_frame; n += 1
			if player.spr.texture == ant: continue
			ant = player.spr.texture
			await RenderingServer.frame_post_draw
			var vimg := get_viewport().get_texture().get_image()
			if vimg.get_format() != Image.FORMAT_RGBA8: vimg.convert(Image.FORMAT_RGBA8)
			var sp: Vector2 = _en_pantalla(vimg, player.position + Vector2(0, -50))
			img.blit_rect(vimg, Rect2i(int(sp.x) - lado / 2, int(sp.y) - lado / 2, lado, lado), Vector2i(fila.size() * lado, r * lado))
			fila.append("%s%s" % [ant.resource_path.get_file().get_basename().trim_prefix(Personajes.LISTA[pj]["art"].get_file() + "_"), " (espejo)" if player.spr.flip_h else ""])
		log.append("%-10s -> %s" % [filas[r][0], " | ".join(fila)])
		andar_dir = Vector2.ZERO
	img.save_png(ruta)
	for l in log: print("TIRA_LAT ", l)
	print("TIRA_LAT ciclo perfil = %.1f u (%.2f alturas) · ciclo frente = %.1f u · velocidad %.0f u/s" % [player.lat_ciclo, player.lat_ciclo / player.alto, player.ciclo8, player.SPEED * player.vel_k])
	get_tree().quit()

# ---- p13: GIF del andar con la CÁMARA QUIETA (el suelo no se mueve: se ve si el pie apoyado resbala), a cámara lenta x0,3:
# derecha, diagonal abajo-izquierda, abajo y arriba (--raizal --gif_p13=prefijo)
func _gif_p13(pref: String) -> void:
	await get_tree().create_timer(0.6).timeout
	_cap_limpio()
	var c := Vector2(-330, 300); var k := 0
	for tramo in [[Vector2(-150, 0), Vector2.RIGHT, 1.3], [Vector2(110, -90), Vector2(-1, 1), 1.0], [Vector2(0, -110), Vector2.DOWN, 1.0], [Vector2(0, 110), Vector2.UP, 1.0]]:
		Engine.time_scale = 1.0
		player.position = c + tramo[0]; andar_dir = Vector2.ZERO; cam.position = c; cam.reset_smoothing()
		await get_tree().create_timer(0.3).timeout
		Engine.time_scale = 0.3
		andar_dir = tramo[1].normalized()
		var t0: float = t
		while t - t0 < tramo[2]:
			cam.position = c
			await RenderingServer.frame_post_draw
			var vimg := get_viewport().get_texture().get_image()
			var sp: Vector2 = _en_pantalla(vimg, c + Vector2(0, -30))
			vimg.get_region(Rect2i(int(sp.x) - 200, int(sp.y) - 130, 400, 240)).save_png("%s%03d.png" % [pref, k]); k += 1
			await get_tree().process_frame
		andar_dir = Vector2.ZERO
	Engine.time_scale = 1.0
	print("GIF_P13 %d fotogramas" % k)
	get_tree().quit()

# ---- GIF del andar: Eco a la derecha y a la izquierda en Raizal, cámara siguiendo (--raizal --gif_lat=prefijo) ----
func _gif_lat(pref: String) -> void:
	await get_tree().create_timer(0.6).timeout
	_cap_limpio()
	Engine.time_scale = 0.2
	var tiempos := []; var k := 0
	for dv in [Vector2.RIGHT, Vector2.LEFT]:
		player.position = Vector2(-260, 470) if dv.x > 0 else Vector2(260, 470); cam.position = player.position; cam.reset_smoothing()
		andar_dir = dv
		var t0: float = t
		while t - t0 < 1.5:
			await RenderingServer.frame_post_draw
			var vimg := get_viewport().get_texture().get_image()
			var sp: Vector2 = _en_pantalla(vimg, player.position + Vector2(0, -50))
			vimg.get_region(Rect2i(int(sp.x) - 220, int(sp.y) - 150, 440, 260)).save_png("%s%03d.png" % [pref, k]); tiempos.append(t); k += 1
			await get_tree().process_frame
		andar_dir = Vector2.ZERO
	FileAccess.open(pref + "tiempos.json", FileAccess.WRITE).store_string(JSON.stringify(tiempos))
	print("GIF_LAT %d fotogramas" % k)
	get_tree().quit()

# ---- ataque de perfil (p11): andar de perfil (referencia de altura) + los 4 fotogramas del ataque, a la derecha y a la izquierda ----
func _ataque_perfil(ruta: String) -> void:
	await get_tree().create_timer(0.6).timeout
	_cap_limpio()
	var lado := 300; var img := Image.create(lado * 5, lado * 2, false, Image.FORMAT_RGBA8)
	var base := Vector2(-250, 300); var log := []
	for r in 2:
		var sx: int = 1 if r == 0 else -1
		player.position = base - Vector2(sx * 120, 0); cam.position = base; cam.reset_smoothing()
		Engine.time_scale = 1.0
		andar_dir = Vector2(sx, 0)
		await get_tree().create_timer(0.5).timeout
		Engine.time_scale = 0.05
		await RenderingServer.frame_post_draw
		var fila := [player.spr.texture.resource_path.get_file()]
		_cap_celda(img, Vector2i(0, r * lado), lado)
		andar_dir = Vector2.ZERO; player.vel = Vector2.ZERO
		await get_tree().create_timer(0.4 * 0.05, true, false, false).timeout
		player.forzar_lado = sx; player.ataque_cd = 0.0; player.atacar()
		var ant: Texture2D = null; var n := 0
		while fila.size() < 5 and n < 600 and player.ataque_t > 0.0:
			await get_tree().process_frame; n += 1
			if player.spr.texture == ant or not "ataque" in player.spr.texture.resource_path: continue
			ant = player.spr.texture
			await RenderingServer.frame_post_draw
			_cap_celda(img, Vector2i(fila.size() * lado, r * lado), lado)
			fila.append(ant.resource_path.get_file() + (" (espejo)" if player.spr.flip_h else ""))
		player.forzar_lado = 0
		log.append(" | ".join(fila))
	Engine.time_scale = 1.0
	img.save_png(ruta)
	for l in log: print("ATAQUE_PERFIL ", l)
	print("ATAQUE_PERFIL escala andar %.3f · ataque %.3f · ciclo %.1f u" % [player.lat_k, player.at_k, player.lat_ciclo])
	get_tree().quit()

# ---- vecino, Gusana, Plumas y bellota andando de perfil (p11): una fila por personaje, cada fotograma tal cual en el juego ----
func _andan_lado(ruta: String) -> void:
	await get_tree().create_timer(0.6).timeout
	_cap_limpio(); player.visible = false
	var quien := [["repartidor", 108.0, false], ["carpintera", 108.0, false], ["nina", 92.0, false], ["gusana", 70.0, true], ["plumas", 96.0, true], ["bellota", 56.0, true]]
	var lado := 260; var img := Image.create(lado * 6, lado * quien.size(), false, Image.FORMAT_RGBA8)
	var base := Vector2(-250, 300); var log := []
	for r in quien.size():
		var n := Node2D.new(); n.set_script(load("res://vecino.gd")); n.id = quien[r][0]; n.alto = quien[r][1]; n.solo_lat = quien[r][2]
		n.ruta = [base - Vector2(160, 0), base + Vector2(400, 0)]; n.pausa = Vector2(0.0, 0.0); n.z_as_relative = false; n.z_index = 200
		raizal_esc.add_child(n); n.espera = 0.0
		cam.position = base; cam.reset_smoothing()
		Engine.time_scale = 0.15
		var fila := []; var ant: Texture2D = null; var k := 0
		while fila.size() < 6 and k < 900:
			await get_tree().process_frame; k += 1
			if n.spr.texture == ant or not n.spr.texture in n.lat: continue
			ant = n.spr.texture
			await RenderingServer.frame_post_draw
			var vimg := get_viewport().get_texture().get_image()
			if vimg.get_format() != Image.FORMAT_RGBA8: vimg.convert(Image.FORMAT_RGBA8)
			var sp: Vector2 = _en_pantalla(vimg, n.position + Vector2(0, -n.alto * 0.5))
			img.blit_rect(vimg, Rect2i(int(sp.x) - lado / 2, int(sp.y) - lado / 2, lado, lado), Vector2i(fila.size() * lado, r * lado))
			fila.append(ant.resource_path.get_file())
		log.append("%s (ciclo %.1f u, escala %.3f): %s" % [quien[r][0], n.lat_ciclo, n.lat_k, " | ".join(fila)])
		n.queue_free(); Engine.time_scale = 1.0
	img.save_png(ruta)
	for l in log: print("ANDAN_LADO ", l)
	get_tree().quit()

# ---- casa de adorno de puerta azul (pescador en espejo, CASAS_DECO[7]): Eco anda contra la puerta y se queda fuera ----
func _casa_cerrada(ruta: String) -> void:
	await get_tree().create_timer(0.6).timeout
	_cap_limpio()
	var c: Array = Raizal.CASAS_DECO[7]
	player.position = c[1] + Vector2(0, 110); cam.position = c[1] + Vector2(0, -80); cam.reset_smoothing()
	andar_dir = Vector2.UP
	await get_tree().create_timer(1.6).timeout
	andar_dir = Vector2.ZERO
	await get_tree().create_timer(0.5).timeout
	cam.position = c[1] + Vector2(0, -80); cam.reset_smoothing()
	await RenderingServer.frame_post_draw
	var vimg := get_viewport().get_texture().get_image()
	var sp: Vector2 = _en_pantalla(vimg, c[1] + Vector2(0, -110))
	vimg.get_region(Rect2i(int(sp.x) - 520, int(sp.y) - 420, 1040, 640)).save_png(ruta)
	print("CASA_CERRADA dentro='%s' pies_rel=%s" % [dentro, player.position - c[1]])
	get_tree().quit()

# ---- p13: vista fija de un punto del mapa (--vista_en=x,y,ruta[,jx,jy]): cámara en x,y; jugador en jx,jy (o fuera de cuadro)
func _vista_en(arg: String) -> void:
	var q := arg.split(",")
	await get_tree().create_timer(0.6).timeout
	_cap_limpio()
	var c := Vector2(float(q[0]), float(q[1]))
	player.position = Vector2(float(q[3]), float(q[4])) if q.size() >= 5 else c + Vector2(0, 2000)
	player.mira = Vector2.DOWN
	for i in 20:
		cam.position = c; cam.reset_smoothing(); await get_tree().process_frame
	await RenderingServer.frame_post_draw
	get_viewport().get_texture().get_image().save_png(q[2]); print("VISTA ", q[2])
	get_tree().quit()

# ---- p13: patinar. Mide EN EL JUEGO dónde queda en el mundo el pie apoyado (contactos con el suelo del fotograma que se ve)
# mientras el pj anda en una dirección (--medir_patina=dx,dy). Imprime por fotograma de juego: x/y del cuerpo y de los contactos.
var _cont_cache := {}
func _contactos_tex(tx: Texture2D) -> Array:
	if _cont_cache.has(tx): return _cont_cache[tx]
	var im: Image = tx.get_image(); if im.is_compressed(): im.decompress()
	var W := im.get_width(); var H := im.get_height(); var suelo := 0
	for y in range(H - 1, 0, -1):
		var hay := false
		for x in W: if im.get_pixel(x, y).a > 0.24: hay = true; break
		if hay: suelo = y; break
	var col := []
	for x in W:
		var c := false
		for y in range(suelo - 3, suelo + 1): if im.get_pixel(x, y).a > 0.24: c = true
		col.append(c)
	var tramos := []; var ini := -1
	for x in W + 1:
		var c: bool = x < W and col[x]
		if c and ini < 0: ini = x
		if not c and ini >= 0:
			if x - ini >= 3: tramos.append([ini, x - 1, suelo])
			ini = -1
	_cont_cache[tx] = tramos; return tramos
# ---- p14: Eco anda hacia arriba desde x0,y0 hasta que se para (contra la puerta); captura con la cámara del juego y luego
# un zoom (x2.5) centrado en la puerta. --andar_a_puerta=x0,y0,captura.png,zoom.png
# p13b: tamaño VISIBLE (píxeles opacos, sin márgenes transparentes) de sprites del escenario, en u de mundo y en px de pantalla
# con la cámara del juego. --medir_visible=nodo1,nodo2,...  (Eco = "eco")
func _medir_visible(arg: String) -> void:
	await get_tree().create_timer(0.6).timeout
	print("ZOOM ", cam.zoom.x, " · ventana ", get_viewport().get_visible_rect().size)
	for n in arg.split(","):
		var sp: Sprite2D = player.spr if n == "eco" else raizal_esc.get_node_or_null(n)
		if sp == null: print("VISIBLE ", n, " no existe"); continue
		var im: Image = sp.texture.get_image(); if im.is_compressed(): im.decompress()
		var r := Rect2(_usado(im, 0.1)); var rr := sp.get_rect()
		var px := Rect2(rr.position + r.position * (rr.size / Vector2(im.get_size())), r.size * (rr.size / Vector2(im.get_size())))
		var w := sp.get_global_transform() * px
		print("VISIBLE %s: %d x %d u (ancho x alto) · %d x %d px de pantalla · pies %s" % [n, w.size.x, w.size.y, w.size.x * cam.zoom.x, w.size.y * cam.zoom.y, Vector2i(sp.global_position)])
	get_tree().quit()
func _visible_u(sp: Sprite2D) -> Vector2:
	var im: Image = sp.texture.get_image(); if im.is_compressed(): im.decompress()
	var r := Rect2(_usado(im, 0.1)); var rr := sp.get_rect()
	return (sp.get_global_transform() * Rect2(rr.position + r.position * (rr.size / Vector2(im.get_size())), r.size * (rr.size / Vector2(im.get_size())))).size
static func _usado(im: Image, umbral: float) -> Rect2i:
	var x0 := im.get_width(); var y0 := im.get_height(); var x1 := -1; var y1 := -1
	for y in range(0, im.get_height(), 2):
		for x in range(0, im.get_width(), 2):
			if im.get_pixel(x, y).a > umbral: x0 = min(x0, x); x1 = max(x1, x); y0 = min(y0, y); y1 = max(y1, y)
	return Rect2i(x0, y0, x1 - x0 + 2, y1 - y0 + 2)

var zoom_fijo := Vector2.ZERO
var jefe_vista := Rect2()   # p21: arena del jefe mientras dura la pelea (vacía = cámara normal)
var _s_cam := 0.0; var _s_suave := false
var cam_fija := Vector2.INF
# p15 · capturas de colarse: --andar_hacia=x0,y0,dx,dy,xmeta,captura.png,camx,camy: anda desde (x0,y0) en (dx,dy) hasta pasar
# x = xmeta o quedarse parado; cámara fija en (camx,camy), mismo zoom del juego. Dice cuánto tapa la casa más cercana al niño.
func _andar_hacia(arg: String) -> void:
	var q := arg.split(",")
	await get_tree().create_timer(0.6).timeout
	for v in raizal_esc.habitantes + raizal_esc.vecinos:   # sin vecinos delante (el niño sigue con su orden de dibujo normal)
		v[0].visible = false; v[0].process_mode = Node.PROCESS_MODE_DISABLED; v[0].position = Vector2(90000, 90000)
	player.position = Vector2(float(q[0]), float(q[1])); andar_dir = Vector2(float(q[2]), float(q[3])).normalized()
	cam_fija = Vector2(float(q[6]), float(q[7]))
	var xm := float(q[4]); var t0 := t; var ult := player.position; var quieto := 0.0
	while t - t0 < 4.0:
		await get_tree().process_frame
		if player.position.distance_to(ult) < 0.2: quieto += get_process_delta_time()
		else: quieto = 0.0
		ult = player.position
		if quieto > 0.4 or (andar_dir.x > 0 and player.position.x >= xm) or (andar_dir.x < 0 and player.position.x <= xm): break
	andar_dir = Vector2.ZERO; player.mira = Vector2.DOWN
	var peor := 0.0
	for ct in raizal_esc.contornos: peor = maxf(peor, raizal_esc.tapa(ct[0], player.position))
	print("ANDAR_HACIA parado en %s · la casa tapa el %d %% del cuerpo" % [Vector2i(player.position), int(peor * 100)])
	for i in 40: await get_tree().process_frame
	await RenderingServer.frame_post_draw
	var vimg := get_viewport().get_texture().get_image(); vimg.save_png(q[5]); print("CAPTURA ", q[5])
	var cs := Vector2.INF; var dmin := 1e9
	for ct in raizal_esc.contornos:
		var dd: float = (ct[0] as Sprite2D).position.distance_to(player.position)
		if dd < dmin: dmin = dd; cs = (ct[0] as Sprite2D).position
	print("PANTALLA casa %s niño %s" % [Vector2i(_en_pantalla(vimg, cs)), Vector2i(_en_pantalla(vimg, player.position))])
	get_tree().quit()

func _andar_a_puerta(arg: String) -> void:
	var q := arg.split(",")
	await get_tree().create_timer(0.6).timeout
	player.position = Vector2(float(q[0]), float(q[1])); andar_dir = Vector2.UP
	var t0 := t; var ult := player.position; var quieto := 0.0
	while t - t0 < 6.0:
		await get_tree().process_frame
		if player.position.distance_to(ult) < 0.2: quieto += get_process_delta_time()
		else: quieto = 0.0
		ult = player.position
		if quieto > 0.5: break
	andar_dir = Vector2.ZERO; player.mira = Vector2.DOWN   # de cara a la cámara, para ver la escala
	if q.size() > 5: cam_fija = Vector2(0, float(q[5]))   # 6.º valor: y del centro de la cámara (mismo zoom del juego)
	print("PARADO EN ", Vector2i(player.position), " (", "%.1f" % (t - t0), " s)")
	for i in 40: await get_tree().process_frame
	await RenderingServer.frame_post_draw
	get_viewport().get_texture().get_image().save_png(q[2]); print("CAPTURA ", q[2])
	if q.size() > 3:
		zoom_fijo = cam.zoom * 2.2; cam_fija = Vector2(0, float(q[4]) if q.size() > 4 else -420.0)   # 5.º valor: y del centro del zoom
		for i in 30: await get_tree().process_frame
		await RenderingServer.frame_post_draw
		get_viewport().get_texture().get_image().save_png(q[3]); print("ZOOM ", q[3])
	get_tree().quit()

func _medir_patina(arg: String) -> void:
	await get_tree().create_timer(0.6).timeout
	_cap_limpio()
	var q := arg.split(","); var dv := Vector2(float(q[0]), float(q[1])).normalized()
	player.position = Vector2(-330, 300) - dv * 260.0; andar_dir = dv
	var t0 := t
	while t - t0 < 2.6:
		await get_tree().process_frame
		var sp: Sprite2D = player.spr
		var t_r: Transform2D = sp.get_global_transform()
		var out := []
		for c in _contactos_tex(sp.texture):
			var W: int = sp.texture.get_width()
			for xx in [c[0], c[1]]:
				var px: float = (W - 1 - xx) if sp.flip_h else xx
				var off: Vector2 = sp.offset if not sp.centered else -sp.texture.get_size() / 2.0 + sp.offset
				out.append("%.1f,%.1f" % [(t_r * (Vector2(px, c[2]) + off)).x, (t_r * (Vector2(px, c[2]) + off)).y])
		print("PAT %.3f %.1f %.1f %s %s" % [t - t0, player.position.x, player.position.y, sp.texture.resource_path.get_file(), " ".join(out)])
	andar_dir = Vector2.ZERO
	get_tree().quit()

# ---- p13: casa del tocón de adorno (CASAS_DECO[3]): Eco intenta meterse por arriba, por los lados y por la puerta ----
func _casa_tocon(ruta: String, idx := 3) -> void:
	await get_tree().create_timer(0.6).timeout
	_cap_limpio()
	var c: Array = Raizal.CASAS_DECO[idx]
	var intentos := [[Vector2(0, -330), Vector2.DOWN], [Vector2(-230, -120), Vector2.RIGHT], [Vector2(230, -120), Vector2.LEFT], [Vector2(0, 120), Vector2.UP]]
	var i := 0
	for it in intentos:
		player.position = c[1] + it[0]; andar_dir = it[1]
		await get_tree().create_timer(2.2).timeout
		andar_dir = Vector2.ZERO
		await get_tree().create_timer(0.4).timeout
		cam.position = c[1] + Vector2(0, -130); cam.reset_smoothing()
		await RenderingServer.frame_post_draw
		var vimg := get_viewport().get_texture().get_image()
		var sp: Vector2 = _en_pantalla(vimg, c[1] + Vector2(0, -130))
		vimg.get_region(Rect2i(int(sp.x) - 330, int(sp.y) - 330, 660, 600)).save_png(ruta.replace(".png", "_%d.png" % i))
		print("CASA_TOCON intento %d desde %s -> se para en %s (dentro=%s)" % [i, it[0], Vector2i(player.position - c[1]), dentro])
		i += 1
	get_tree().quit()

# ---- camino de la plaza a casa de la abuela por donde estaba el arco del Corral: Eco lo recorre andando (--raizal --camino_corral=ruta) ----
func _camino_corral(ruta: String) -> void:
	await get_tree().create_timer(0.6).timeout
	_cap_limpio()
	var pts := [Vector2(-760, -200), Vector2(-1020, -330), Vector2(-1180, -640)]
	player.position = pts[0]; cam.position = Vector2(-1000, -380); cam.reset_smoothing()
	var llegado := true; var t0 := t
	for i in range(1, pts.size()):
		while player.position.distance_to(pts[i]) > 20.0 and t - t0 < 8.0:
			andar_dir = (pts[i] - player.position).normalized(); await get_tree().process_frame
			cam.position = Vector2(-1000, -380)
			if i == 1 and player.position.distance_to(pts[1]) < 40.0 and not FileAccess.file_exists(ruta):
				await RenderingServer.frame_post_draw
				var vimg := get_viewport().get_texture().get_image()
				var sp: Vector2 = _en_pantalla(vimg, Vector2(-1000, -380))
				vimg.get_region(Rect2i(int(sp.x) - 560, int(sp.y) - 400, 1120, 760)).save_png(ruta)
		if player.position.distance_to(pts[i]) > 20.0: llegado = false
	andar_dir = Vector2.ZERO
	print("CAMINO_CORRAL llega=%s pos=%s t=%.1f s" % [llegado, Vector2i(player.position), t - t0])
	get_tree().quit()

# ---- p12: Doña Plumas en su rama flotante: quieta (vaivén), de lado a lado y hacia arriba con su estela (--raizal --plumas_rama=prefijo) ----
func _plumas_rama_cap(pref: String) -> void:
	await get_tree().create_timer(0.6).timeout
	if raizal_esc != null:
		for v in raizal_esc.vecinos:
			v[0].visible = false; v[0].process_mode = Node.PROCESS_MODE_DISABLED; v[0].position = Vector2(90000, 90000)
	var pl: Node2D = _npc("plumas")[0]
	var o: Vector2 = pl.position
	player.position = o + Vector2(-230, 120)
	var cen: Vector2 = o + Vector2(60, -90)
	var tw := create_tween()
	tw.tween_interval(1.4)
	tw.tween_property(pl, "position", o + Vector2(300, 0), 1.5).set_trans(Tween.TRANS_SINE)
	tw.tween_interval(0.6)
	tw.tween_property(pl, "position", o + Vector2(0, -170), 1.5).set_trans(Tween.TRANS_SINE)
	tw.tween_interval(0.5)
	tw.tween_property(pl, "position", o, 1.3).set_trans(Tween.TRANS_SINE)
	tw.tween_interval(0.8)
	var k := 0; var t0 := t
	while t - t0 < 9.4:
		cam.position = cen; cam.reset_smoothing()
		await RenderingServer.frame_post_draw
		var vimg := get_viewport().get_texture().get_image()
		var sp: Vector2 = _en_pantalla(vimg, cen)
		vimg.get_region(Rect2i(int(sp.x) - 400, int(sp.y) - 260, 800, 520)).save_png("%s%03d.png" % [pref, k]); k += 1
		await get_tree().create_timer(0.05).timeout
	print("PLUMAS_RAMA %d fotogramas · script %s · rama %s · z %d · visible %s" % [k, pl.get_script().resource_path, pl.rama.position, pl.z_index, pl.is_visible_in_tree()])
	get_tree().quit()

func _cap_celda(img: Image, dst: Vector2i, lado: int) -> void:
	var vimg := get_viewport().get_texture().get_image()
	if vimg.get_format() != Image.FORMAT_RGBA8: vimg.convert(Image.FORMAT_RGBA8)
	var sp: Vector2 = _en_pantalla(vimg, player.position + Vector2(0, -50))
	img.blit_rect(vimg, Rect2i(int(sp.x) - lado / 2, int(sp.y) - lado / 2, lado, lado), dst)

func _cap_limpio() -> void:   # capturas p10: el pj encima de todo y sin vecinos que lo tapen
	player.z_as_relative = false; player.z_index = 200
	if raizal_esc != null:
		for v in raizal_esc.habitantes + raizal_esc.vecinos:
			v[0].visible = false; v[0].process_mode = Node.PROCESS_MODE_DISABLED; v[0].position = Vector2(90000, 90000)   # ni etiquetas ni bocadillos

func _en_pantalla(vimg: Image, p: Vector2) -> Vector2:   # punto del mundo -> píxel de la imagen del viewport
	var vr: Vector2 = get_viewport().get_visible_rect().size
	var vp: Vector2 = vr / 2.0 + (p - cam.get_screen_center_position()) * cam.zoom
	return vp * (Vector2(vimg.get_size()) / vr)

# ---- p15 · reposo frente a andar (--raizal --pj=x --reposo_vs_andar=ruta.png): en cada dirección anda, se fotografía andando,
# se para y se fotografía parado en el mismo sitio de pantalla. Dice el alto y la base visibles (px de pantalla) de los dos.
func _caja_pj(vimg: Image) -> Rect2:   # caja opaca del dibujo del niño en pantalla, medida en su textura
	var sp: Sprite2D = player.spr; var im: Image = sp.texture.get_image()
	if im.is_compressed(): im.decompress()
	var u: Rect2i = im.get_used_rect(); var ur := Rect2(u)
	var a0: Vector2 = sp.get_global_transform() * (sp.get_rect().position + ur.position) if not sp.flip_h else sp.get_global_transform() * (sp.get_rect().position + Vector2(im.get_width() - ur.end.x, ur.position.y))
	var a1: Vector2 = a0 + ur.size * sp.get_global_transform().get_scale()
	var p0 := _en_pantalla(vimg, a0); var p1 := _en_pantalla(vimg, a1)
	return Rect2(p0, p1 - p0)
const BASE_RVA := Vector2(-200, 700)   # tierra de la plaza sin vallas delante
func _reposo_vs_andar(ruta: String) -> void:
	await get_tree().create_timer(0.6).timeout
	_cap_limpio()
	var dirs := [["sur", Vector2.DOWN], ["sureste", Vector2(1, 1)], ["este", Vector2.RIGHT], ["noreste", Vector2(1, -1)],
		["norte", Vector2.UP], ["noroeste", Vector2(-1, -1)], ["oeste", Vector2.LEFT], ["suroeste", Vector2(-1, 1)]]
	var L := 150; var img := Image.create(L * 8, L * 2, false, Image.FORMAT_RGBA8)
	for r in dirs.size():
		var dv: Vector2 = dirs[r][1].normalized()
		player.position = BASE_RVA - dv * 80.0; cam_fija = BASE_RVA; andar_dir = dv
		await get_tree().create_timer(0.45).timeout
		await RenderingServer.frame_post_draw
		var v1 := get_viewport().get_texture().get_image(); if v1.get_format() != Image.FORMAT_RGBA8: v1.convert(Image.FORMAT_RGBA8)
		var c1 := _caja_pj(v1); var f1: String = player.spr.texture.resource_path.get_file().get_basename()
		var pie1: Vector2 = _en_pantalla(v1, player.position)
		andar_dir = Vector2.ZERO
		await get_tree().create_timer(0.5).timeout
		await RenderingServer.frame_post_draw
		var v2 := get_viewport().get_texture().get_image(); if v2.get_format() != Image.FORMAT_RGBA8: v2.convert(Image.FORMAT_RGBA8)
		var c2 := _caja_pj(v2); var f2: String = player.spr.texture.resource_path.get_file().get_basename()
		var pie2: Vector2 = _en_pantalla(v2, player.position)
		img.blit_rect(v1, Rect2i(int(pie1.x) - L / 2, int(pie1.y) - L + 20, L, L), Vector2i(r * L, 0))
		img.blit_rect(v2, Rect2i(int(pie2.x) - L / 2, int(pie2.y) - L + 20, L, L), Vector2i(r * L, L))
		print("REPOSO_VS %s %s andando %s alto %d px base %+d | parado %s alto %d px base %+d" % [pj, dirs[r][0], f1, c1.size.y, int(c1.end.y - pie1.y), f2, c2.size.y, int(c2.end.y - pie2.y)])
	img.save_png(ruta)
	get_tree().quit()

# ---- p15b · vista con la cámara fija en x,y (--vista_mapa=x,y,ruta[,jx,jy]): guarda la imagen y dice cómo pasar del mundo a
# la pantalla (MAPA x0 y0 zoom: píxel = (mundo - centro) * zoom + mitad de la pantalla), para medir el suelo desde fuera
func _vista_mapa(arg: String) -> void:
	var q := arg.split(",")
	await get_tree().create_timer(0.6).timeout
	_cap_limpio()
	cam_fija = Vector2(float(q[0]), float(q[1]))
	player.position = Vector2(float(q[3]), float(q[4])) if q.size() >= 5 else cam_fija + Vector2(0, 2000)
	player.mira = Vector2.DOWN
	for i in 30:
		cam.position = cam_fija; cam.reset_smoothing(); await get_tree().process_frame
	await RenderingServer.frame_post_draw
	var im := get_viewport().get_texture().get_image(); im.save_png(q[2])
	var c: Vector2 = cam.get_screen_center_position()
	print("MAPA %.2f %.2f %.5f %d %d" % [c.x, c.y, cam.zoom.x * im.get_width() / get_viewport().get_visible_rect().size.x, im.get_width(), im.get_height()])
	get_tree().quit()

# ---- pulido 2 · gif de la hierba alta (--bosque --gif_hierba=prefijo,x0,y0,x1,y1): anda de (x0,y0) a (x1,y1) cruzando la
# hierba y se para; un fotograma por frame, recortado alrededor del punto medio (cámara fija)
func _gif_hierba(arg: String) -> void:
	var q := arg.split(",")
	var a := Vector2(float(q[1]), float(q[2])); var b := Vector2(float(q[3]), float(q[4])); var m := (a + b) / 2.0
	await get_tree().create_timer(0.6).timeout
	_cap_limpio()
	player.position = a; cam_fija = m
	for i in 20:
		cam.position = cam_fija; cam.reset_smoothing(); await get_tree().process_frame
	var n := 0; var parado := 0.0
	Engine.time_scale = 0.25
	while parado < 0.8:
		var d := b - player.position
		andar_dir = d.normalized() if d.length() > 12.0 else Vector2.ZERO
		if andar_dir == Vector2.ZERO: parado += get_process_delta_time()
		cam.position = cam_fija
		await RenderingServer.frame_post_draw
		var v := get_viewport().get_texture().get_image()
		var c := _en_pantalla(v, m + Vector2(0, -40))
		v.get_region(Rect2i(int(c.x) - 240, int(c.y) - 120, 480, 240)).save_png("%s_%03d.png" % [q[0], n]); n += 1
		if n > 400: break
	print("GIF_HIERBA ", n, " fotogramas")
	get_tree().quit()

# ---- p22 · gif de la flora que ataca (--bosque --gif_flora=prefijo,índice[,hora]): el niño pasa junto a la planta índice de
# data/flora_ataca.json, se deja atacar, y luego le pega hasta calmarla. Un PNG por frame con su tiempo de juego en el nombre.
func _gif_flora(arg: String) -> void:
	var q := arg.split(","); var idx := int(q[1])
	await get_tree().create_timer(0.8).timeout
	_cap_limpio(); god = false
	var pl_ = bosque_esc.plantas[idx]; var p: Vector2 = pl_.position; var tp: String = pl_.tipo
	var hc: Array = Planta.cfg()["sitios"][idx]["hacia_camino"]; var h := Vector2(hc[0], hc[1]).normalized(); var tg := h.orthogonal()
	var plan: Array = []   # [destino, segundos, pegar]
	match tp:
		"garra": player.position = p + h * 100 - tg * 330; plan = [[p + h * 100 + tg * 330, 2.4, false], [p + h * 95, 1.0, false], [p + h * 95, 2.4, true], [p + h * 95, 4.8, false]]
		"capullos": player.position = p + h * 290; plan = [[p + h * 290, 1.4, false], [p + h * 290 + tg * 150, 1.6, false], [p + h * 110, 1.0, false], [p + h * 110, 2.0, true], [p + h * 110, 4.8, false]]
		_: player.position = p + h * 330; plan = [[p + h * 100, 1.0, false], [p + h * 100, 1.6, false], [p + h * 320, 1.4, false], [p + h * 100, 0.8, false], [p + h * 100, 2.0, true], [p + h * 100, 4.8, false]]
	pl_.cd = 0.0
	cam_fija = p + h * (165.0 if tp == "capullos" else 130.0) + Vector2(0, -70)
	for i in 20:
		cam.position = cam_fija; cam.reset_smoothing(); await get_tree().process_frame
	var n := 0; var pega_t := 0.0
	Engine.time_scale = 0.25
	for paso in plan:
		var t0 := t
		while t - t0 < paso[1]:
			var dd: Vector2 = paso[0] - player.position
			andar_dir = dd.normalized() if dd.length() > 14.0 else Vector2.ZERO
			player.hp = player.max_hp   # el gif enseña el ataque, no el desmayo
			if paso[2]:
				pega_t -= get_process_delta_time()
				if pega_t <= 0.0 and pl_.estado != "calmada": pega_t = 0.32; damage_enemy(pl_, 5.0, (p - player.position).normalized())
			cam.position = cam_fija
			await RenderingServer.frame_post_draw
			var v := get_viewport().get_texture().get_image()
			var c := _en_pantalla(v, cam_fija)
			v.get_region(Rect2i(int(c.x) - 270, int(c.y) - 170, 540, 340)).save_png("%s_%04d_%06d.png" % [q[0], n, int(t * 1000.0)]); n += 1
	print("GIF_FLORA ", tp, " ", n, " fotogramas")
	get_tree().quit()

# ---- p22 · gif del equipo por capas (--raizal --pj=x [--equipo=todo] --gif_equipo=prefijo): anda en las 8 direcciones parándose
# en cada una y ataca hacia abajo, a la derecha, arriba y a la izquierda; recorte de 300×300 alrededor del niño
func _gif_equipo(pref: String) -> void:
	await get_tree().create_timer(0.6).timeout
	_cap_limpio()
	player.position = BASE_RVA
	var plan: Array = []   # [dirección, segundos, atacar]
	for d in [Vector2.RIGHT, Vector2(1, 1), Vector2.DOWN, Vector2(-1, 1), Vector2.LEFT, Vector2(-1, -1), Vector2.UP, Vector2(1, -1)]:
		plan.append([d.normalized(), 0.55, false]); plan.append([Vector2.ZERO, 0.45, false])
	for d in [Vector2.DOWN, Vector2.RIGHT, Vector2.UP, Vector2.LEFT]: plan.append([d, 0.5, true])
	plan.append([Vector2.ZERO, 0.4, false])
	var n := 0
	Engine.time_scale = 0.25
	for pl in plan:
		var t0 := t
		while t - t0 < pl[1]:
			if pl[2]:
				andar_dir = Vector2.ZERO; player.mira = pl[0]; player.aim = pl[0]
				if player.ataque_t <= 0.0: player.ataque_t = player.T_ATAQUE8 * 4.0
			else: andar_dir = pl[0]
			cam.position = player.position + Vector2(0, -60); cam.reset_smoothing()
			await RenderingServer.frame_post_draw
			var v := get_viewport().get_texture().get_image()
			var c := _en_pantalla(v, player.position + Vector2(0, -65))
			v.get_region(Rect2i(int(c.x) - 150, int(c.y) - 150, 300, 300)).save_png("%s_%04d_%06d.png" % [pref, n, int(t * 1000.0)]); n += 1
	print("GIF_EQUIPO ", n, " fotogramas")
	get_tree().quit()

# ---- p15 · gif de andar y pararse (--raizal --pj=x --gif_parar=prefijo): un fotograma por frame (con su tiempo de juego), recortados alrededor del niño
func _gif_parar(pref: String) -> void:
	await get_tree().create_timer(0.6).timeout
	_cap_limpio()
	player.position = BASE_RVA + Vector2(-140, 0); cam_fija = BASE_RVA
	var plan := [[Vector2.RIGHT, 0.9], [Vector2.ZERO, 0.7], [Vector2(-1, 1).normalized(), 0.5], [Vector2.ZERO, 0.6], [Vector2.UP, 0.5], [Vector2.ZERO, 0.6], [Vector2.LEFT, 0.6], [Vector2.ZERO, 0.7]]
	var n := 0
	Engine.time_scale = 0.2   # la captura es lenta: a cámara lenta salen ~35 fotogramas por segundo de juego
	for pl in plan:
		andar_dir = pl[0]; var t0 := t
		while t - t0 < pl[1]:
			await RenderingServer.frame_post_draw
			var v := get_viewport().get_texture().get_image()
			var c := _en_pantalla(v, BASE_RVA)
			v.get_region(Rect2i(int(c.x) - 260, int(c.y) - 170, 520, 300)).save_png("%s_%03d_%05d.png" % [pref, n, int(t * 1000.0)]); n += 1
	print("GIF_PARAR ", n, " fotogramas")
	get_tree().quit()

# ---- reposo: anda en cada dirección, se para y se fotografía (los dos pies en el suelo) (--raizal --reposo_lat=ruta.png) ----
func _reposo_lat(ruta: String) -> void:
	await get_tree().create_timer(0.6).timeout
	_cap_limpio()
	var dirs := [["derecha", Vector2.RIGHT], ["izquierda", Vector2.LEFT], ["abajo", Vector2.DOWN], ["arriba", Vector2.UP],
		["abajo-der", Vector2(1, 1)], ["arriba-izq", Vector2(-1, -1)], ["abajo-izq", Vector2(-1, 1)], ["arriba-der", Vector2(1, -1)]]
	var lado := 170; var img := Image.create(lado * 4, lado * 2, false, Image.FORMAT_RGBA8)
	var pies := Image.create(360 * 4, 320 * 2, false, Image.FORMAT_RGBA8)   # zoom x4 a los pies
	var base := Vector2(0, 470)
	for a in OS.get_cmdline_user_args():
		if a.begins_with("--reposo_pos="): var q: PackedStringArray = a.get_slice("=", 1).split(","); base = Vector2(float(q[0]), float(q[1]))
	var log := []
	for r in dirs.size():
		var dv: Vector2 = dirs[r][1].normalized()
		player.position = base - dv * 90.0; cam.position = player.position; cam.reset_smoothing()
		andar_dir = dv
		await get_tree().create_timer(0.37 + 0.05 * r).timeout   # se para en una fase distinta cada vez
		andar_dir = Vector2.ZERO
		await get_tree().create_timer(0.5).timeout
		await RenderingServer.frame_post_draw
		var vimg := get_viewport().get_texture().get_image()
		if vimg.get_format() != Image.FORMAT_RGBA8: vimg.convert(Image.FORMAT_RGBA8)
		var sp: Vector2 = _en_pantalla(vimg, player.position + Vector2(0, -40))
		img.blit_rect(vimg, Rect2i(int(sp.x) - lado / 2, int(sp.y) - lado / 2, lado, lado), Vector2i((r % 4) * lado, (r / 4) * lado))
		var fp: Vector2 = _en_pantalla(vimg, player.position)
		var cp := vimg.get_region(Rect2i(int(fp.x) - 45, int(fp.y) - 66, 90, 80)); cp.resize(360, 320, Image.INTERPOLATE_NEAREST)
		pies.blit_rect(cp, Rect2i(0, 0, 360, 320), Vector2i((r % 4) * 360, (r / 4) * 320))
		if "--reposo_grande" in OS.get_cmdline_user_args(): vimg.get_region(Rect2i(int(fp.x) - 150, int(fp.y) - 260, 300, 330)).save_png(ruta.get_basename() + "_%d.png" % r)
		log.append("%s: %s%s%s" % [dirs[r][0], player.spr.texture.resource_path.get_file().get_basename(), " (espejo)" if player.spr.flip_h else "", "" if state == "jugando" else " [%s]" % state])
	img.save_png(ruta); pies.save_png(ruta.get_basename() + "_pies.png")
	print("REPOSO ", " | ".join(log))
	get_tree().quit()

# ---- capturas p11 de los compañeros (--raizal --etapa=5 --cap_comps=prefijo): escala junto a Eco, seguir andando, refugio, Chispa ----
func _cap_vista(ruta: String) -> void:
	await RenderingServer.frame_post_draw
	var im := get_viewport().get_texture().get_image(); im.save_png(ruta)
func _cap_comps(pref: String) -> void:
	await get_tree().create_timer(0.6).timeout
	for c in Secretos.ORDEN: Secretos.poner(arpg, "comps", c)
	arpg["hojas"] = 5; arpg["sigue"] = "musgo"; arpg["evo"] = {}
	_cap_limpio()   # en Raizal, de día y en la plaza de tierra (se ve mejor la escala y los pies)
	var base := Vector2(-330, 300)
	# 1) escala: Eco y los cuatro, Cría (fila 1) e Intermedio (fila 2)
	if companero: companero.queue_free(); companero = null
	player.position = base + Vector2(0, -170); player.mira = Vector2.DOWN; cam.position = base + Vector2(170, -60); cam.reset_smoothing()
	var hechos: Array = []
	for fila in 2:
		for i in 4:
			var n := Node2D.new(); n.set_script(load("res://companero.gd")); n.tipo = Secretos.ORDEN[i]; n.evo = fila
			n.reposa = base + Vector2(120 + i * 95, -170 + fila * 140); add_child(n); hechos.append(n)
	var p2 := Node2D.new(); p2.set_script(load("res://player.gd")); add_child(p2); p2.position = base + Vector2(0, -30); p2.mira = Vector2.DOWN
	await get_tree().create_timer(1.0).timeout
	await _cap_vista(pref + "escala.png")
	print("CAP escala Eco alto=%.0f · cría=%.0f · intermedio=%.0f" % [player.alto, hechos[0].ALTO[0], hechos[0].ALTO[1]])
	for n in hechos: n.queue_free()
	p2.queue_free()
	# 2) Musguito te sigue: Eco anda a la derecha y vuelve a la izquierda (fotogramas cada 0,05 s de juego)
	player.position = base + Vector2(-150, 0); cam.position = player.position; cam.reset_smoothing()
	companero = _nodo_comp("musgo"); await get_tree().create_timer(0.6).timeout
	Engine.time_scale = 0.25
	var k := 0
	for dv in [Vector2.RIGHT, Vector2.LEFT]:
		andar_dir = dv
		var t0 := t
		while t - t0 < 1.6:
			await get_tree().create_timer(0.05).timeout
			await RenderingServer.frame_post_draw
			var vimg := get_viewport().get_texture().get_image()
			if vimg.get_format() != Image.FORMAT_RGBA8: vimg.convert(Image.FORMAT_RGBA8)
			var sp: Vector2 = _en_pantalla(vimg, player.position + Vector2(0, -50))
			vimg.get_region(Rect2i(int(sp.x) - 260, int(sp.y) - 110, 520, 200)).save_png(pref + "sigue_%03d.png" % k); k += 1
	andar_dir = Vector2.ZERO
	await get_tree().create_timer(0.5).timeout
	await _cap_vista(pref + "sigue_parado.png")
	Engine.time_scale = 1.0
	print("CAP sigue %d fotogramas" % k)
	# 3) Chispa revela un objeto misterioso (y de día: el bosque igual)
	arpg["sigue"] = "chispa"; start_bosque(); await get_tree().create_timer(0.3).timeout
	for e in enemies: if is_instance_valid(e): e.visible = false; e.process_mode = Node.PROCESS_MODE_DISABLED
	var mp: Vector2 = Secretos.MISTERIOS[0]["pos"]
	player.position = mp + Vector2(-430, 30); cam.position = mp + Vector2(-150, 0); cam.reset_smoothing(); _poner_companero()
	await get_tree().create_timer(0.4).timeout
	await _cap_vista(pref + "chispa_lejos.png")
	player.position = mp + Vector2(-120, 30); companero.position = mp + Vector2(-70, 20); await get_tree().create_timer(0.5).timeout
	await _cap_vista(pref + "chispa_revela.png")
	print("CAP misterio visible=", misterios_n[0][0].visible if not misterios_n.is_empty() else "-")
	# 4) refugio: tres en sus rincones (Chispa ya es Intermedio), Musguito te sigue; y la ventana de la bruja
	arpg["sigue"] = "musgo"; arpg["evo"] = {"chispa": 1}
	start_zona("refugio"); await get_tree().create_timer(1.0).timeout
	await _cap_vista(pref + "refugio.png")
	_bruja_ui(); await get_tree().create_timer(0.8).timeout
	await _cap_vista(pref + "refugio_bruja.png")
	print("CAP_FIN")
	get_tree().quit()

# ---- p21 · vista general del bosque (--bosque --mosaico=carpeta[,zoom]): la cámara recorre el mapa entero en baldosas y guarda
# cada una con su centro; un script de python las junta en una sola imagen
func _mosaico(arg: String) -> void:
	var q := arg.split(",")
	var z: float = float(q[1]) if q.size() > 1 else 0.25
	await get_tree().create_timer(0.8).timeout
	_cap_limpio()
	for c in get_children():
		if c is CanvasLayer and c.layer >= 1: c.visible = false
	zoom_fijo = Vector2.ONE * z
	var vs: Vector2 = get_viewport().get_visible_rect().size
	var w: float = vs.x / z; var h: float = vs.y / z
	var nx: int = int(ceil(arena.size.x / w)); var ny: int = int(ceil(arena.size.y / h))
	for j in ny:
		for i in nx:
			var cx: float = arena.position.x + w * 0.5 + (0.0 if nx == 1 else i * (arena.size.x - w) / (nx - 1))
			var cy: float = arena.position.y + h * 0.5 + (0.0 if ny == 1 else j * (arena.size.y - h) / (ny - 1))
			cam_fija = Vector2(cx, cy)
			for k in 10:
				cam.position = cam_fija; cam.reset_smoothing(); await get_tree().process_frame
			await RenderingServer.frame_post_draw
			var im := get_viewport().get_texture().get_image(); im.save_png("%s/m_%02d_%02d.png" % [q[0], j, i])
			var cc: Vector2 = cam.get_screen_center_position()
			print("MOSAICO %d %d %.1f %.1f %.5f %d %d" % [j, i, cc.x, cc.y, cam.zoom.x * im.get_width() / vs.x, im.get_width(), im.get_height()])
	get_tree().quit()
