extends Control
# p23 · base de las pantallas de las teclas M e I: un lienzo de diseño de 1280 × 720 (como las maquetas de capturas_ui) escalado
# y centrado en la ventana, con la cabecera común (título, subtítulo, X) y ayudas de dibujo. Las piezas horneadas están en
# assets/ui/teclas/ (diseno/inventario_mapa/hornear.py, a 2x).
const R := "res://assets/ui/teclas/"
const DISENO := Vector2(1280, 720)
const TINTA := Color(0.275, 0.173, 0.078)
const PAPEL := Color(0.957, 0.91, 0.784)
const APAGADO := Color(0.5, 0.455, 0.376)
const SUAVE2 := Color(0.43, 0.49, 0.46)
var L: Control                  # lienzo de diseño
var tec                         # teclas.gd
var modo := ""
var k := 1.0
var tx := {}

func _ready() -> void:
	process_mode = Node.PROCESS_MODE_ALWAYS
	set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT); mouse_filter = Control.MOUSE_FILTER_STOP
	tec = get_meta("teclas"); modo = get_meta("modo")
	L = Control.new(); L.size = DISENO; L.mouse_filter = Control.MOUSE_FILTER_PASS; add_child(L)
	L.draw.connect(_dibujar); L.gui_input.connect(_entrada)
	_ajustar(); get_viewport().size_changed.connect(_ajustar)
	_montar()
func _ajustar() -> void:
	var vs: Vector2 = get_viewport_rect().size
	k = min(vs.x / DISENO.x, vs.y / DISENO.y); L.scale = Vector2.ONE * k; L.position = ((vs - DISENO * k) / 2.0).floor()
func _montar() -> void: pass
func _dibujar() -> void: pass
func _entrada(_e: InputEvent) -> void: pass
func m(): return tec.m()

func t(nombre: String) -> Texture2D:
	if not tx.has(nombre): tx[nombre] = load(R + nombre + ".png")
	return tx[nombre]
# textura horneada a 2x: se dibuja a la mitad en coordenadas de diseño
func pon(c: CanvasItem, nombre: String, p: Vector2, tam := Vector2.ZERO, mod := Color.WHITE) -> void:
	var tt := t(nombre)
	if tt == null: return
	c.draw_texture_rect(tt, Rect2(p, tam if tam != Vector2.ZERO else tt.get_size() / 2.0), false, mod)
func txt(c: CanvasItem, s: String, p: Vector2, tam: int, col: Color, ali := HORIZONTAL_ALIGNMENT_LEFT, fuente: Font = null, borde := 0, col_b := Color(0.02, 0.07, 0.07, 0.85), ancho := -1.0) -> void:
	var f: Font = fuente if fuente else Estilo.sans()
	var w: float = ancho if ancho > 0 else 1400.0
	var x: float = p.x if ali == HORIZONTAL_ALIGNMENT_LEFT else (p.x - w / 2.0 if ali == HORIZONTAL_ALIGNMENT_CENTER else p.x - w)
	var y: float = p.y + (f.get_ascent(tam) - f.get_descent(tam)) / 2.0   # p.y es el centro vertical
	if borde > 0: c.draw_string_outline(f, Vector2(x, y), s, ali, w, tam, borde, col_b)
	c.draw_string(f, Vector2(x, y), s, ali, w, tam, col)
func ancho_txt(s: String, tam: int, fuente: Font = null) -> float: return (fuente if fuente else Estilo.sans()).get_string_size(s, HORIZONTAL_ALIGNMENT_LEFT, -1, tam).x
func caja(c: CanvasItem, r: Rect2, fondo := Color(0.055, 0.13, 0.125, 0.92), borde := Color(0.86, 0.73, 0.46, 0.35), radio := 10, grosor := 1) -> void:
	var sb := StyleBoxFlat.new(); sb.bg_color = fondo; sb.border_color = borde; sb.set_border_width_all(grosor); sb.set_corner_radius_all(radio); sb.anti_aliasing = true
	c.draw_style_box(sb, r)
func pastilla_oro(c: CanvasItem, centro: Vector2, n: int) -> void:
	var s := str(n); var w: float = 64.0 + ancho_txt(s, 18, Estilo.negrita())
	var r := Rect2(centro.x - w / 2.0, centro.y - 18, w, 36)
	caja(c, r, Color(0.36, 0.22, 0.1), Color(0.86, 0.66, 0.36, 0.9), 10, 2)
	caja(c, r.grow(-4), Color(0.2, 0.12, 0.06), Color(0, 0, 0, 0), 7, 0)
	c.draw_texture_rect(load("res://assets/ui/pausa/ico_oro_v2.png"), Rect2(r.position.x + 12, centro.y - 12, 24, 24), false)
	txt(c, s, Vector2(r.position.x + 44, centro.y), 18, Estilo.CREMA, HORIZONTAL_ALIGNMENT_LEFT, Estilo.negrita())
# cabecera común: retrato opcional, título, subtítulo y la X
func cabecera(c: CanvasItem, titulo: String, sub: String, retrato := "") -> void:
	var x := 44.0
	if retrato != "": pon(c, retrato, Vector2(30, 16), Vector2(72, 74)); x = 114.0
	txt(c, titulo, Vector2(x, 40), 32, Estilo.CREMA, HORIZONTAL_ALIGNMENT_LEFT, Estilo.serif(), 6)
	txt(c, sub, Vector2(x + 1, 72), 15, Estilo.SUAVE)
	pon(c, "cerrar", Vector2(1192, 22), Vector2(54, 56))
	pon(c, "marco", Vector2(0, 80), Vector2(1280, 640))
func en_cerrar(p: Vector2) -> bool: return Rect2(1192, 22, 54, 56).has_point(p)
func retrato_pj() -> String: return "retrato_" + String(Personajes.LISTA[m().pj]["img"]).get_file().split("_")[0]
func lugar() -> String:
	var mn = m()
	if mn.modo == "bosque" and mn.player: return tr(Arpg.ZONAS[Arpg.zona_bosque(mn.player.position)])
	if mn.modo == "zona": return tr("JUEGO_BOSQUE_SUSURRANTE")
	return tr("JUEGO_RAIZAL")
func nombre_pj() -> String: return tr(Personajes.LISTA[m().pj]["n"])
