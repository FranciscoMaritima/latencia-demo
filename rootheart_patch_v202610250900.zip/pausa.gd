extends Control
# Botón de pausa (arriba a la derecha) + menú de pausa con la información de la partida.
var panel: Control
var boton: Button
func m(): return get_parent().get_parent()
func _ready() -> void:
	process_mode = Node.PROCESS_MODE_ALWAYS
	set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT); mouse_filter = Control.MOUSE_FILTER_IGNORE
	# p13: icono dibujado (dos barras redondeadas, sin texto): el «II» en serif se leía como el número romano del acto 2
	boton = Button.new(); boton.text = ""; boton.name = "BotonPausa"; boton.custom_minimum_size = Vector2(52, 52); boton.size = Vector2(52, 52); boton.add_theme_font_size_override("font_size", 20)
	boton.add_theme_font_override("font", Estilo.negrita()); boton.add_theme_stylebox_override("normal", Estilo.caja(Color(0.06, 0.17, 0.17, 0.82), Color(0.86, 0.73, 0.46, 0.38), 10, 6.0))
	boton.focus_mode = Control.FOCUS_NONE; add_child(boton); boton.pressed.connect(alternar)
	boton.draw.connect(func():
		var barra := StyleBoxFlat.new(); barra.bg_color = Estilo.CREMA; barra.set_corner_radius_all(4); barra.anti_aliasing = true
		for x in [16.0, 29.0]: boton.draw_style_box(barra, Rect2(x, 15.0, 7.0, 22.0)))
var tt := 0.0
func _process(_d: float) -> void:
	if m().state == "pausa" and m().shot_path != "":
		tt += _d
		if tt > 0.5: get_viewport().get_texture().get_image().save_png(m().shot_path); get_tree().quit()
	var eh: float = m().esc_hud; boton.scale = Vector2.ONE * eh
	boton.position = Vector2(get_viewport_rect().size.x - (14 + 52) * eh, 12 * eh)
	boton.visible = m().state == "jugando"
	if m().state != "jugando" or get_tree().paused: m()._ocultar_ui_raizal()   # avisos y burbujas del mundo nunca encima de pausa/menús
func _notification(what: int) -> void:
	# Ajustes > Pausa al cambiar de ventana
	if what == NOTIFICATION_APPLICATION_FOCUS_OUT and is_inside_tree() and Guardado.d.get("pausa_foco", true) and m().state == "jugando" and not m().test_mode: alternar()
func _unhandled_input(e: InputEvent) -> void:
	if not e.is_action_pressed("ui_cancel"): return
	var mn = m()
	if mn.state == "jugando" and e is InputEventJoypadButton and e.button_index == JOY_BUTTON_B: return   # en juego B no hace nada (sin dash); Esc/Start pausan
	if mn.state in ["jugando", "pausa"]: alternar(); get_viewport().set_input_as_handled()

func alternar() -> void:
	var mn = m()
	if mn.state == "jugando":
		mn.state = "pausa"; get_tree().paused = true; _mostrar()
	elif mn.state == "pausa":
		_cerrar(); mn.state = "jugando"; get_tree().paused = false
func _cerrar() -> void:
	if panel: panel.queue_free(); panel = null
# p7: rediseño según capturas_ui/ref_menu_escape.png. Juego de fondo desenfocado; retrato redondo + «AVENTURA EN PAUSA»;
# reloj; 6 tarjetas de estadística (valores reales); «TUS MEJORAS» con 5 cartas ligadas a las estadísticas (verde +, rojo −);
# a la derecha, personaje y botones. Sin textos al pie; las explicaciones, solo al seleccionar. Sin Compañeros.
const RP := "res://assets/ui/pausa/"
# cartas: [id, nombre, estadística, origen en la maqueta (x0, y0, x1, y1), formato]
const CARTAS := [["armadura", "PAUSA_ARMADURA", "reduccion", Rect2(60, 474, 240, 326), "%"], ["dano", "PAUSA_DANO", "dano", Rect2(326, 474, 236, 326), "%"],
	["vida", "JUEGO_VIDA", "vida_max", Rect2(588, 474, 234, 326), "vida"], ["velocidad", "JUEGO_VELOCIDAD", "vel_mov", Rect2(843, 474, 234, 326), "%"],
	["suerte", "JUEGO_SUERTE", "suerte", Rect2(1098, 474, 230, 326), "n"]]
const PANEL_O := Vector2(14, 392)
const PANEL_T := Vector2(1366, 459)
const AYUDA := {"armadura": "PAUSA_REDUCE_DANO_RECIBES", "dano": "PAUSA_FUERTE_PEGA_ARMA", "vida": "PAUSA_VIDA_MAXIMA", "velocidad": "PAUSA_RAPIDO_ANDAS", "suerte": "PAUSA_MAS_BOTIN_MEJORES_SORPRESAS"}
var ayuda: Label

func _verde(k: float) -> Color: return Color(0.2, 0.52, 0.18) if k >= 0.0 else Color(0.72, 0.16, 0.12)
func _valor(v: float, fmt: String) -> String:
	var sg := "+" if v >= 0.0 else "-"   # p13: el «−» (U+2212) no está en la fuente de las cartas: salía un cuadro roto
	match fmt:
		"vida": return "%s%d %%" % [sg, int(round(abs(v)))]   # +10 de vida sobre 100 = +10 %
		"n": return "%s%d" % [sg, int(round(abs(v)))]
	return "%s%d %%" % [sg, int(round(abs(v) * 100.0))]

func _tarjeta(ico: String, nombre: String, valor: String, vert: bool) -> PanelContainer:
	var pc := PanelContainer.new(); pc.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	pc.add_theme_stylebox_override("panel", Estilo.caja(Color(0.05, 0.15, 0.13, 0.88), Color(0.86, 0.73, 0.46, 0.45), 10, 10.0, 1))
	var hb := HBoxContainer.new(); hb.add_theme_constant_override("separation", 12); pc.add_child(hb)
	var ic := TextureRect.new(); ic.texture = load(RP + ico); ic.expand_mode = TextureRect.EXPAND_IGNORE_SIZE; ic.stretch_mode = TextureRect.STRETCH_KEEP_ASPECT_CENTERED
	ic.custom_minimum_size = Vector2(34, 34) if not vert else Vector2(28, 28); ic.size_flags_vertical = Control.SIZE_SHRINK_CENTER; hb.add_child(ic)
	var vb := VBoxContainer.new(); vb.add_theme_constant_override("separation", 0); vb.size_flags_horizontal = Control.SIZE_EXPAND_FILL; hb.add_child(vb)
	var l1 := Estilo.texto(tr(nombre).to_upper(), 11, Estilo.SUAVE); l1.add_theme_font_override("font", Estilo.negrita()); vb.add_child(l1)
	var l2 := Estilo.texto(valor, (20 if valor.length() < 15 else 17) if not vert else (17 if valor.length() < 15 else 15), Estilo.CREMA); l2.add_theme_font_override("font", Estilo.serif()); l2.text_overrun_behavior = TextServer.OVERRUN_TRIM_ELLIPSIS; vb.add_child(l2)
	var ra := TextureRect.new(); ra.texture = load(RP + "ramita.png"); ra.expand_mode = TextureRect.EXPAND_IGNORE_SIZE; ra.custom_minimum_size = Vector2(26, 26)
	ra.size_flags_vertical = Control.SIZE_SHRINK_END; ra.modulate = Color(1, 1, 1, 0.8); hb.add_child(ra)
	return pc

func _boton(txt: String, primario := false) -> Button:
	var b := Button.new(); b.text = txt; b.alignment = HORIZONTAL_ALIGNMENT_LEFT; b.custom_minimum_size = Vector2(0, 50)
	b.add_theme_font_override("font", Estilo.serif()); b.add_theme_font_size_override("font_size", 19)
	var n := Estilo.caja(Color(0.98, 0.78, 0.4) if primario else Color(0.05, 0.16, 0.14, 0.92), Color(1, 0.93, 0.75) if primario else Color(0.86, 0.73, 0.46, 0.4), 10, 18.0, 2 if primario else 1)
	n.content_margin_left = 18
	var h: StyleBoxFlat = n.duplicate(); h.bg_color = n.bg_color.lightened(0.12); h.border_color = Color(1, 0.92, 0.7); h.set_border_width_all(2)
	b.add_theme_stylebox_override("normal", n); b.add_theme_stylebox_override("hover", h); b.add_theme_stylebox_override("focus", h); b.add_theme_stylebox_override("pressed", h)
	var col := Color(0.2, 0.12, 0.04) if primario else Estilo.CREMA
	for k in ["font_color", "font_hover_color", "font_focus_color", "font_pressed_color"]: b.add_theme_color_override(k, col)
	var fl := Label.new(); fl.text = "›"; fl.add_theme_font_size_override("font_size", 24); fl.add_theme_color_override("font_color", col); fl.mouse_filter = Control.MOUSE_FILTER_IGNORE
	fl.vertical_alignment = VERTICAL_ALIGNMENT_CENTER; fl.anchor_left = 1.0; fl.anchor_right = 1.0; fl.anchor_top = 0.0; fl.anchor_bottom = 1.0
	fl.offset_left = -34; fl.offset_right = -14; fl.offset_top = -3; fl.offset_bottom = -3; b.add_child(fl)
	return b

func _mostrar() -> void:
	var mn = m(); _cerrar()
	var vert := Estilo.vertical()
	var raiz: bool = mn.modo in ["raizal", "bosque", "zona"]
	var bosq: bool = mn.modo == "bosque"
	panel = Control.new(); panel.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT); add_child(panel)
	# p13: el fondo era un shader de pantalla (hint_screen_texture con mipmaps) que en la web (Compatibility) sale NEGRO. Ahora es una
	# foto de la pantalla reducida (desenfoque barato y seguro en todos los renderizadores), oscurecida como antes.
	var fondo := TextureRect.new(); fondo.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT); fondo.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
	fondo.stretch_mode = TextureRect.STRETCH_SCALE; fondo.texture_filter = CanvasItem.TEXTURE_FILTER_LINEAR; fondo.modulate = Color(0.42, 0.5, 0.47)
	var foto: Image = get_viewport().get_texture().get_image()
	if foto != null and not foto.is_empty():
		foto.resize(max(8, foto.get_width() / 24), max(8, foto.get_height() / 24), Image.INTERPOLATE_BILINEAR)
		foto.resize(foto.get_width() * 4, foto.get_height() * 4, Image.INTERPOLATE_CUBIC)
		fondo.texture = ImageTexture.create_from_image(foto)
	panel.add_child(fondo)
	var vs: Vector2 = get_viewport_rect().size
	var mg := MarginContainer.new(); mg.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	# p13: menú centrado y equilibrado en cualquier ventana: ancho útil máx. 1240, todo el bloque centrado en vertical
	var lado: float = 18.0 if vert else max(30.0, (vs.x - 1240.0) / 2.0)
	for k in ["left", "right"]: mg.add_theme_constant_override("margin_" + k, int(lado))
	mg.add_theme_constant_override("margin_top", 22 if vert else 20); mg.add_theme_constant_override("margin_bottom", 22 if vert else 20); panel.add_child(mg)
	var cont := VBoxContainer.new(); cont.add_theme_constant_override("separation", 12); cont.alignment = BoxContainer.ALIGNMENT_CENTER; mg.add_child(cont)
	var ancho: float = vs.x - 2.0 * lado
	var ancho_der: float = 0.0 if vert else clamp(ancho * 0.25, 240.0, 300.0)
	# cabecera
	var cab := HBoxContainer.new(); cab.add_theme_constant_override("separation", 16); cont.add_child(cab)
	var aro := PanelContainer.new(); aro.add_theme_stylebox_override("panel", Estilo.caja(Color(0.92, 0.85, 0.7), Color(0.86, 0.73, 0.46), 40, 2.0, 3)); aro.size_flags_vertical = Control.SIZE_SHRINK_CENTER; cab.add_child(aro)
	var rt := TextureRect.new(); rt.texture = load(Personajes.LISTA[mn.pj]["img"]); rt.expand_mode = TextureRect.EXPAND_IGNORE_SIZE; rt.stretch_mode = TextureRect.STRETCH_KEEP_ASPECT_COVERED
	rt.custom_minimum_size = Vector2(70, 70) if not vert else Vector2(60, 60); var cm := ShaderMaterial.new(); cm.shader = load("res://assets/ui/circulo.gdshader"); rt.material = cm; aro.add_child(rt)
	var tv := VBoxContainer.new(); tv.add_theme_constant_override("separation", 0); tv.size_flags_horizontal = Control.SIZE_EXPAND_FILL; cab.add_child(tv)
	var ce := Estilo.ceja(tr("PAUSA_AVENTURA_PAUSA"), 13); tv.add_child(ce)
	var ti := Estilo.texto(tr("PAUSA_MOMENTO_CALMA"), 38 if not vert else 30, Estilo.CREMA); ti.add_theme_font_override("font", Estilo.serif()); tv.add_child(ti)
	var sub := tr("PAUSA_RAIZAL_POBLADO_GRAN_ARBOL")
	if bosq: sub = tr("PAUSA_BOSQUE_SUSURRANTE_CLARO_LUCIERNAGAS")
	if raiz and mn.dentro != "": sub = tr("PAUSA_RAIZAL") % tr(Raizal.NOMBRE_CASA.get(mn.dentro, ""))
	if mn.modo == "zona": sub = tr("JUEGO_REFUGIO_BRUJA") if mn.zona_id == "refugio" else tr(Secretos.ZONAS[mn.zona_id]["n"])
	tv.add_child(Estilo.texto(sub, 15, Estilo.SUAVE))
	var rl := Estilo.pastilla("%02d:%02d" % [int(mn.alive_time) / 60, int(mn.alive_time) % 60]); rl.size_flags_vertical = Control.SIZE_SHRINK_BEGIN; cab.add_child(rl)
	var raya := ColorRect.new(); raya.color = Color(0.86, 0.73, 0.46, 0.3); raya.custom_minimum_size = Vector2(0, 1); cont.add_child(raya)
	# cuerpo
	var cuerpo: BoxContainer = VBoxContainer.new() if vert else HBoxContainer.new(); cuerpo.add_theme_constant_override("separation", 22); cont.add_child(cuerpo)
	var izq := VBoxContainer.new(); izq.size_flags_horizontal = Control.SIZE_EXPAND_FILL; izq.add_theme_constant_override("separation", 12); cuerpo.add_child(izq)
	var gr := GridContainer.new(); gr.columns = 2 if vert else 3; gr.add_theme_constant_override("h_separation", 12); gr.add_theme_constant_override("v_separation", 10); izq.add_child(gr)
	var nivel: int = mn.arpg["nivel"]
	var oro: int = mn.arpg["oro"]
	var calm: int = int(mn.arpg.get("calmados_tot", 0))
	var arma_t: String = ((Armas.n(mn.arma) + (" · +%d" % mn.arpg["arma_mas"] if mn.arpg["arma_mas"] > 0 else "")))
	# «Criaturas liberadas» (Francisco, 19/10 23:50)
	for d in [["ico_nivel.png", tr("JUEGO_NIVEL"), str(nivel)], ["ico_vida.png", tr("JUEGO_VIDA"), "%d / %d" % [int(ceil(mn.player.hp)), int(mn.player.max_hp)]], ["ico_fragmentos.png", tr("MENU_JEFES_VENCIDOS"), str(mn.arpg.get("jefes_tot", 0))],
			["ico_oro_v2.png", tr("PAUSA_ORO"), Estilo.miles(oro)], ["ico_criaturas.png", tr("PAUSA_CRIATURAS_LIBERADAS"), Estilo.miles(calm)], ["ico_arma.png", tr("JUEGO_ARMA"), arma_t]]:
		gr.add_child(_tarjeta(d[0], d[1], d[2], vert))
	# TUS MEJORAS: el panel de la maqueta y, encima, las cartas en su sitio exacto
	# tamaño exacto del panel: todo el ancho de la columna si cabe en alto; si no, lo que quepa, centrado bajo las tarjetas
	var marco := AspectRatioContainer.new(); marco.ratio = PANEL_T.x / PANEL_T.y; izq.add_child(marco)
	var ancho_izq: float = ancho if vert else ancho - ancho_der - 22.0
	var alto_libre: float = vs.y - 40.0 - 98.0 - 13.0 - (2 if not vert else 3) * 62.0 - 32.0 - 12.0 * 3 - (0.0 if not vert else 6 * 60.0 + 30.0)
	var alto_m: float = max(160.0, min(ancho_izq / marco.ratio, alto_libre))
	marco.custom_minimum_size = Vector2(alto_m * marco.ratio, alto_m); marco.size_flags_horizontal = Control.SIZE_SHRINK_CENTER
	var lam := TextureRect.new(); lam.texture = load(RP + "panel_mejoras.png"); lam.expand_mode = TextureRect.EXPAND_IGNORE_SIZE; lam.stretch_mode = TextureRect.STRETCH_SCALE; marco.add_child(lam)
	var primera: Control = null
	for c in CARTAS:
		var v: float = mn.st(c[2]); var abierta: bool = abs(v) > 0.0001
		var nombre_t: String = "carta_%s%s.png" % [c[0], "" if abierta else "_cerrada"]
		if c[0] == "dano" and abierta and v < 0.0: nombre_t = "carta_dano_neg.png"
		var bt := Button.new(); bt.flat = true; bt.focus_mode = Control.FOCUS_ALL; bt.name = "Mejora_" + c[0]
		var vacio := StyleBoxEmpty.new(); bt.add_theme_stylebox_override("normal", vacio); bt.add_theme_stylebox_override("hover", vacio); bt.add_theme_stylebox_override("pressed", vacio)
		var foco := StyleBoxFlat.new(); foco.draw_center = false; foco.border_color = Color(1, 0.92, 0.6); foco.set_border_width_all(3); foco.set_corner_radius_all(18); bt.add_theme_stylebox_override("focus", foco)
		lam.add_child(bt)
		var t_r := TextureRect.new(); t_r.texture = load(RP + nombre_t); t_r.expand_mode = TextureRect.EXPAND_IGNORE_SIZE; t_r.stretch_mode = TextureRect.STRETCH_SCALE; t_r.mouse_filter = Control.MOUSE_FILTER_IGNORE
		t_r.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT); bt.add_child(t_r)
		var ln := Label.new(); ln.mouse_filter = Control.MOUSE_FILTER_IGNORE; ln.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER; ln.add_theme_font_override("font", Estilo.serif())
		ln.add_theme_color_override("font_color", Color(0.25, 0.16, 0.08)); bt.add_child(ln)
		var lv := Label.new(); lv.mouse_filter = Control.MOUSE_FILTER_IGNORE; lv.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER; lv.add_theme_font_override("font", Estilo.negrita())
		lv.add_theme_color_override("font_color", _verde(v)); bt.add_child(lv)
		ln.text = c[1] if abierta else ""; lv.text = _valor(v, c[4]) if abierta else ""
		var r: Rect2 = Rect2(c[3].position - PANEL_O, c[3].size)
		lam.resized.connect(func():
			var k: float = lam.size.x / PANEL_T.x
			bt.position = r.position * k; bt.size = r.size * k
			ln.position = Vector2(0, 204.0 * k); ln.size = Vector2(r.size.x * k, 40.0 * k); ln.add_theme_font_size_override("font_size", max(9, int(26.0 * k)))
			lv.position = Vector2(0, 238.0 * k); lv.size = Vector2(r.size.x * k, 44.0 * k); lv.add_theme_font_size_override("font_size", max(10, int(32.0 * k))))
		# explicación solo al seleccionar (foco o ratón encima)
		var cid: String = c[0]; var cn: String = c[1]; var cs: String = c[2]; var cf: String = c[4]
		var explica := func():
			var t: String = "%s: %s." % [tr(cn), tr(AYUDA[cid])]
			if abs(mn.st(cs)) > 0.0001:
				var partes: Array = []
				for o in mn.stats_de.get(cs, []): partes.append("%s %s" % [o[0], _valor(o[1], cf)])
				t += "  " + " · ".join(partes)
			else: t += tr("PAUSA_AUN_SIN_MEJORAS")
			ayuda.text = t
		bt.focus_entered.connect(explica); bt.mouse_entered.connect(explica)
		bt.focus_exited.connect(func(): ayuda.text = ""); bt.mouse_exited.connect(func(): if not bt.has_focus(): ayuda.text = "")
		if primera == null: primera = bt
	ayuda = Estilo.texto("", 14, Estilo.CREMA); ayuda.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART; ayuda.custom_minimum_size.y = 20; izq.add_child(ayuda)
	# columna derecha
	var der := VBoxContainer.new(); der.add_theme_constant_override("separation", 10); der.custom_minimum_size.x = ancho_der; der.alignment = BoxContainer.ALIGNMENT_BEGIN; cuerpo.add_child(der)
	der.add_child(Estilo.texto(tr("PAUSA_PERSONAJE") % tr(Personajes.LISTA[mn.pj]["n"]), 15, Estilo.SUAVE))
	var c := _boton(tr("MENU_CONTINUAR"), true); der.add_child(c); c.pressed.connect(alternar)
	if raiz and not bosq:   # el Árbol de Cristal se abre desde aquí. Compañeros: pantalla quitada (19/10, 20:15)
		var bo := _boton(tr("JUEGO_ARBOL_CRISTAL")); der.add_child(bo)
		bo.pressed.connect(func(): _abrir_menu("arbol"))
	if bosq:
		var vr := _boton(tr("JUEGO_VOLVER_RAIZAL")); der.add_child(vr)
		vr.pressed.connect(func(): _cerrar(); get_tree().paused = false; mn.state = "jugando"; mn.start_raizal("bosque"))
	if raiz and not Secretos.lista(mn.arpg, "frags").is_empty():   # colección del pergamino (zonas secretas)
		var bpg := _boton(tr("JUEGO_PERGAMINO")); der.add_child(bpg)
		bpg.pressed.connect(func(): _cerrar(); mn._pergamino_ui(func(): mn.state = "pausa"; get_tree().paused = true; _mostrar()))
	var aj := _boton(tr("JUEGO_AJUSTES")); der.add_child(aj); aj.pressed.connect(func(): _abrir_menu("ajustes"))
	var s := _boton(tr("PAUSA_SALIR_AL_MENU")); der.add_child(s)
	s.pressed.connect(func():
		_cerrar(); get_tree().paused = false
		mn.volver_raizal = false; mn.arpg_guardar(); mn._volver_menu("principal"))
	c.grab_focus()
	if "--pausa_carta" in OS.get_cmdline_user_args() and primera: (func(): await get_tree().process_frame; primera.grab_focus()).call()

func _abrir_menu(dest: String) -> void:
	var mn = m(); _cerrar(); mn.state = "menu"
	mn.menu.volver_cb = func(): mn.menu.visible = false; mn.state = "pausa"; _mostrar()
	mn.menu.mostrar(dest)
